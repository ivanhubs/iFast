import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FundfactsheetComponent } from './fundfactsheet/fundfactsheet.component';


const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'fundfactsheet',component:FundfactsheetComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
