import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderHomeComponent } from './home/header-home/header-home.component';
import { Body1HomeComponent } from './home/body1-home/body1-home.component';
import { Body2HomeComponent } from './home/body2-home/body2-home.component';
import { Body3HomeComponent } from './home/body3-home/body3-home.component';
import { Body4HomeComponent } from './home/body4-home/body4-home.component';
import { FooterHomeComponent } from './home/footer-home/footer-home.component';
import { FundfactsheetComponent } from './fundfactsheet/fundfactsheet.component';
import { FundTitleComponent } from './fundfactsheet/fund-title/fund-title.component';
import { FundInfoComponent } from './fundfactsheet/fund-info/fund-info.component';
import { FundDocumentsComponent } from './fundfactsheet/fund-documents/fund-documents.component';
import { InvestObjectiveComponent } from './fundfactsheet/invest-objective/invest-objective.component';
import { FundPerformanceComponent } from './fundfactsheet/fund-performance/fund-performance.component';
import { AnnualisedReturnsComponent } from './fundfactsheet/fund-performance/annualised-returns/annualised-returns.component';
import { CumulativePerformanceComponent } from './fundfactsheet/fund-performance/cumulative-performance/cumulative-performance.component';
import { YearReturnsComponent } from './fundfactsheet/fund-performance/year-returns/year-returns.component';
import { HistoricalNavMovementComponent } from './fundfactsheet/fund-performance/historical-nav-movement/historical-nav-movement.component';
import { FundReturnsComponent } from './fundfactsheet/fund-returns/fund-returns.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderHomeComponent,
    Body1HomeComponent,
    Body2HomeComponent,
    Body3HomeComponent,
    Body4HomeComponent,
    FooterHomeComponent,
    FundfactsheetComponent,
    FundTitleComponent,
    FundInfoComponent,
    FundDocumentsComponent,
    InvestObjectiveComponent,
    FundPerformanceComponent,
    AnnualisedReturnsComponent,
    CumulativePerformanceComponent,
    YearReturnsComponent,
    HistoricalNavMovementComponent,
    FundReturnsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
