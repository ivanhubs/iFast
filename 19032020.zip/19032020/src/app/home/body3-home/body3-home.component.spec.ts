import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Body3HomeComponent } from './body3-home.component';

describe('Body3HomeComponent', () => {
  let component: Body3HomeComponent;
  let fixture: ComponentFixture<Body3HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Body3HomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Body3HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
