import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Body4HomeComponent } from './body4-home.component';

describe('Body4HomeComponent', () => {
  let component: Body4HomeComponent;
  let fixture: ComponentFixture<Body4HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Body4HomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Body4HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
