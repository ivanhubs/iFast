import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-returns',
  templateUrl: './fund-returns.component.html',
  styleUrls: ['./fund-returns.component.css']
})
export class FundReturnsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
