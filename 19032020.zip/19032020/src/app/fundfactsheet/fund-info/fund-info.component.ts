import { Component, OnInit } from '@angular/core';
import {FundInfo} from './fundInfo'
@Component({
  selector: 'app-fund-info',
  templateUrl: './fund-info.component.html',
  styleUrls: ['./fund-info.component.css']
})
export class FundInfoComponent implements OnInit {
  fundsInfo: FundInfo[] = [
    { class: 'Equity', sector: 'General'
    , geo_Alloc: 'Asia excluding Japan',approvalEPF:"No",complaintShariah:"Yes"
  ,fundSize:15.2,dateLaunch:"Dec 2,2015",priceLaunch:1.00,pricingBasis:"Foward Pricing"
,historicalIncomeDist:"-"}
  ];
constructor() { }

  ngOnInit(): void {
  }

}
