import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CumulativePerformanceComponent } from './cumulative-performance.component';

describe('CumulativePerformanceComponent', () => {
  let component: CumulativePerformanceComponent;
  let fixture: ComponentFixture<CumulativePerformanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CumulativePerformanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CumulativePerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
