import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoricalNavMovementComponent } from './historical-nav-movement.component';

describe('HistoricalNavMovementComponent', () => {
  let component: HistoricalNavMovementComponent;
  let fixture: ComponentFixture<HistoricalNavMovementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HistoricalNavMovementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoricalNavMovementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
