import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-documents',
  templateUrl: './fund-documents.component.html',
  styleUrls: ['./fund-documents.component.css']
})
export class FundDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
