import { Component, OnInit } from '@angular/core';
import { Fund } from '../../home/body2-home/fundData';
@Component({
  selector: 'app-fund-title',
  templateUrl: './fund-title.component.html',
  styleUrls: ['./fund-title.component.css']
})
export class FundTitleComponent implements OnInit {
  funds: Fund[] = [
    { name: 'RHB China-India Dynamic Growth Fund', price: 0.9855, percentage: 3.81}
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
