/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { CdkConnectedOverlay, CdkOverlayOrigin, ConnectedOverlayPositionChange, ConnectionPositionPair } from '@angular/cdk/overlay';
import { AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CandyDate } from 'ng-zorro-antd/core';
import { DateHelperService } from 'ng-zorro-antd/i18n';
import * as ɵngcc0 from '@angular/core';
export declare class NzPickerComponent implements AfterViewInit, OnChanges {
    private dateHelper;
    private changeDetector;
    noAnimation: boolean;
    isRange: boolean;
    open: boolean | undefined;
    disabled: boolean;
    placeholder: string | string[];
    allowClear: boolean;
    autoFocus: boolean;
    className: string;
    format: string;
    size: 'large' | 'small';
    style: object;
    value: CandyDate | CandyDate[] | null;
    readonly valueChange: EventEmitter<CandyDate | CandyDate[] | null>;
    readonly openChange: EventEmitter<boolean>;
    origin: CdkOverlayOrigin;
    cdkConnectedOverlay: CdkConnectedOverlay;
    pickerInput: ElementRef;
    prefixCls: string;
    animationOpenState: boolean;
    overlayOpen: boolean;
    overlayOffsetY: number;
    overlayOffsetX: number;
    overlayPositions: ConnectionPositionPair[];
    dropdownAnimation: 'top' | 'bottom';
    currentPositionX: 'start' | 'end';
    currentPositionY: 'top' | 'bottom';
    readonly realOpenState: boolean;
    constructor(dateHelper: DateHelperService, changeDetector: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    focus(): void;
    showOverlay(): void;
    hideOverlay(): void;
    onClickInputBox(): void;
    onClickBackdrop(): void;
    onOverlayDetach(): void;
    onPositionChange(position: ConnectedOverlayPositionChange): void;
    onClickClear(event: MouseEvent): void;
    getReadableValue(partType?: RangePartType): string | null;
    getPartTypeIndex(partType: RangePartType): number;
    getPlaceholder(partType?: RangePartType): string;
    isEmptyValue(value: CandyDate[] | CandyDate | null): boolean;
    isOpenHandledByUser(): boolean;
    animationStart(): void;
    animationDone(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzPickerComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzPickerComponent, "nz-picker", ["nzPicker"], {
    "noAnimation": "noAnimation";
    "isRange": "isRange";
    "open": "open";
    "value": "value";
    "disabled": "disabled";
    "placeholder": "placeholder";
    "allowClear": "allowClear";
    "autoFocus": "autoFocus";
    "className": "className";
    "format": "format";
    "size": "size";
    "style": "style";
}, {
    "valueChange": "valueChange";
    "openChange": "openChange";
}, never>;
}
export declare type RangePartType = 'left' | 'right';

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlja2VyLmNvbXBvbmVudC5kLnRzIiwic291cmNlcyI6WyJwaWNrZXIuY29tcG9uZW50LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7OztBQVdBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnREEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IENka0Nvbm5lY3RlZE92ZXJsYXksIENka092ZXJsYXlPcmlnaW4sIENvbm5lY3RlZE92ZXJsYXlQb3NpdGlvbkNoYW5nZSwgQ29ubmVjdGlvblBvc2l0aW9uUGFpciB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IEFmdGVyVmlld0luaXQsIENoYW5nZURldGVjdG9yUmVmLCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ2FuZHlEYXRlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmltcG9ydCB7IERhdGVIZWxwZXJTZXJ2aWNlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9pMThuJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56UGlja2VyQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25DaGFuZ2VzIHtcbiAgICBwcml2YXRlIGRhdGVIZWxwZXI7XG4gICAgcHJpdmF0ZSBjaGFuZ2VEZXRlY3RvcjtcbiAgICBub0FuaW1hdGlvbjogYm9vbGVhbjtcbiAgICBpc1JhbmdlOiBib29sZWFuO1xuICAgIG9wZW46IGJvb2xlYW4gfCB1bmRlZmluZWQ7XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgcGxhY2Vob2xkZXI6IHN0cmluZyB8IHN0cmluZ1tdO1xuICAgIGFsbG93Q2xlYXI6IGJvb2xlYW47XG4gICAgYXV0b0ZvY3VzOiBib29sZWFuO1xuICAgIGNsYXNzTmFtZTogc3RyaW5nO1xuICAgIGZvcm1hdDogc3RyaW5nO1xuICAgIHNpemU6ICdsYXJnZScgfCAnc21hbGwnO1xuICAgIHN0eWxlOiBvYmplY3Q7XG4gICAgdmFsdWU6IENhbmR5RGF0ZSB8IENhbmR5RGF0ZVtdIHwgbnVsbDtcbiAgICByZWFkb25seSB2YWx1ZUNoYW5nZTogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZSB8IENhbmR5RGF0ZVtdIHwgbnVsbD47XG4gICAgcmVhZG9ubHkgb3BlbkNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuICAgIG9yaWdpbjogQ2RrT3ZlcmxheU9yaWdpbjtcbiAgICBjZGtDb25uZWN0ZWRPdmVybGF5OiBDZGtDb25uZWN0ZWRPdmVybGF5O1xuICAgIHBpY2tlcklucHV0OiBFbGVtZW50UmVmO1xuICAgIHByZWZpeENsczogc3RyaW5nO1xuICAgIGFuaW1hdGlvbk9wZW5TdGF0ZTogYm9vbGVhbjtcbiAgICBvdmVybGF5T3BlbjogYm9vbGVhbjtcbiAgICBvdmVybGF5T2Zmc2V0WTogbnVtYmVyO1xuICAgIG92ZXJsYXlPZmZzZXRYOiBudW1iZXI7XG4gICAgb3ZlcmxheVBvc2l0aW9uczogQ29ubmVjdGlvblBvc2l0aW9uUGFpcltdO1xuICAgIGRyb3Bkb3duQW5pbWF0aW9uOiAndG9wJyB8ICdib3R0b20nO1xuICAgIGN1cnJlbnRQb3NpdGlvblg6ICdzdGFydCcgfCAnZW5kJztcbiAgICBjdXJyZW50UG9zaXRpb25ZOiAndG9wJyB8ICdib3R0b20nO1xuICAgIHJlYWRvbmx5IHJlYWxPcGVuU3RhdGU6IGJvb2xlYW47XG4gICAgY29uc3RydWN0b3IoZGF0ZUhlbHBlcjogRGF0ZUhlbHBlclNlcnZpY2UsIGNoYW5nZURldGVjdG9yOiBDaGFuZ2VEZXRlY3RvclJlZik7XG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQ7XG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQ7XG4gICAgZm9jdXMoKTogdm9pZDtcbiAgICBzaG93T3ZlcmxheSgpOiB2b2lkO1xuICAgIGhpZGVPdmVybGF5KCk6IHZvaWQ7XG4gICAgb25DbGlja0lucHV0Qm94KCk6IHZvaWQ7XG4gICAgb25DbGlja0JhY2tkcm9wKCk6IHZvaWQ7XG4gICAgb25PdmVybGF5RGV0YWNoKCk6IHZvaWQ7XG4gICAgb25Qb3NpdGlvbkNoYW5nZShwb3NpdGlvbjogQ29ubmVjdGVkT3ZlcmxheVBvc2l0aW9uQ2hhbmdlKTogdm9pZDtcbiAgICBvbkNsaWNrQ2xlYXIoZXZlbnQ6IE1vdXNlRXZlbnQpOiB2b2lkO1xuICAgIGdldFJlYWRhYmxlVmFsdWUocGFydFR5cGU/OiBSYW5nZVBhcnRUeXBlKTogc3RyaW5nIHwgbnVsbDtcbiAgICBnZXRQYXJ0VHlwZUluZGV4KHBhcnRUeXBlOiBSYW5nZVBhcnRUeXBlKTogbnVtYmVyO1xuICAgIGdldFBsYWNlaG9sZGVyKHBhcnRUeXBlPzogUmFuZ2VQYXJ0VHlwZSk6IHN0cmluZztcbiAgICBpc0VtcHR5VmFsdWUodmFsdWU6IENhbmR5RGF0ZVtdIHwgQ2FuZHlEYXRlIHwgbnVsbCk6IGJvb2xlYW47XG4gICAgaXNPcGVuSGFuZGxlZEJ5VXNlcigpOiBib29sZWFuO1xuICAgIGFuaW1hdGlvblN0YXJ0KCk6IHZvaWQ7XG4gICAgYW5pbWF0aW9uRG9uZSgpOiB2b2lkO1xufVxuZXhwb3J0IGRlY2xhcmUgdHlwZSBSYW5nZVBhcnRUeXBlID0gJ2xlZnQnIHwgJ3JpZ2h0JztcbiJdfQ==