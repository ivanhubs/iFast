/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { CandyDate, FunctionProp } from 'ng-zorro-antd/core';
import { NzCalendarI18nInterface } from 'ng-zorro-antd/i18n';
import { CompatibleValue, DisabledDateFn, DisabledTimeConfig, DisabledTimeFn, PanelMode, PresetRanges, SupportTimeOptions } from '../../standard-types';
import * as ɵngcc0 from '@angular/core';
export declare class DateRangePopupComponent implements OnInit, OnChanges {
    isRange: boolean;
    showWeek: boolean;
    locale: NzCalendarI18nInterface;
    format: string;
    placeholder: string | string[];
    disabledDate: DisabledDateFn;
    disabledTime: DisabledTimeFn;
    showToday: boolean;
    showTime: SupportTimeOptions | boolean;
    extraFooter: TemplateRef<void> | string;
    ranges: PresetRanges;
    dateRender: FunctionProp<TemplateRef<Date> | string>;
    popupStyle: object;
    dropdownClassName: string;
    panelMode: PanelMode | PanelMode[];
    value: CompatibleValue;
    readonly panelModeChange: EventEmitter<"decade" | "year" | "month" | "date" | "time" | PanelMode[]>;
    readonly calendarChange: EventEmitter<CompatibleValue>;
    readonly valueChange: EventEmitter<CompatibleValue>;
    readonly inputChange: EventEmitter<CompatibleValue>;
    readonly resultOk: EventEmitter<void>;
    readonly closePicker: EventEmitter<void>;
    prefixCls: string;
    showTimePicker: boolean;
    timeOptions: SupportTimeOptions | SupportTimeOptions[] | null;
    valueForRangeShow: CandyDate[];
    selectedValue: CandyDate[];
    hoverValue: CandyDate[];
    readonly hasTimePicker: boolean;
    readonly hasFooter: boolean;
    private partTypeMap;
    [property: string]: any;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onShowTimePickerChange(show: boolean): void;
    onClickOk(): void;
    onClickToday(value: CandyDate): void;
    onDayHover(value: CandyDate): void;
    onPanelModeChange(mode: PanelMode, partType?: RangePartType): void;
    onHeaderChange(value: CandyDate, partType?: RangePartType): void;
    onSelectTime(value: CandyDate, partType?: RangePartType): void;
    changeValueFromInput(value: {
        date: CandyDate;
        isEnter: boolean;
    }, partType?: RangePartType): void;
    changeValueFromSelect(value: CandyDate): void;
    enablePrevNext(direction: 'prev' | 'next', partType?: RangePartType): boolean;
    getPanelMode(partType?: RangePartType): PanelMode;
    getValue(partType?: RangePartType): CandyDate;
    getValueBySelector(partType?: RangePartType): CandyDate;
    getPartTypeIndex(partType?: RangePartType): number;
    getPlaceholder(partType?: RangePartType): string;
    hasSelectedValue(): boolean;
    disabledStartTime: (value: Date | Date[]) => DisabledTimeConfig;
    disabledEndTime: (value: Date | Date[]) => DisabledTimeConfig;
    isAllowedSelectedValue(): boolean;
    timePickerDisabled(): boolean;
    okDisabled(): boolean;
    getTimeOptions(partType?: RangePartType): SupportTimeOptions | null;
    onClickPresetRange(val: PresetRanges[keyof PresetRanges]): void;
    onPresetRangeMouseLeave(): void;
    onHoverPresetRange(val: PresetRanges[keyof PresetRanges]): void;
    getObjectKeys(obj: object): string[];
    private closePickerPanel;
    private clearHoverValue;
    private buildTimeOptions;
    private overrideTimeOptions;
    private setValueFromInput;
    private setValue;
    private overrideHms;
    private isValidRange;
    private normalizeRangeValue;
    private setRangeValue;
    private cloneRangeDate;
    private initialArray;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DateRangePopupComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<DateRangePopupComponent, "date-range-popup", ["dateRangePopup"], {
    "value": "value";
    "panelMode": "panelMode";
    "isRange": "isRange";
    "showWeek": "showWeek";
    "locale": "locale";
    "format": "format";
    "placeholder": "placeholder";
    "disabledDate": "disabledDate";
    "disabledTime": "disabledTime";
    "showToday": "showToday";
    "showTime": "showTime";
    "extraFooter": "extraFooter";
    "ranges": "ranges";
    "dateRender": "dateRender";
    "popupStyle": "popupStyle";
    "dropdownClassName": "dropdownClassName";
}, {
    "panelModeChange": "panelModeChange";
    "calendarChange": "calendarChange";
    "valueChange": "valueChange";
    "inputChange": "inputChange";
    "resultOk": "resultOk";
    "closePicker": "closePicker";
}, never>;
}
export declare type RangePartType = 'left' | 'right';

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS1yYW5nZS1wb3B1cC5jb21wb25lbnQuZC50cyIsInNvdXJjZXMiOlsiZGF0ZS1yYW5nZS1wb3B1cC5jb21wb25lbnQuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7O0FBV0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTRFQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyLCBPbkNoYW5nZXMsIE9uSW5pdCwgU2ltcGxlQ2hhbmdlcywgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENhbmR5RGF0ZSwgRnVuY3Rpb25Qcm9wIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmltcG9ydCB7IE56Q2FsZW5kYXJJMThuSW50ZXJmYWNlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9pMThuJztcbmltcG9ydCB7IENvbXBhdGlibGVWYWx1ZSwgRGlzYWJsZWREYXRlRm4sIERpc2FibGVkVGltZUNvbmZpZywgRGlzYWJsZWRUaW1lRm4sIFBhbmVsTW9kZSwgUHJlc2V0UmFuZ2VzLCBTdXBwb3J0VGltZU9wdGlvbnMgfSBmcm9tICcuLi8uLi9zdGFuZGFyZC10eXBlcyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEYXRlUmFuZ2VQb3B1cENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBpc1JhbmdlOiBib29sZWFuO1xuICAgIHNob3dXZWVrOiBib29sZWFuO1xuICAgIGxvY2FsZTogTnpDYWxlbmRhckkxOG5JbnRlcmZhY2U7XG4gICAgZm9ybWF0OiBzdHJpbmc7XG4gICAgcGxhY2Vob2xkZXI6IHN0cmluZyB8IHN0cmluZ1tdO1xuICAgIGRpc2FibGVkRGF0ZTogRGlzYWJsZWREYXRlRm47XG4gICAgZGlzYWJsZWRUaW1lOiBEaXNhYmxlZFRpbWVGbjtcbiAgICBzaG93VG9kYXk6IGJvb2xlYW47XG4gICAgc2hvd1RpbWU6IFN1cHBvcnRUaW1lT3B0aW9ucyB8IGJvb2xlYW47XG4gICAgZXh0cmFGb290ZXI6IFRlbXBsYXRlUmVmPHZvaWQ+IHwgc3RyaW5nO1xuICAgIHJhbmdlczogUHJlc2V0UmFuZ2VzO1xuICAgIGRhdGVSZW5kZXI6IEZ1bmN0aW9uUHJvcDxUZW1wbGF0ZVJlZjxEYXRlPiB8IHN0cmluZz47XG4gICAgcG9wdXBTdHlsZTogb2JqZWN0O1xuICAgIGRyb3Bkb3duQ2xhc3NOYW1lOiBzdHJpbmc7XG4gICAgcGFuZWxNb2RlOiBQYW5lbE1vZGUgfCBQYW5lbE1vZGVbXTtcbiAgICB2YWx1ZTogQ29tcGF0aWJsZVZhbHVlO1xuICAgIHJlYWRvbmx5IHBhbmVsTW9kZUNoYW5nZTogRXZlbnRFbWl0dGVyPFwiZGVjYWRlXCIgfCBcInllYXJcIiB8IFwibW9udGhcIiB8IFwiZGF0ZVwiIHwgXCJ0aW1lXCIgfCBQYW5lbE1vZGVbXT47XG4gICAgcmVhZG9ubHkgY2FsZW5kYXJDaGFuZ2U6IEV2ZW50RW1pdHRlcjxDb21wYXRpYmxlVmFsdWU+O1xuICAgIHJlYWRvbmx5IHZhbHVlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Q29tcGF0aWJsZVZhbHVlPjtcbiAgICByZWFkb25seSBpbnB1dENoYW5nZTogRXZlbnRFbWl0dGVyPENvbXBhdGlibGVWYWx1ZT47XG4gICAgcmVhZG9ubHkgcmVzdWx0T2s6IEV2ZW50RW1pdHRlcjx2b2lkPjtcbiAgICByZWFkb25seSBjbG9zZVBpY2tlcjogRXZlbnRFbWl0dGVyPHZvaWQ+O1xuICAgIHByZWZpeENsczogc3RyaW5nO1xuICAgIHNob3dUaW1lUGlja2VyOiBib29sZWFuO1xuICAgIHRpbWVPcHRpb25zOiBTdXBwb3J0VGltZU9wdGlvbnMgfCBTdXBwb3J0VGltZU9wdGlvbnNbXSB8IG51bGw7XG4gICAgdmFsdWVGb3JSYW5nZVNob3c6IENhbmR5RGF0ZVtdO1xuICAgIHNlbGVjdGVkVmFsdWU6IENhbmR5RGF0ZVtdO1xuICAgIGhvdmVyVmFsdWU6IENhbmR5RGF0ZVtdO1xuICAgIHJlYWRvbmx5IGhhc1RpbWVQaWNrZXI6IGJvb2xlYW47XG4gICAgcmVhZG9ubHkgaGFzRm9vdGVyOiBib29sZWFuO1xuICAgIHByaXZhdGUgcGFydFR5cGVNYXA7XG4gICAgW3Byb3BlcnR5OiBzdHJpbmddOiBhbnk7XG4gICAgbmdPbkluaXQoKTogdm9pZDtcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZDtcbiAgICBvblNob3dUaW1lUGlja2VyQ2hhbmdlKHNob3c6IGJvb2xlYW4pOiB2b2lkO1xuICAgIG9uQ2xpY2tPaygpOiB2b2lkO1xuICAgIG9uQ2xpY2tUb2RheSh2YWx1ZTogQ2FuZHlEYXRlKTogdm9pZDtcbiAgICBvbkRheUhvdmVyKHZhbHVlOiBDYW5keURhdGUpOiB2b2lkO1xuICAgIG9uUGFuZWxNb2RlQ2hhbmdlKG1vZGU6IFBhbmVsTW9kZSwgcGFydFR5cGU/OiBSYW5nZVBhcnRUeXBlKTogdm9pZDtcbiAgICBvbkhlYWRlckNoYW5nZSh2YWx1ZTogQ2FuZHlEYXRlLCBwYXJ0VHlwZT86IFJhbmdlUGFydFR5cGUpOiB2b2lkO1xuICAgIG9uU2VsZWN0VGltZSh2YWx1ZTogQ2FuZHlEYXRlLCBwYXJ0VHlwZT86IFJhbmdlUGFydFR5cGUpOiB2b2lkO1xuICAgIGNoYW5nZVZhbHVlRnJvbUlucHV0KHZhbHVlOiB7XG4gICAgICAgIGRhdGU6IENhbmR5RGF0ZTtcbiAgICAgICAgaXNFbnRlcjogYm9vbGVhbjtcbiAgICB9LCBwYXJ0VHlwZT86IFJhbmdlUGFydFR5cGUpOiB2b2lkO1xuICAgIGNoYW5nZVZhbHVlRnJvbVNlbGVjdCh2YWx1ZTogQ2FuZHlEYXRlKTogdm9pZDtcbiAgICBlbmFibGVQcmV2TmV4dChkaXJlY3Rpb246ICdwcmV2JyB8ICduZXh0JywgcGFydFR5cGU/OiBSYW5nZVBhcnRUeXBlKTogYm9vbGVhbjtcbiAgICBnZXRQYW5lbE1vZGUocGFydFR5cGU/OiBSYW5nZVBhcnRUeXBlKTogUGFuZWxNb2RlO1xuICAgIGdldFZhbHVlKHBhcnRUeXBlPzogUmFuZ2VQYXJ0VHlwZSk6IENhbmR5RGF0ZTtcbiAgICBnZXRWYWx1ZUJ5U2VsZWN0b3IocGFydFR5cGU/OiBSYW5nZVBhcnRUeXBlKTogQ2FuZHlEYXRlO1xuICAgIGdldFBhcnRUeXBlSW5kZXgocGFydFR5cGU/OiBSYW5nZVBhcnRUeXBlKTogbnVtYmVyO1xuICAgIGdldFBsYWNlaG9sZGVyKHBhcnRUeXBlPzogUmFuZ2VQYXJ0VHlwZSk6IHN0cmluZztcbiAgICBoYXNTZWxlY3RlZFZhbHVlKCk6IGJvb2xlYW47XG4gICAgZGlzYWJsZWRTdGFydFRpbWU6ICh2YWx1ZTogRGF0ZSB8IERhdGVbXSkgPT4gRGlzYWJsZWRUaW1lQ29uZmlnO1xuICAgIGRpc2FibGVkRW5kVGltZTogKHZhbHVlOiBEYXRlIHwgRGF0ZVtdKSA9PiBEaXNhYmxlZFRpbWVDb25maWc7XG4gICAgaXNBbGxvd2VkU2VsZWN0ZWRWYWx1ZSgpOiBib29sZWFuO1xuICAgIHRpbWVQaWNrZXJEaXNhYmxlZCgpOiBib29sZWFuO1xuICAgIG9rRGlzYWJsZWQoKTogYm9vbGVhbjtcbiAgICBnZXRUaW1lT3B0aW9ucyhwYXJ0VHlwZT86IFJhbmdlUGFydFR5cGUpOiBTdXBwb3J0VGltZU9wdGlvbnMgfCBudWxsO1xuICAgIG9uQ2xpY2tQcmVzZXRSYW5nZSh2YWw6IFByZXNldFJhbmdlc1trZXlvZiBQcmVzZXRSYW5nZXNdKTogdm9pZDtcbiAgICBvblByZXNldFJhbmdlTW91c2VMZWF2ZSgpOiB2b2lkO1xuICAgIG9uSG92ZXJQcmVzZXRSYW5nZSh2YWw6IFByZXNldFJhbmdlc1trZXlvZiBQcmVzZXRSYW5nZXNdKTogdm9pZDtcbiAgICBnZXRPYmplY3RLZXlzKG9iajogb2JqZWN0KTogc3RyaW5nW107XG4gICAgcHJpdmF0ZSBjbG9zZVBpY2tlclBhbmVsO1xuICAgIHByaXZhdGUgY2xlYXJIb3ZlclZhbHVlO1xuICAgIHByaXZhdGUgYnVpbGRUaW1lT3B0aW9ucztcbiAgICBwcml2YXRlIG92ZXJyaWRlVGltZU9wdGlvbnM7XG4gICAgcHJpdmF0ZSBzZXRWYWx1ZUZyb21JbnB1dDtcbiAgICBwcml2YXRlIHNldFZhbHVlO1xuICAgIHByaXZhdGUgb3ZlcnJpZGVIbXM7XG4gICAgcHJpdmF0ZSBpc1ZhbGlkUmFuZ2U7XG4gICAgcHJpdmF0ZSBub3JtYWxpemVSYW5nZVZhbHVlO1xuICAgIHByaXZhdGUgc2V0UmFuZ2VWYWx1ZTtcbiAgICBwcml2YXRlIGNsb25lUmFuZ2VEYXRlO1xuICAgIHByaXZhdGUgaW5pdGlhbEFycmF5O1xufVxuZXhwb3J0IGRlY2xhcmUgdHlwZSBSYW5nZVBhcnRUeXBlID0gJ2xlZnQnIHwgJ3JpZ2h0JztcbiJdfQ==