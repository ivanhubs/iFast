/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, TemplateRef } from '@angular/core';
import { CandyDate, FunctionProp } from 'ng-zorro-antd/core';
import { NzCalendarI18nInterface } from 'ng-zorro-antd/i18n';
import { DisabledDateFn, PanelMode } from '../../standard-types';
import * as ɵngcc0 from '@angular/core';
export declare class InnerPopupComponent {
    showWeek: boolean;
    locale: NzCalendarI18nInterface;
    showTimePicker: boolean;
    timeOptions: any;
    enablePrev: boolean;
    enableNext: boolean;
    disabledDate: DisabledDateFn;
    dateRender: FunctionProp<TemplateRef<Date> | string>;
    selectedValue: CandyDate[];
    hoverValue: CandyDate[];
    panelMode: PanelMode;
    readonly panelModeChange: EventEmitter<PanelMode>;
    value: CandyDate;
    readonly headerChange: EventEmitter<CandyDate>;
    readonly selectDate: EventEmitter<CandyDate>;
    readonly selectTime: EventEmitter<CandyDate>;
    readonly dayHover: EventEmitter<CandyDate>;
    prefixCls: string;
    onSelectTime(date: Date): void;
    onSelectDate(date: CandyDate | Date): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<InnerPopupComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<InnerPopupComponent, "inner-popup", ["innerPopup"], {
    "showWeek": "showWeek";
    "locale": "locale";
    "showTimePicker": "showTimePicker";
    "timeOptions": "timeOptions";
    "enablePrev": "enablePrev";
    "enableNext": "enableNext";
    "disabledDate": "disabledDate";
    "dateRender": "dateRender";
    "selectedValue": "selectedValue";
    "hoverValue": "hoverValue";
    "panelMode": "panelMode";
    "value": "value";
}, {
    "panelModeChange": "panelModeChange";
    "headerChange": "headerChange";
    "selectDate": "selectDate";
    "selectTime": "selectTime";
    "dayHover": "dayHover";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5uZXItcG9wdXAuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbImlubmVyLXBvcHVwLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7QUFXQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIsIFRlbXBsYXRlUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDYW5keURhdGUsIEZ1bmN0aW9uUHJvcCB9IGZyb20gJ25nLXpvcnJvLWFudGQvY29yZSc7XG5pbXBvcnQgeyBOekNhbGVuZGFySTE4bkludGVyZmFjZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvaTE4bic7XG5pbXBvcnQgeyBEaXNhYmxlZERhdGVGbiwgUGFuZWxNb2RlIH0gZnJvbSAnLi4vLi4vc3RhbmRhcmQtdHlwZXMnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgSW5uZXJQb3B1cENvbXBvbmVudCB7XG4gICAgc2hvd1dlZWs6IGJvb2xlYW47XG4gICAgbG9jYWxlOiBOekNhbGVuZGFySTE4bkludGVyZmFjZTtcbiAgICBzaG93VGltZVBpY2tlcjogYm9vbGVhbjtcbiAgICB0aW1lT3B0aW9uczogYW55O1xuICAgIGVuYWJsZVByZXY6IGJvb2xlYW47XG4gICAgZW5hYmxlTmV4dDogYm9vbGVhbjtcbiAgICBkaXNhYmxlZERhdGU6IERpc2FibGVkRGF0ZUZuO1xuICAgIGRhdGVSZW5kZXI6IEZ1bmN0aW9uUHJvcDxUZW1wbGF0ZVJlZjxEYXRlPiB8IHN0cmluZz47XG4gICAgc2VsZWN0ZWRWYWx1ZTogQ2FuZHlEYXRlW107XG4gICAgaG92ZXJWYWx1ZTogQ2FuZHlEYXRlW107XG4gICAgcGFuZWxNb2RlOiBQYW5lbE1vZGU7XG4gICAgcmVhZG9ubHkgcGFuZWxNb2RlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8UGFuZWxNb2RlPjtcbiAgICB2YWx1ZTogQ2FuZHlEYXRlO1xuICAgIHJlYWRvbmx5IGhlYWRlckNoYW5nZTogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZT47XG4gICAgcmVhZG9ubHkgc2VsZWN0RGF0ZTogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZT47XG4gICAgcmVhZG9ubHkgc2VsZWN0VGltZTogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZT47XG4gICAgcmVhZG9ubHkgZGF5SG92ZXI6IEV2ZW50RW1pdHRlcjxDYW5keURhdGU+O1xuICAgIHByZWZpeENsczogc3RyaW5nO1xuICAgIG9uU2VsZWN0VGltZShkYXRlOiBEYXRlKTogdm9pZDtcbiAgICBvblNlbGVjdERhdGUoZGF0ZTogQ2FuZHlEYXRlIHwgRGF0ZSk6IHZvaWQ7XG59XG4iXX0=