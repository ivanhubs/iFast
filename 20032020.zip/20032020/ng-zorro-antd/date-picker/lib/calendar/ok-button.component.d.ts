/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter } from '@angular/core';
import { NzCalendarI18nInterface } from 'ng-zorro-antd/i18n';
import * as ɵngcc0 from '@angular/core';
export declare class OkButtonComponent {
    locale: NzCalendarI18nInterface;
    okDisabled: boolean;
    readonly clickOk: EventEmitter<void>;
    prefixCls: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<OkButtonComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<OkButtonComponent, "ok-button", ["okButton"], {
    "okDisabled": "okDisabled";
    "locale": "locale";
}, {
    "clickOk": "clickOk";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2stYnV0dG9uLmNvbXBvbmVudC5kLnRzIiwic291cmNlcyI6WyJvay1idXR0b24uY29tcG9uZW50LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7QUFTQTs7Ozs7Ozs7Ozs7O0FBS0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTnpDYWxlbmRhckkxOG5JbnRlcmZhY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL2kxOG4nO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgT2tCdXR0b25Db21wb25lbnQge1xuICAgIGxvY2FsZTogTnpDYWxlbmRhckkxOG5JbnRlcmZhY2U7XG4gICAgb2tEaXNhYmxlZDogYm9vbGVhbjtcbiAgICByZWFkb25seSBjbGlja09rOiBFdmVudEVtaXR0ZXI8dm9pZD47XG4gICAgcHJlZml4Q2xzOiBzdHJpbmc7XG59XG4iXX0=