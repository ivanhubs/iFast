/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { DateHelperService, NzCalendarI18nInterface } from 'ng-zorro-antd/i18n';
import { CandyDate } from 'ng-zorro-antd/core';
import { PanelMode } from '../../standard-types';
import * as ɵngcc0 from '@angular/core';
export declare class CalendarHeaderComponent implements OnInit, OnChanges {
    private dateHelper;
    locale: NzCalendarI18nInterface;
    enablePrev: boolean;
    enableNext: boolean;
    disabledMonth: (date: Date) => boolean;
    disabledYear: (date: Date) => boolean;
    showTimePicker: boolean;
    value: CandyDate;
    readonly valueChange: EventEmitter<CandyDate>;
    panelMode: PanelMode;
    readonly panelModeChange: EventEmitter<PanelMode>;
    readonly chooseDecade: EventEmitter<CandyDate>;
    readonly chooseYear: EventEmitter<CandyDate>;
    readonly chooseMonth: EventEmitter<CandyDate>;
    prefixCls: string;
    yearMonthDaySelectors: YearMonthDaySelector[];
    private yearToMonth;
    constructor(dateHelper: DateHelperService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    previousYear(): void;
    nextYear(): void;
    previousMonth(): void;
    nextMonth(): void;
    changePanel(mode: PanelMode, value?: CandyDate): void;
    onChooseDecade(value: CandyDate): void;
    onChooseYear(value: CandyDate): void;
    onChooseMonth(value: CandyDate): void;
    changeToMonthPanel(): void;
    private render;
    private gotoMonth;
    private gotoYear;
    private changeValueFromInside;
    private formatDateTime;
    private createYearMonthDaySelectors;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CalendarHeaderComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<CalendarHeaderComponent, "calendar-header", ["calendarHeader"], {
    "enablePrev": "enablePrev";
    "enableNext": "enableNext";
    "showTimePicker": "showTimePicker";
    "value": "value";
    "locale": "locale";
    "disabledMonth": "disabledMonth";
    "disabledYear": "disabledYear";
    "panelMode": "panelMode";
}, {
    "valueChange": "valueChange";
    "panelModeChange": "panelModeChange";
    "chooseDecade": "chooseDecade";
    "chooseYear": "chooseYear";
    "chooseMonth": "chooseMonth";
}, never>;
}
export interface YearMonthDaySelector {
    className: string;
    title?: string;
    label: string;
    onClick?(): void;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXItaGVhZGVyLmNvbXBvbmVudC5kLnRzIiwic291cmNlcyI6WyJjYWxlbmRhci1oZWFkZXIuY29tcG9uZW50LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7OztBQVdBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9DQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyLCBPbkNoYW5nZXMsIE9uSW5pdCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRGF0ZUhlbHBlclNlcnZpY2UsIE56Q2FsZW5kYXJJMThuSW50ZXJmYWNlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9pMThuJztcbmltcG9ydCB7IENhbmR5RGF0ZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvY29yZSc7XG5pbXBvcnQgeyBQYW5lbE1vZGUgfSBmcm9tICcuLi8uLi9zdGFuZGFyZC10eXBlcyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBDYWxlbmRhckhlYWRlckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgICBwcml2YXRlIGRhdGVIZWxwZXI7XG4gICAgbG9jYWxlOiBOekNhbGVuZGFySTE4bkludGVyZmFjZTtcbiAgICBlbmFibGVQcmV2OiBib29sZWFuO1xuICAgIGVuYWJsZU5leHQ6IGJvb2xlYW47XG4gICAgZGlzYWJsZWRNb250aDogKGRhdGU6IERhdGUpID0+IGJvb2xlYW47XG4gICAgZGlzYWJsZWRZZWFyOiAoZGF0ZTogRGF0ZSkgPT4gYm9vbGVhbjtcbiAgICBzaG93VGltZVBpY2tlcjogYm9vbGVhbjtcbiAgICB2YWx1ZTogQ2FuZHlEYXRlO1xuICAgIHJlYWRvbmx5IHZhbHVlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Q2FuZHlEYXRlPjtcbiAgICBwYW5lbE1vZGU6IFBhbmVsTW9kZTtcbiAgICByZWFkb25seSBwYW5lbE1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxQYW5lbE1vZGU+O1xuICAgIHJlYWRvbmx5IGNob29zZURlY2FkZTogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZT47XG4gICAgcmVhZG9ubHkgY2hvb3NlWWVhcjogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZT47XG4gICAgcmVhZG9ubHkgY2hvb3NlTW9udGg6IEV2ZW50RW1pdHRlcjxDYW5keURhdGU+O1xuICAgIHByZWZpeENsczogc3RyaW5nO1xuICAgIHllYXJNb250aERheVNlbGVjdG9yczogWWVhck1vbnRoRGF5U2VsZWN0b3JbXTtcbiAgICBwcml2YXRlIHllYXJUb01vbnRoO1xuICAgIGNvbnN0cnVjdG9yKGRhdGVIZWxwZXI6IERhdGVIZWxwZXJTZXJ2aWNlKTtcbiAgICBuZ09uSW5pdCgpOiB2b2lkO1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkO1xuICAgIHByZXZpb3VzWWVhcigpOiB2b2lkO1xuICAgIG5leHRZZWFyKCk6IHZvaWQ7XG4gICAgcHJldmlvdXNNb250aCgpOiB2b2lkO1xuICAgIG5leHRNb250aCgpOiB2b2lkO1xuICAgIGNoYW5nZVBhbmVsKG1vZGU6IFBhbmVsTW9kZSwgdmFsdWU/OiBDYW5keURhdGUpOiB2b2lkO1xuICAgIG9uQ2hvb3NlRGVjYWRlKHZhbHVlOiBDYW5keURhdGUpOiB2b2lkO1xuICAgIG9uQ2hvb3NlWWVhcih2YWx1ZTogQ2FuZHlEYXRlKTogdm9pZDtcbiAgICBvbkNob29zZU1vbnRoKHZhbHVlOiBDYW5keURhdGUpOiB2b2lkO1xuICAgIGNoYW5nZVRvTW9udGhQYW5lbCgpOiB2b2lkO1xuICAgIHByaXZhdGUgcmVuZGVyO1xuICAgIHByaXZhdGUgZ290b01vbnRoO1xuICAgIHByaXZhdGUgZ290b1llYXI7XG4gICAgcHJpdmF0ZSBjaGFuZ2VWYWx1ZUZyb21JbnNpZGU7XG4gICAgcHJpdmF0ZSBmb3JtYXREYXRlVGltZTtcbiAgICBwcml2YXRlIGNyZWF0ZVllYXJNb250aERheVNlbGVjdG9ycztcbn1cbmV4cG9ydCBpbnRlcmZhY2UgWWVhck1vbnRoRGF5U2VsZWN0b3Ige1xuICAgIGNsYXNzTmFtZTogc3RyaW5nO1xuICAgIHRpdGxlPzogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgb25DbGljaz8oKTogdm9pZDtcbn1cbiJdfQ==