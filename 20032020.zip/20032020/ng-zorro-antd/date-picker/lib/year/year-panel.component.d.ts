/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CandyDate } from 'ng-zorro-antd/core';
import { NzCalendarI18nInterface } from 'ng-zorro-antd/i18n';
import * as ɵngcc0 from '@angular/core';
export declare class YearPanelComponent implements OnChanges {
    locale: NzCalendarI18nInterface;
    value: CandyDate;
    readonly valueChange: EventEmitter<CandyDate>;
    disabledDate: (date: Date) => boolean;
    readonly decadePanelShow: EventEmitter<void>;
    readonly currentYear: number;
    readonly startYear: number;
    readonly endYear: number;
    prefixCls: string;
    panelYears: PanelYearData[][];
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    previousDecade(): void;
    nextDecade(): void;
    trackPanelYear(_index: number, yearData: PanelYearData): string;
    private render;
    private gotoYear;
    private chooseYear;
    private makePanelYears;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<YearPanelComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<YearPanelComponent, "year-panel", ["yearPanel"], {
    "value": "value";
    "locale": "locale";
    "disabledDate": "disabledDate";
}, {
    "valueChange": "valueChange";
    "decadePanelShow": "decadePanelShow";
}, never>;
}
export interface PanelYearData {
    disabled: boolean;
    content: string;
    year: number;
    title: string;
    isCurrent: boolean;
    isLowerThanStart: boolean;
    isBiggerThanEnd: boolean;
    classMap: object | null;
    onClick: VoidFunction | null;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoieWVhci1wYW5lbC5jb21wb25lbnQuZC50cyIsInNvdXJjZXMiOlsieWVhci1wYW5lbC5jb21wb25lbnQuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7QUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IEV2ZW50RW1pdHRlciwgT25DaGFuZ2VzLCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDYW5keURhdGUgfSBmcm9tICduZy16b3Jyby1hbnRkL2NvcmUnO1xuaW1wb3J0IHsgTnpDYWxlbmRhckkxOG5JbnRlcmZhY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL2kxOG4nO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgWWVhclBhbmVsQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzIHtcbiAgICBsb2NhbGU6IE56Q2FsZW5kYXJJMThuSW50ZXJmYWNlO1xuICAgIHZhbHVlOiBDYW5keURhdGU7XG4gICAgcmVhZG9ubHkgdmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxDYW5keURhdGU+O1xuICAgIGRpc2FibGVkRGF0ZTogKGRhdGU6IERhdGUpID0+IGJvb2xlYW47XG4gICAgcmVhZG9ubHkgZGVjYWRlUGFuZWxTaG93OiBFdmVudEVtaXR0ZXI8dm9pZD47XG4gICAgcmVhZG9ubHkgY3VycmVudFllYXI6IG51bWJlcjtcbiAgICByZWFkb25seSBzdGFydFllYXI6IG51bWJlcjtcbiAgICByZWFkb25seSBlbmRZZWFyOiBudW1iZXI7XG4gICAgcHJlZml4Q2xzOiBzdHJpbmc7XG4gICAgcGFuZWxZZWFyczogUGFuZWxZZWFyRGF0YVtdW107XG4gICAgY29uc3RydWN0b3IoKTtcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZDtcbiAgICBwcmV2aW91c0RlY2FkZSgpOiB2b2lkO1xuICAgIG5leHREZWNhZGUoKTogdm9pZDtcbiAgICB0cmFja1BhbmVsWWVhcihfaW5kZXg6IG51bWJlciwgeWVhckRhdGE6IFBhbmVsWWVhckRhdGEpOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSByZW5kZXI7XG4gICAgcHJpdmF0ZSBnb3RvWWVhcjtcbiAgICBwcml2YXRlIGNob29zZVllYXI7XG4gICAgcHJpdmF0ZSBtYWtlUGFuZWxZZWFycztcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUGFuZWxZZWFyRGF0YSB7XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgY29udGVudDogc3RyaW5nO1xuICAgIHllYXI6IG51bWJlcjtcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIGlzQ3VycmVudDogYm9vbGVhbjtcbiAgICBpc0xvd2VyVGhhblN0YXJ0OiBib29sZWFuO1xuICAgIGlzQmlnZ2VyVGhhbkVuZDogYm9vbGVhbjtcbiAgICBjbGFzc01hcDogb2JqZWN0IHwgbnVsbDtcbiAgICBvbkNsaWNrOiBWb2lkRnVuY3Rpb24gfCBudWxsO1xufVxuIl19