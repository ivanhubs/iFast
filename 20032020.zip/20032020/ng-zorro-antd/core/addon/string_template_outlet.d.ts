/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { OnChanges, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzStringTemplateOutletDirective implements OnChanges {
    private viewContainer;
    private defaultTemplate;
    private isTemplate;
    private inputTemplate;
    private inputViewRef;
    private defaultViewRef;
    nzStringTemplateOutletContext: any | null;
    nzStringTemplateOutlet: string | TemplateRef<any>;
    recreateView(): void;
    private getType;
    private shouldRecreateView;
    private hasContextShapeChanged;
    private updateExistingContext;
    constructor(viewContainer: ViewContainerRef, defaultTemplate: TemplateRef<void>);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzStringTemplateOutletDirective>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NzStringTemplateOutletDirective, "[nzStringTemplateOutlet]", ["nzStringTemplateOutlet"], {
    "nzStringTemplateOutletContext": "nzStringTemplateOutletContext";
    "nzStringTemplateOutlet": "nzStringTemplateOutlet";
}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RyaW5nX3RlbXBsYXRlX291dGxldC5kLnRzIiwic291cmNlcyI6WyJzdHJpbmdfdGVtcGxhdGVfb3V0bGV0LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7OztBQVFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcywgVGVtcGxhdGVSZWYsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56U3RyaW5nVGVtcGxhdGVPdXRsZXREaXJlY3RpdmUgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAgIHByaXZhdGUgdmlld0NvbnRhaW5lcjtcbiAgICBwcml2YXRlIGRlZmF1bHRUZW1wbGF0ZTtcbiAgICBwcml2YXRlIGlzVGVtcGxhdGU7XG4gICAgcHJpdmF0ZSBpbnB1dFRlbXBsYXRlO1xuICAgIHByaXZhdGUgaW5wdXRWaWV3UmVmO1xuICAgIHByaXZhdGUgZGVmYXVsdFZpZXdSZWY7XG4gICAgbnpTdHJpbmdUZW1wbGF0ZU91dGxldENvbnRleHQ6IGFueSB8IG51bGw7XG4gICAgbnpTdHJpbmdUZW1wbGF0ZU91dGxldDogc3RyaW5nIHwgVGVtcGxhdGVSZWY8YW55PjtcbiAgICByZWNyZWF0ZVZpZXcoKTogdm9pZDtcbiAgICBwcml2YXRlIGdldFR5cGU7XG4gICAgcHJpdmF0ZSBzaG91bGRSZWNyZWF0ZVZpZXc7XG4gICAgcHJpdmF0ZSBoYXNDb250ZXh0U2hhcGVDaGFuZ2VkO1xuICAgIHByaXZhdGUgdXBkYXRlRXhpc3RpbmdDb250ZXh0O1xuICAgIGNvbnN0cnVjdG9yKHZpZXdDb250YWluZXI6IFZpZXdDb250YWluZXJSZWYsIGRlZmF1bHRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8dm9pZD4pO1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkO1xufVxuIl19