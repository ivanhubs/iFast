/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './string_template_outlet';
import * as ɵngcc2 from './classlist_add';
import * as ɵngcc3 from '@angular/common';
export declare class NzAddOnModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzAddOnModule, [typeof ɵngcc1.NzStringTemplateOutletDirective, typeof ɵngcc2.NzClassListAddDirective], [typeof ɵngcc3.CommonModule], [typeof ɵngcc1.NzStringTemplateOutletDirective, typeof ɵngcc2.NzClassListAddDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzAddOnModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkb24ubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbImFkZG9uLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztBQU9BOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpBZGRPbk1vZHVsZSB7XG59XG4iXX0=