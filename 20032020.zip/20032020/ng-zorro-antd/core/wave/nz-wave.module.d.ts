/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-wave.directive';
import * as ɵngcc2 from '@angular/cdk/platform';
export declare class NzWaveModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzWaveModule, [typeof ɵngcc1.NzWaveDirective], [typeof ɵngcc2.PlatformModule], [typeof ɵngcc1.NzWaveDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzWaveModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotd2F2ZS5tb2R1bGUuZC50cyIsInNvdXJjZXMiOlsibnotd2F2ZS5tb2R1bGUuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7OztBQU9BOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpXYXZlTW9kdWxlIHtcbn1cbiJdfQ==