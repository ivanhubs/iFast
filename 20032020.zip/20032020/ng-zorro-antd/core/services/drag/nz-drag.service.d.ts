/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { RendererFactory2 } from '@angular/core';
import { Observable } from 'rxjs';
import * as ɵngcc0 from '@angular/core';
interface Point {
    x: number;
    y: number;
}
declare type Delta = Point;
/**
 * This module provide a global dragging service to other components.
 */
export declare class NzDragService {
    private draggingThreshold;
    private currentDraggingSequence;
    private currentStartingPoint;
    private handleRegistry;
    private renderer;
    constructor(rendererFactory2: RendererFactory2);
    requestDraggingSequence(event: MouseEvent | TouchEvent): Observable<Delta>;
    private registerDraggingHandler;
    private teardownDraggingSequence;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzDragService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzDragService>;
}
export {};

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZHJhZy5zZXJ2aWNlLmQudHMiLCJzb3VyY2VzIjpbIm56LWRyYWcuc2VydmljZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7O0FBU0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5pbXBvcnQgeyBSZW5kZXJlckZhY3RvcnkyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbnRlcmZhY2UgUG9pbnQge1xuICAgIHg6IG51bWJlcjtcbiAgICB5OiBudW1iZXI7XG59XG5kZWNsYXJlIHR5cGUgRGVsdGEgPSBQb2ludDtcbi8qKlxuICogVGhpcyBtb2R1bGUgcHJvdmlkZSBhIGdsb2JhbCBkcmFnZ2luZyBzZXJ2aWNlIHRvIG90aGVyIGNvbXBvbmVudHMuXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56RHJhZ1NlcnZpY2Uge1xuICAgIHByaXZhdGUgZHJhZ2dpbmdUaHJlc2hvbGQ7XG4gICAgcHJpdmF0ZSBjdXJyZW50RHJhZ2dpbmdTZXF1ZW5jZTtcbiAgICBwcml2YXRlIGN1cnJlbnRTdGFydGluZ1BvaW50O1xuICAgIHByaXZhdGUgaGFuZGxlUmVnaXN0cnk7XG4gICAgcHJpdmF0ZSByZW5kZXJlcjtcbiAgICBjb25zdHJ1Y3RvcihyZW5kZXJlckZhY3RvcnkyOiBSZW5kZXJlckZhY3RvcnkyKTtcbiAgICByZXF1ZXN0RHJhZ2dpbmdTZXF1ZW5jZShldmVudDogTW91c2VFdmVudCB8IFRvdWNoRXZlbnQpOiBPYnNlcnZhYmxlPERlbHRhPjtcbiAgICBwcml2YXRlIHJlZ2lzdGVyRHJhZ2dpbmdIYW5kbGVyO1xuICAgIHByaXZhdGUgdGVhcmRvd25EcmFnZ2luZ1NlcXVlbmNlO1xufVxuZXhwb3J0IHt9O1xuIl19