/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
export declare class NzCopyToClipboardService {
    private document;
    constructor(document: any);
    copy(text: string): Promise<string>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCopyToClipboardService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzCopyToClipboardService>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY29weS10by1jbGlwYm9hcmQuc2VydmljZS5kLnRzIiwic291cmNlcyI6WyJuei1jb3B5LXRvLWNsaXBib2FyZC5zZXJ2aWNlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O0FBT0E7Ozs7OztBQUlBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekNvcHlUb0NsaXBib2FyZFNlcnZpY2Uge1xuICAgIHByaXZhdGUgZG9jdW1lbnQ7XG4gICAgY29uc3RydWN0b3IoZG9jdW1lbnQ6IGFueSk7XG4gICAgY29weSh0ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz47XG59XG4iXX0=