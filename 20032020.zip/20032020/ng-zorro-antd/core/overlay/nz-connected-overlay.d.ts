/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { CdkConnectedOverlay } from '@angular/cdk/overlay';
import * as ɵngcc0 from '@angular/core';
export declare class NzConnectedOverlayDirective {
    private cdkConnectedOverlay;
    constructor(cdkConnectedOverlay: CdkConnectedOverlay);
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzConnectedOverlayDirective>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NzConnectedOverlayDirective, "[cdkConnectedOverlay][nzConnectedOverlay]", ["nzConnectedOverlay"], {}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY29ubmVjdGVkLW92ZXJsYXkuZC50cyIsInNvdXJjZXMiOlsibnotY29ubmVjdGVkLW92ZXJsYXkuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7O0FBUUE7Ozs7O0FBR0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IENka0Nvbm5lY3RlZE92ZXJsYXkgfSBmcm9tICdAYW5ndWxhci9jZGsvb3ZlcmxheSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekNvbm5lY3RlZE92ZXJsYXlEaXJlY3RpdmUge1xuICAgIHByaXZhdGUgY2RrQ29ubmVjdGVkT3ZlcmxheTtcbiAgICBjb25zdHJ1Y3RvcihjZGtDb25uZWN0ZWRPdmVybGF5OiBDZGtDb25uZWN0ZWRPdmVybGF5KTtcbn1cbiJdfQ==