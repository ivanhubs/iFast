/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { OnDestroy } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { NzTreeNode } from './nz-tree-base-node';
import { NzFormatEmitEvent } from './nz-tree-base.definitions';
import * as ɵngcc0 from '@angular/core';
export declare class NzTreeBaseService implements OnDestroy {
    DRAG_SIDE_RANGE: number;
    DRAG_MIN_GAP: number;
    isCheckStrictly: boolean;
    isMultiple: boolean;
    selectedNode: NzTreeNode;
    rootNodes: NzTreeNode[];
    selectedNodeList: NzTreeNode[];
    expandedNodeList: NzTreeNode[];
    checkedNodeList: NzTreeNode[];
    halfCheckedNodeList: NzTreeNode[];
    matchedNodeList: NzTreeNode[];
    triggerEventChange$: Subject<NzFormatEmitEvent>;
    /**
     * trigger event
     */
    eventTriggerChanged(): Observable<NzFormatEmitEvent>;
    /**
     * reset tree nodes will clear default node list
     */
    initTree(nzNodes: NzTreeNode[]): void;
    getSelectedNode(): NzTreeNode | null;
    /**
     * get some list
     */
    getSelectedNodeList(): NzTreeNode[];
    /**
     * return checked nodes
     */
    getCheckedNodeList(): NzTreeNode[];
    getHalfCheckedNodeList(): NzTreeNode[];
    /**
     * return expanded nodes
     */
    getExpandedNodeList(): NzTreeNode[];
    /**
     * return search matched nodes
     */
    getMatchedNodeList(): NzTreeNode[];
    isArrayOfNzTreeNode(value: any[]): boolean;
    /**
     * reset selectedNodeList
     */
    calcSelectedKeys(selectedKeys: string[], nzNodes: NzTreeNode[], isMulti?: boolean): void;
    /**
     * reset expandedNodeList
     */
    calcExpandedKeys(expandedKeys: string[], nzNodes: NzTreeNode[]): void;
    /**
     * reset checkedNodeList
     */
    calcCheckedKeys(checkedKeys: string[], nzNodes: NzTreeNode[], isCheckStrictly?: boolean): void;
    /**
     * set drag node
     */
    setSelectedNode(node: NzTreeNode): void;
    /**
     * set node selected status
     */
    setNodeActive(node: NzTreeNode): void;
    /**
     * add or remove node to selectedNodeList
     */
    setSelectedNodeList(node: NzTreeNode, isMultiple?: boolean): void;
    /**
     * merge checked nodes
     */
    setHalfCheckedNodeList(node: NzTreeNode): void;
    setCheckedNodeList(node: NzTreeNode): void;
    /**
     * conduct checked/selected/expanded keys
     */
    conductNodeState(type?: string): NzTreeNode[];
    /**
     * set expanded nodes
     */
    setExpandedNodeList(node: NzTreeNode): void;
    /**
     * check state
     * @param isCheckStrictly
     */
    refreshCheckState(isCheckStrictly?: boolean): void;
    conduct(node: NzTreeNode): void;
    /**
     * 1、children half checked
     * 2、children all checked, parent checked
     * 3、no children checked
     */
    conductUp(node: NzTreeNode): void;
    /**
     * reset child check state
     */
    conductDown(node: NzTreeNode, value: boolean): void;
    /**
     * search value & expand node
     * should add expandlist
     */
    searchExpand(value: string): void;
    /**
     * flush after delete node
     */
    afterRemove(nodes: NzTreeNode[]): void;
    /**
     * drag event
     */
    refreshDragNode(node: NzTreeNode): void;
    resetNodeLevel(node: NzTreeNode): void;
    calcDropPosition(event: DragEvent): number;
    /**
     * drop
     * 0: inner -1: pre 1: next
     */
    dropAndApply(targetNode: NzTreeNode, dragPos?: number): void;
    /**
     * emit Structure
     * eventName
     * node
     * event: MouseEvent / DragEvent
     * dragNode
     */
    formatEvent(eventName: string, node: NzTreeNode | null, event: MouseEvent | DragEvent | null): NzFormatEmitEvent;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzTreeBaseService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzTreeBaseService>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotdHJlZS1iYXNlLnNlcnZpY2UuZC50cyIsInNvdXJjZXMiOlsibnotdHJlZS1iYXNlLnNlcnZpY2UuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7O0FBV0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEwSEEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgTnpUcmVlTm9kZSB9IGZyb20gJy4vbnotdHJlZS1iYXNlLW5vZGUnO1xuaW1wb3J0IHsgTnpGb3JtYXRFbWl0RXZlbnQgfSBmcm9tICcuL256LXRyZWUtYmFzZS5kZWZpbml0aW9ucyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOelRyZWVCYXNlU2VydmljZSBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG4gICAgRFJBR19TSURFX1JBTkdFOiBudW1iZXI7XG4gICAgRFJBR19NSU5fR0FQOiBudW1iZXI7XG4gICAgaXNDaGVja1N0cmljdGx5OiBib29sZWFuO1xuICAgIGlzTXVsdGlwbGU6IGJvb2xlYW47XG4gICAgc2VsZWN0ZWROb2RlOiBOelRyZWVOb2RlO1xuICAgIHJvb3ROb2RlczogTnpUcmVlTm9kZVtdO1xuICAgIHNlbGVjdGVkTm9kZUxpc3Q6IE56VHJlZU5vZGVbXTtcbiAgICBleHBhbmRlZE5vZGVMaXN0OiBOelRyZWVOb2RlW107XG4gICAgY2hlY2tlZE5vZGVMaXN0OiBOelRyZWVOb2RlW107XG4gICAgaGFsZkNoZWNrZWROb2RlTGlzdDogTnpUcmVlTm9kZVtdO1xuICAgIG1hdGNoZWROb2RlTGlzdDogTnpUcmVlTm9kZVtdO1xuICAgIHRyaWdnZXJFdmVudENoYW5nZSQ6IFN1YmplY3Q8TnpGb3JtYXRFbWl0RXZlbnQ+O1xuICAgIC8qKlxuICAgICAqIHRyaWdnZXIgZXZlbnRcbiAgICAgKi9cbiAgICBldmVudFRyaWdnZXJDaGFuZ2VkKCk6IE9ic2VydmFibGU8TnpGb3JtYXRFbWl0RXZlbnQ+O1xuICAgIC8qKlxuICAgICAqIHJlc2V0IHRyZWUgbm9kZXMgd2lsbCBjbGVhciBkZWZhdWx0IG5vZGUgbGlzdFxuICAgICAqL1xuICAgIGluaXRUcmVlKG56Tm9kZXM6IE56VHJlZU5vZGVbXSk6IHZvaWQ7XG4gICAgZ2V0U2VsZWN0ZWROb2RlKCk6IE56VHJlZU5vZGUgfCBudWxsO1xuICAgIC8qKlxuICAgICAqIGdldCBzb21lIGxpc3RcbiAgICAgKi9cbiAgICBnZXRTZWxlY3RlZE5vZGVMaXN0KCk6IE56VHJlZU5vZGVbXTtcbiAgICAvKipcbiAgICAgKiByZXR1cm4gY2hlY2tlZCBub2Rlc1xuICAgICAqL1xuICAgIGdldENoZWNrZWROb2RlTGlzdCgpOiBOelRyZWVOb2RlW107XG4gICAgZ2V0SGFsZkNoZWNrZWROb2RlTGlzdCgpOiBOelRyZWVOb2RlW107XG4gICAgLyoqXG4gICAgICogcmV0dXJuIGV4cGFuZGVkIG5vZGVzXG4gICAgICovXG4gICAgZ2V0RXhwYW5kZWROb2RlTGlzdCgpOiBOelRyZWVOb2RlW107XG4gICAgLyoqXG4gICAgICogcmV0dXJuIHNlYXJjaCBtYXRjaGVkIG5vZGVzXG4gICAgICovXG4gICAgZ2V0TWF0Y2hlZE5vZGVMaXN0KCk6IE56VHJlZU5vZGVbXTtcbiAgICBpc0FycmF5T2ZOelRyZWVOb2RlKHZhbHVlOiBhbnlbXSk6IGJvb2xlYW47XG4gICAgLyoqXG4gICAgICogcmVzZXQgc2VsZWN0ZWROb2RlTGlzdFxuICAgICAqL1xuICAgIGNhbGNTZWxlY3RlZEtleXMoc2VsZWN0ZWRLZXlzOiBzdHJpbmdbXSwgbnpOb2RlczogTnpUcmVlTm9kZVtdLCBpc011bHRpPzogYm9vbGVhbik6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogcmVzZXQgZXhwYW5kZWROb2RlTGlzdFxuICAgICAqL1xuICAgIGNhbGNFeHBhbmRlZEtleXMoZXhwYW5kZWRLZXlzOiBzdHJpbmdbXSwgbnpOb2RlczogTnpUcmVlTm9kZVtdKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiByZXNldCBjaGVja2VkTm9kZUxpc3RcbiAgICAgKi9cbiAgICBjYWxjQ2hlY2tlZEtleXMoY2hlY2tlZEtleXM6IHN0cmluZ1tdLCBuek5vZGVzOiBOelRyZWVOb2RlW10sIGlzQ2hlY2tTdHJpY3RseT86IGJvb2xlYW4pOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIHNldCBkcmFnIG5vZGVcbiAgICAgKi9cbiAgICBzZXRTZWxlY3RlZE5vZGUobm9kZTogTnpUcmVlTm9kZSk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogc2V0IG5vZGUgc2VsZWN0ZWQgc3RhdHVzXG4gICAgICovXG4gICAgc2V0Tm9kZUFjdGl2ZShub2RlOiBOelRyZWVOb2RlKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBhZGQgb3IgcmVtb3ZlIG5vZGUgdG8gc2VsZWN0ZWROb2RlTGlzdFxuICAgICAqL1xuICAgIHNldFNlbGVjdGVkTm9kZUxpc3Qobm9kZTogTnpUcmVlTm9kZSwgaXNNdWx0aXBsZT86IGJvb2xlYW4pOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIG1lcmdlIGNoZWNrZWQgbm9kZXNcbiAgICAgKi9cbiAgICBzZXRIYWxmQ2hlY2tlZE5vZGVMaXN0KG5vZGU6IE56VHJlZU5vZGUpOiB2b2lkO1xuICAgIHNldENoZWNrZWROb2RlTGlzdChub2RlOiBOelRyZWVOb2RlKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBjb25kdWN0IGNoZWNrZWQvc2VsZWN0ZWQvZXhwYW5kZWQga2V5c1xuICAgICAqL1xuICAgIGNvbmR1Y3ROb2RlU3RhdGUodHlwZT86IHN0cmluZyk6IE56VHJlZU5vZGVbXTtcbiAgICAvKipcbiAgICAgKiBzZXQgZXhwYW5kZWQgbm9kZXNcbiAgICAgKi9cbiAgICBzZXRFeHBhbmRlZE5vZGVMaXN0KG5vZGU6IE56VHJlZU5vZGUpOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIGNoZWNrIHN0YXRlXG4gICAgICogQHBhcmFtIGlzQ2hlY2tTdHJpY3RseVxuICAgICAqL1xuICAgIHJlZnJlc2hDaGVja1N0YXRlKGlzQ2hlY2tTdHJpY3RseT86IGJvb2xlYW4pOiB2b2lkO1xuICAgIGNvbmR1Y3Qobm9kZTogTnpUcmVlTm9kZSk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogMeOAgWNoaWxkcmVuIGhhbGYgY2hlY2tlZFxuICAgICAqIDLjgIFjaGlsZHJlbiBhbGwgY2hlY2tlZCwgcGFyZW50IGNoZWNrZWRcbiAgICAgKiAz44CBbm8gY2hpbGRyZW4gY2hlY2tlZFxuICAgICAqL1xuICAgIGNvbmR1Y3RVcChub2RlOiBOelRyZWVOb2RlKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiByZXNldCBjaGlsZCBjaGVjayBzdGF0ZVxuICAgICAqL1xuICAgIGNvbmR1Y3REb3duKG5vZGU6IE56VHJlZU5vZGUsIHZhbHVlOiBib29sZWFuKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBzZWFyY2ggdmFsdWUgJiBleHBhbmQgbm9kZVxuICAgICAqIHNob3VsZCBhZGQgZXhwYW5kbGlzdFxuICAgICAqL1xuICAgIHNlYXJjaEV4cGFuZCh2YWx1ZTogc3RyaW5nKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBmbHVzaCBhZnRlciBkZWxldGUgbm9kZVxuICAgICAqL1xuICAgIGFmdGVyUmVtb3ZlKG5vZGVzOiBOelRyZWVOb2RlW10pOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIGRyYWcgZXZlbnRcbiAgICAgKi9cbiAgICByZWZyZXNoRHJhZ05vZGUobm9kZTogTnpUcmVlTm9kZSk6IHZvaWQ7XG4gICAgcmVzZXROb2RlTGV2ZWwobm9kZTogTnpUcmVlTm9kZSk6IHZvaWQ7XG4gICAgY2FsY0Ryb3BQb3NpdGlvbihldmVudDogRHJhZ0V2ZW50KTogbnVtYmVyO1xuICAgIC8qKlxuICAgICAqIGRyb3BcbiAgICAgKiAwOiBpbm5lciAtMTogcHJlIDE6IG5leHRcbiAgICAgKi9cbiAgICBkcm9wQW5kQXBwbHkodGFyZ2V0Tm9kZTogTnpUcmVlTm9kZSwgZHJhZ1Bvcz86IG51bWJlcik6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogZW1pdCBTdHJ1Y3R1cmVcbiAgICAgKiBldmVudE5hbWVcbiAgICAgKiBub2RlXG4gICAgICogZXZlbnQ6IE1vdXNlRXZlbnQgLyBEcmFnRXZlbnRcbiAgICAgKiBkcmFnTm9kZVxuICAgICAqL1xuICAgIGZvcm1hdEV2ZW50KGV2ZW50TmFtZTogc3RyaW5nLCBub2RlOiBOelRyZWVOb2RlIHwgbnVsbCwgZXZlbnQ6IE1vdXNlRXZlbnQgfCBEcmFnRXZlbnQgfCBudWxsKTogTnpGb3JtYXRFbWl0RXZlbnQ7XG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZDtcbn1cbiJdfQ==