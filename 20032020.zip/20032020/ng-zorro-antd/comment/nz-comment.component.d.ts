/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { QueryList, TemplateRef } from '@angular/core';
import { NzCommentActionComponent as CommentAction } from './nz-comment-cells';
import * as ɵngcc0 from '@angular/core';
export declare class NzCommentComponent {
    nzAuthor: string | TemplateRef<void>;
    nzDatetime: string | TemplateRef<void>;
    actions: QueryList<CommentAction>;
    constructor();
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCommentComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzCommentComponent, "nz-comment", ["nzComment"], {
    "nzAuthor": "nzAuthor";
    "nzDatetime": "nzDatetime";
}, {}, ["actions"]>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY29tbWVudC5jb21wb25lbnQuZC50cyIsInNvdXJjZXMiOlsibnotY29tbWVudC5jb21wb25lbnQuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7OztBQVNBOzs7Ozs7Ozs7O0FBS0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IFF1ZXJ5TGlzdCwgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE56Q29tbWVudEFjdGlvbkNvbXBvbmVudCBhcyBDb21tZW50QWN0aW9uIH0gZnJvbSAnLi9uei1jb21tZW50LWNlbGxzJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56Q29tbWVudENvbXBvbmVudCB7XG4gICAgbnpBdXRob3I6IHN0cmluZyB8IFRlbXBsYXRlUmVmPHZvaWQ+O1xuICAgIG56RGF0ZXRpbWU6IHN0cmluZyB8IFRlbXBsYXRlUmVmPHZvaWQ+O1xuICAgIGFjdGlvbnM6IFF1ZXJ5TGlzdDxDb21tZW50QWN0aW9uPjtcbiAgICBjb25zdHJ1Y3RvcigpO1xufVxuIl19