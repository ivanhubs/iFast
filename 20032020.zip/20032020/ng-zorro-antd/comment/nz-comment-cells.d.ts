/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { CdkPortalOutlet, TemplatePortal } from '@angular/cdk/portal';
import { AfterViewInit, ComponentFactoryResolver, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzCommentAvatarDirective {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCommentAvatarDirective>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NzCommentAvatarDirective, "nz-avatar[nz-comment-avatar]", ["nzCommentAvatar"], {}, {}, never>;
}
export declare class NzCommentContentDirective {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCommentContentDirective>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NzCommentContentDirective, "nz-comment-content, [nz-comment-content]", ["nzCommentContent"], {}, {}, never>;
}
export declare class NzCommentActionHostDirective extends CdkPortalOutlet implements OnInit, OnDestroy, AfterViewInit {
    nzCommentActionHost: TemplatePortal | null;
    constructor(componentFactoryResolver: ComponentFactoryResolver, viewContainerRef: ViewContainerRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCommentActionHostDirective>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NzCommentActionHostDirective, "[nzCommentActionHost]", ["nzCommentActionHost"], {
    "nzCommentActionHost": "nzCommentActionHost";
}, {}, never>;
}
export declare class NzCommentActionComponent implements OnInit {
    private viewContainerRef;
    implicitContent: TemplateRef<void>;
    private contentPortal;
    readonly content: TemplatePortal | null;
    constructor(viewContainerRef: ViewContainerRef);
    ngOnInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCommentActionComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzCommentActionComponent, "nz-comment-action", ["nzCommentAction"], {}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY29tbWVudC1jZWxscy5kLnRzIiwic291cmNlcyI6WyJuei1jb21tZW50LWNlbGxzLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7QUFTQTs7O0FBQ0E7Ozs7QUFFQTs7Ozs7Ozs7Ozs7QUFPQTs7Ozs7Ozs7OztBQVFBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5pbXBvcnQgeyBDZGtQb3J0YWxPdXRsZXQsIFRlbXBsYXRlUG9ydGFsIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL3BvcnRhbCc7XG5pbXBvcnQgeyBBZnRlclZpZXdJbml0LCBDb21wb25lbnRGYWN0b3J5UmVzb2x2ZXIsIE9uRGVzdHJveSwgT25Jbml0LCBUZW1wbGF0ZVJlZiwgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpDb21tZW50QXZhdGFyRGlyZWN0aXZlIHtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56Q29tbWVudENvbnRlbnREaXJlY3RpdmUge1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpDb21tZW50QWN0aW9uSG9zdERpcmVjdGl2ZSBleHRlbmRzIENka1BvcnRhbE91dGxldCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95LCBBZnRlclZpZXdJbml0IHtcbiAgICBuekNvbW1lbnRBY3Rpb25Ib3N0OiBUZW1wbGF0ZVBvcnRhbCB8IG51bGw7XG4gICAgY29uc3RydWN0b3IoY29tcG9uZW50RmFjdG9yeVJlc29sdmVyOiBDb21wb25lbnRGYWN0b3J5UmVzb2x2ZXIsIHZpZXdDb250YWluZXJSZWY6IFZpZXdDb250YWluZXJSZWYpO1xuICAgIG5nT25Jbml0KCk6IHZvaWQ7XG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZDtcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZDtcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56Q29tbWVudEFjdGlvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgcHJpdmF0ZSB2aWV3Q29udGFpbmVyUmVmO1xuICAgIGltcGxpY2l0Q29udGVudDogVGVtcGxhdGVSZWY8dm9pZD47XG4gICAgcHJpdmF0ZSBjb250ZW50UG9ydGFsO1xuICAgIHJlYWRvbmx5IGNvbnRlbnQ6IFRlbXBsYXRlUG9ydGFsIHwgbnVsbDtcbiAgICBjb25zdHJ1Y3Rvcih2aWV3Q29udGFpbmVyUmVmOiBWaWV3Q29udGFpbmVyUmVmKTtcbiAgICBuZ09uSW5pdCgpOiB2b2lkO1xufVxuIl19