import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-back-top.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/cdk/platform';
export declare class NzBackTopModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzBackTopModule, [typeof ɵngcc1.NzBackTopComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.PlatformModule], [typeof ɵngcc1.NzBackTopComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzBackTopModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYmFjay10b3AubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm56LWJhY2stdG9wLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVjbGFyZSBjbGFzcyBOekJhY2tUb3BNb2R1bGUge1xufVxuIl19