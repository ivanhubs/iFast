/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { ChangeDetectorRef, EventEmitter, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { NzConfigService, NzScrollService } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzBackTopComponent implements OnInit, OnDestroy {
    nzConfigService: NzConfigService;
    private scrollSrv;
    private doc;
    private platform;
    private cd;
    private scroll$;
    private target;
    visible: boolean;
    nzTemplate: TemplateRef<void>;
    nzVisibilityHeight: number;
    nzTarget: string | HTMLElement;
    readonly nzClick: EventEmitter<boolean>;
    constructor(nzConfigService: NzConfigService, scrollSrv: NzScrollService, doc: any, platform: Platform, cd: ChangeDetectorRef);
    ngOnInit(): void;
    clickBackTop(): void;
    private getTarget;
    private handleScroll;
    private removeListen;
    private registerScrollEvent;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzBackTopComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzBackTopComponent, "nz-back-top", ["nzBackTop"], {
    "nzTarget": "nzTarget";
    "nzTemplate": "nzTemplate";
    "nzVisibilityHeight": "nzVisibilityHeight";
}, {
    "nzClick": "nzClick";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYmFjay10b3AuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWJhY2stdG9wLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXFCQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgUGxhdGZvcm0gfSBmcm9tICdAYW5ndWxhci9jZGsvcGxhdGZvcm0nO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0b3JSZWYsIEV2ZW50RW1pdHRlciwgT25EZXN0cm95LCBPbkluaXQsIFRlbXBsYXRlUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOekNvbmZpZ1NlcnZpY2UsIE56U2Nyb2xsU2VydmljZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekJhY2tUb3BDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gICAgbnpDb25maWdTZXJ2aWNlOiBOekNvbmZpZ1NlcnZpY2U7XG4gICAgcHJpdmF0ZSBzY3JvbGxTcnY7XG4gICAgcHJpdmF0ZSBkb2M7XG4gICAgcHJpdmF0ZSBwbGF0Zm9ybTtcbiAgICBwcml2YXRlIGNkO1xuICAgIHByaXZhdGUgc2Nyb2xsJDtcbiAgICBwcml2YXRlIHRhcmdldDtcbiAgICB2aXNpYmxlOiBib29sZWFuO1xuICAgIG56VGVtcGxhdGU6IFRlbXBsYXRlUmVmPHZvaWQ+O1xuICAgIG56VmlzaWJpbGl0eUhlaWdodDogbnVtYmVyO1xuICAgIG56VGFyZ2V0OiBzdHJpbmcgfCBIVE1MRWxlbWVudDtcbiAgICByZWFkb25seSBuekNsaWNrOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj47XG4gICAgY29uc3RydWN0b3IobnpDb25maWdTZXJ2aWNlOiBOekNvbmZpZ1NlcnZpY2UsIHNjcm9sbFNydjogTnpTY3JvbGxTZXJ2aWNlLCBkb2M6IGFueSwgcGxhdGZvcm06IFBsYXRmb3JtLCBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYpO1xuICAgIG5nT25Jbml0KCk6IHZvaWQ7XG4gICAgY2xpY2tCYWNrVG9wKCk6IHZvaWQ7XG4gICAgcHJpdmF0ZSBnZXRUYXJnZXQ7XG4gICAgcHJpdmF0ZSBoYW5kbGVTY3JvbGw7XG4gICAgcHJpdmF0ZSByZW1vdmVMaXN0ZW47XG4gICAgcHJpdmF0ZSByZWdpc3RlclNjcm9sbEV2ZW50O1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQ7XG59XG4iXX0=