import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-anchor.component';
import * as ɵngcc2 from './nz-anchor-link.component';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from 'ng-zorro-antd/affix';
import * as ɵngcc5 from '@angular/cdk/platform';
export declare class NzAnchorModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzAnchorModule, [typeof ɵngcc1.NzAnchorComponent, typeof ɵngcc2.NzAnchorLinkComponent], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.NzAffixModule, typeof ɵngcc5.PlatformModule], [typeof ɵngcc1.NzAnchorComponent, typeof ɵngcc2.NzAnchorLinkComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzAnchorModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYW5jaG9yLm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJuei1hbmNob3IubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpBbmNob3JNb2R1bGUge1xufVxuIl19