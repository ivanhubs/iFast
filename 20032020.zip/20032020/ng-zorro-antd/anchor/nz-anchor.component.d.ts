/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { AfterViewInit, ChangeDetectorRef, EventEmitter, OnDestroy } from '@angular/core';
import { NgStyleInterface, NzConfigService, NzScrollService } from 'ng-zorro-antd/core';
import { NzAnchorLinkComponent } from './nz-anchor-link.component';
import * as ɵngcc0 from '@angular/core';
export declare class NzAnchorComponent implements OnDestroy, AfterViewInit {
    nzConfigService: NzConfigService;
    private scrollSrv;
    private doc;
    private cdr;
    private platform;
    private ink;
    nzAffix: boolean;
    nzShowInkInFixed: boolean;
    nzBounds: number;
    nzOffsetTop: number;
    private _offsetTop;
    nzTarget: string | Element;
    readonly nzClick: EventEmitter<string>;
    readonly nzScroll: EventEmitter<NzAnchorLinkComponent>;
    visible: boolean;
    wrapperStyle: NgStyleInterface;
    private links;
    private animating;
    private target;
    private scroll$;
    private destroyed;
    constructor(nzConfigService: NzConfigService, scrollSrv: NzScrollService, doc: any, cdr: ChangeDetectorRef, platform: Platform);
    registerLink(link: NzAnchorLinkComponent): void;
    unregisterLink(link: NzAnchorLinkComponent): void;
    private getTarget;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private registerScrollEvent;
    private removeListen;
    private getOffsetTop;
    handleScroll(): void;
    private clearActive;
    private handleActive;
    handleScrollTo(linkComp: NzAnchorLinkComponent): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzAnchorComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzAnchorComponent, "nz-anchor", ["nzAnchor"], {
    "nzAffix": "nzAffix";
    "nzOffsetTop": "nzOffsetTop";
    "nzTarget": "nzTarget";
    "nzShowInkInFixed": "nzShowInkInFixed";
    "nzBounds": "nzBounds";
}, {
    "nzClick": "nzClick";
    "nzScroll": "nzScroll";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYW5jaG9yLmNvbXBvbmVudC5kLnRzIiwic291cmNlcyI6WyJuei1hbmNob3IuY29tcG9uZW50LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7OztBQVdBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5pbXBvcnQgeyBQbGF0Zm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9wbGF0Zm9ybSc7XG5pbXBvcnQgeyBBZnRlclZpZXdJbml0LCBDaGFuZ2VEZXRlY3RvclJlZiwgRXZlbnRFbWl0dGVyLCBPbkRlc3Ryb3kgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nU3R5bGVJbnRlcmZhY2UsIE56Q29uZmlnU2VydmljZSwgTnpTY3JvbGxTZXJ2aWNlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmltcG9ydCB7IE56QW5jaG9yTGlua0NvbXBvbmVudCB9IGZyb20gJy4vbnotYW5jaG9yLWxpbmsuY29tcG9uZW50JztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56QW5jaG9yQ29tcG9uZW50IGltcGxlbWVudHMgT25EZXN0cm95LCBBZnRlclZpZXdJbml0IHtcbiAgICBuekNvbmZpZ1NlcnZpY2U6IE56Q29uZmlnU2VydmljZTtcbiAgICBwcml2YXRlIHNjcm9sbFNydjtcbiAgICBwcml2YXRlIGRvYztcbiAgICBwcml2YXRlIGNkcjtcbiAgICBwcml2YXRlIHBsYXRmb3JtO1xuICAgIHByaXZhdGUgaW5rO1xuICAgIG56QWZmaXg6IGJvb2xlYW47XG4gICAgbnpTaG93SW5rSW5GaXhlZDogYm9vbGVhbjtcbiAgICBuekJvdW5kczogbnVtYmVyO1xuICAgIG56T2Zmc2V0VG9wOiBudW1iZXI7XG4gICAgcHJpdmF0ZSBfb2Zmc2V0VG9wO1xuICAgIG56VGFyZ2V0OiBzdHJpbmcgfCBFbGVtZW50O1xuICAgIHJlYWRvbmx5IG56Q2xpY2s6IEV2ZW50RW1pdHRlcjxzdHJpbmc+O1xuICAgIHJlYWRvbmx5IG56U2Nyb2xsOiBFdmVudEVtaXR0ZXI8TnpBbmNob3JMaW5rQ29tcG9uZW50PjtcbiAgICB2aXNpYmxlOiBib29sZWFuO1xuICAgIHdyYXBwZXJTdHlsZTogTmdTdHlsZUludGVyZmFjZTtcbiAgICBwcml2YXRlIGxpbmtzO1xuICAgIHByaXZhdGUgYW5pbWF0aW5nO1xuICAgIHByaXZhdGUgdGFyZ2V0O1xuICAgIHByaXZhdGUgc2Nyb2xsJDtcbiAgICBwcml2YXRlIGRlc3Ryb3llZDtcbiAgICBjb25zdHJ1Y3RvcihuekNvbmZpZ1NlcnZpY2U6IE56Q29uZmlnU2VydmljZSwgc2Nyb2xsU3J2OiBOelNjcm9sbFNlcnZpY2UsIGRvYzogYW55LCBjZHI6IENoYW5nZURldGVjdG9yUmVmLCBwbGF0Zm9ybTogUGxhdGZvcm0pO1xuICAgIHJlZ2lzdGVyTGluayhsaW5rOiBOekFuY2hvckxpbmtDb21wb25lbnQpOiB2b2lkO1xuICAgIHVucmVnaXN0ZXJMaW5rKGxpbms6IE56QW5jaG9yTGlua0NvbXBvbmVudCk6IHZvaWQ7XG4gICAgcHJpdmF0ZSBnZXRUYXJnZXQ7XG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQ7XG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZDtcbiAgICBwcml2YXRlIHJlZ2lzdGVyU2Nyb2xsRXZlbnQ7XG4gICAgcHJpdmF0ZSByZW1vdmVMaXN0ZW47XG4gICAgcHJpdmF0ZSBnZXRPZmZzZXRUb3A7XG4gICAgaGFuZGxlU2Nyb2xsKCk6IHZvaWQ7XG4gICAgcHJpdmF0ZSBjbGVhckFjdGl2ZTtcbiAgICBwcml2YXRlIGhhbmRsZUFjdGl2ZTtcbiAgICBoYW5kbGVTY3JvbGxUbyhsaW5rQ29tcDogTnpBbmNob3JMaW5rQ29tcG9uZW50KTogdm9pZDtcbn1cbiJdfQ==