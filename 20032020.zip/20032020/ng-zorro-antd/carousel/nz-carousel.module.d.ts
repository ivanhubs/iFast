import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-carousel.component';
import * as ɵngcc2 from './nz-carousel-content.directive';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from '@angular/cdk/platform';
export declare class NzCarouselModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzCarouselModule, [typeof ɵngcc1.NzCarouselComponent, typeof ɵngcc2.NzCarouselContentDirective], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.PlatformModule], [typeof ɵngcc1.NzCarouselComponent, typeof ɵngcc2.NzCarouselContentDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzCarouselModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY2Fyb3VzZWwubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm56LWNhcm91c2VsLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpDYXJvdXNlbE1vZHVsZSB7XG59XG4iXX0=