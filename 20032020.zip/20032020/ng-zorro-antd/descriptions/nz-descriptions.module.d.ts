import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-descriptions.component';
import * as ɵngcc2 from './nz-descriptions-item.component';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from 'ng-zorro-antd/core';
import * as ɵngcc5 from '@angular/cdk/platform';
export declare class NzDescriptionsModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzDescriptionsModule, [typeof ɵngcc1.NzDescriptionsComponent, typeof ɵngcc2.NzDescriptionsItemComponent], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.NzAddOnModule, typeof ɵngcc5.PlatformModule], [typeof ɵngcc1.NzDescriptionsComponent, typeof ɵngcc2.NzDescriptionsItemComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzDescriptionsModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZGVzY3JpcHRpb25zLm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJuei1kZXNjcmlwdGlvbnMubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpEZXNjcmlwdGlvbnNNb2R1bGUge1xufVxuIl19