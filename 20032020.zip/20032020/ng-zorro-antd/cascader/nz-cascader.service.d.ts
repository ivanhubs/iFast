/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { OnDestroy } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { NzCascaderComponentAsSource, NzCascaderOption, NzCascaderSearchOption } from './nz-cascader-definitions';
/**
 * All data is stored and parsed in NzCascaderService.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NzCascaderService implements OnDestroy {
    /** Activated options in each column. */
    activatedOptions: NzCascaderOption[];
    /** An array to store cascader items arranged in different layers. */
    columns: NzCascaderOption[][];
    /** If user has entered searching mode. */
    inSearchingMode: boolean;
    /** Selected options would be output to user. */
    selectedOptions: NzCascaderOption[];
    values: any[];
    readonly $loading: BehaviorSubject<boolean>;
    /**
     * Emit an event to notify cascader it needs to redraw because activated or
     * selected options are changed.
     */
    readonly $redraw: Subject<void>;
    /**
     * Emit an event when an option gets selected.
     * Emit true if a leaf options is selected.
     */
    readonly $optionSelected: Subject<{
        option: import("./nz-cascader-definitions").CascaderOption;
        index: number;
    } | null>;
    /**
     * Emit an event to notify cascader it needs to quit searching mode.
     * Only emit when user do select a searching option.
     */
    readonly $quitSearching: Subject<void>;
    /** To hold columns before entering searching mode. */
    private columnsSnapshot;
    /** To hold activated options before entering searching mode. */
    private activatedOptionsSnapshot;
    private cascaderComponent;
    /** Return cascader options in the first layer. */
    readonly nzOptions: NzCascaderOption[];
    ngOnDestroy(): void;
    /**
     * Make sure that value matches what is displayed in the dropdown.
     */
    syncOptions(first?: boolean): void;
    /**
     * Bind cascader component so this service could use inputs.
     */
    withComponent(cascaderComponent: NzCascaderComponentAsSource): void;
    /**
     * Reset all options. Rebuild searching options if in searching mode.
     */
    withOptions(options: NzCascaderOption[] | null): void;
    /**
     * Try to set a option as activated.
     * @param option Cascader option
     * @param columnIndex Of which column this option is in
     * @param performSelect Select
     * @param loadingChildren Try to load children asynchronously.
     */
    setOptionActivated(option: NzCascaderOption, columnIndex: number, performSelect?: boolean, loadingChildren?: boolean): void;
    setOptionSelected(option: NzCascaderOption, index: number): void;
    setOptionDeactivatedSinceColumn(column: number): void;
    /**
     * Set a searching option as selected, finishing up things.
     * @param option
     */
    setSearchOptionSelected(option: NzCascaderSearchOption): void;
    /**
     * Filter cascader options to reset `columns`.
     * @param searchValue The string user wants to search.
     */
    prepareSearchOptions(searchValue: string): void;
    /**
     * Toggle searching mode by UI. It deals with things not directly related to UI.
     * @param toSearching If this cascader is entering searching mode
     */
    toggleSearchingMode(toSearching: boolean): void;
    /**
     * Clear selected options.
     */
    clear(): void;
    getOptionLabel(o: NzCascaderOption): string;
    getOptionValue(o: NzCascaderOption): any;
    /**
     * Try to insert options into a column.
     * @param options Options to insert
     * @param columnIndex Position
     */
    private setColumnData;
    /**
     * Set all ancestor options as activated.
     */
    private trackAncestorActivatedOptions;
    private dropBehindActivatedOptions;
    private dropBehindColumns;
    /**
     * Load children of an option asynchronously.
     */
    loadChildren(option: NzCascaderOption | any, // tslint:disable-line:no-any
    columnIndex: number, success?: VoidFunction, failure?: VoidFunction): void;
    private isLoaded;
    /**
     * Find a option that has a given value in a given column.
     */
    private findOptionWithValue;
    private prepareEmitValue;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCascaderService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzCascaderService>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY2FzY2FkZXIuc2VydmljZS5kLnRzIiwic291cmNlcyI6WyJuei1jYXNjYWRlci5zZXJ2aWNlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7O0FBYUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVHQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QsIFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE56Q2FzY2FkZXJDb21wb25lbnRBc1NvdXJjZSwgTnpDYXNjYWRlck9wdGlvbiwgTnpDYXNjYWRlclNlYXJjaE9wdGlvbiB9IGZyb20gJy4vbnotY2FzY2FkZXItZGVmaW5pdGlvbnMnO1xuLyoqXG4gKiBBbGwgZGF0YSBpcyBzdG9yZWQgYW5kIHBhcnNlZCBpbiBOekNhc2NhZGVyU2VydmljZS5cbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpDYXNjYWRlclNlcnZpY2UgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICAgIC8qKiBBY3RpdmF0ZWQgb3B0aW9ucyBpbiBlYWNoIGNvbHVtbi4gKi9cbiAgICBhY3RpdmF0ZWRPcHRpb25zOiBOekNhc2NhZGVyT3B0aW9uW107XG4gICAgLyoqIEFuIGFycmF5IHRvIHN0b3JlIGNhc2NhZGVyIGl0ZW1zIGFycmFuZ2VkIGluIGRpZmZlcmVudCBsYXllcnMuICovXG4gICAgY29sdW1uczogTnpDYXNjYWRlck9wdGlvbltdW107XG4gICAgLyoqIElmIHVzZXIgaGFzIGVudGVyZWQgc2VhcmNoaW5nIG1vZGUuICovXG4gICAgaW5TZWFyY2hpbmdNb2RlOiBib29sZWFuO1xuICAgIC8qKiBTZWxlY3RlZCBvcHRpb25zIHdvdWxkIGJlIG91dHB1dCB0byB1c2VyLiAqL1xuICAgIHNlbGVjdGVkT3B0aW9uczogTnpDYXNjYWRlck9wdGlvbltdO1xuICAgIHZhbHVlczogYW55W107XG4gICAgcmVhZG9ubHkgJGxvYWRpbmc6IEJlaGF2aW9yU3ViamVjdDxib29sZWFuPjtcbiAgICAvKipcbiAgICAgKiBFbWl0IGFuIGV2ZW50IHRvIG5vdGlmeSBjYXNjYWRlciBpdCBuZWVkcyB0byByZWRyYXcgYmVjYXVzZSBhY3RpdmF0ZWQgb3JcbiAgICAgKiBzZWxlY3RlZCBvcHRpb25zIGFyZSBjaGFuZ2VkLlxuICAgICAqL1xuICAgIHJlYWRvbmx5ICRyZWRyYXc6IFN1YmplY3Q8dm9pZD47XG4gICAgLyoqXG4gICAgICogRW1pdCBhbiBldmVudCB3aGVuIGFuIG9wdGlvbiBnZXRzIHNlbGVjdGVkLlxuICAgICAqIEVtaXQgdHJ1ZSBpZiBhIGxlYWYgb3B0aW9ucyBpcyBzZWxlY3RlZC5cbiAgICAgKi9cbiAgICByZWFkb25seSAkb3B0aW9uU2VsZWN0ZWQ6IFN1YmplY3Q8e1xuICAgICAgICBvcHRpb246IGltcG9ydChcIi4vbnotY2FzY2FkZXItZGVmaW5pdGlvbnNcIikuQ2FzY2FkZXJPcHRpb247XG4gICAgICAgIGluZGV4OiBudW1iZXI7XG4gICAgfSB8IG51bGw+O1xuICAgIC8qKlxuICAgICAqIEVtaXQgYW4gZXZlbnQgdG8gbm90aWZ5IGNhc2NhZGVyIGl0IG5lZWRzIHRvIHF1aXQgc2VhcmNoaW5nIG1vZGUuXG4gICAgICogT25seSBlbWl0IHdoZW4gdXNlciBkbyBzZWxlY3QgYSBzZWFyY2hpbmcgb3B0aW9uLlxuICAgICAqL1xuICAgIHJlYWRvbmx5ICRxdWl0U2VhcmNoaW5nOiBTdWJqZWN0PHZvaWQ+O1xuICAgIC8qKiBUbyBob2xkIGNvbHVtbnMgYmVmb3JlIGVudGVyaW5nIHNlYXJjaGluZyBtb2RlLiAqL1xuICAgIHByaXZhdGUgY29sdW1uc1NuYXBzaG90O1xuICAgIC8qKiBUbyBob2xkIGFjdGl2YXRlZCBvcHRpb25zIGJlZm9yZSBlbnRlcmluZyBzZWFyY2hpbmcgbW9kZS4gKi9cbiAgICBwcml2YXRlIGFjdGl2YXRlZE9wdGlvbnNTbmFwc2hvdDtcbiAgICBwcml2YXRlIGNhc2NhZGVyQ29tcG9uZW50O1xuICAgIC8qKiBSZXR1cm4gY2FzY2FkZXIgb3B0aW9ucyBpbiB0aGUgZmlyc3QgbGF5ZXIuICovXG4gICAgcmVhZG9ubHkgbnpPcHRpb25zOiBOekNhc2NhZGVyT3B0aW9uW107XG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBNYWtlIHN1cmUgdGhhdCB2YWx1ZSBtYXRjaGVzIHdoYXQgaXMgZGlzcGxheWVkIGluIHRoZSBkcm9wZG93bi5cbiAgICAgKi9cbiAgICBzeW5jT3B0aW9ucyhmaXJzdD86IGJvb2xlYW4pOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIEJpbmQgY2FzY2FkZXIgY29tcG9uZW50IHNvIHRoaXMgc2VydmljZSBjb3VsZCB1c2UgaW5wdXRzLlxuICAgICAqL1xuICAgIHdpdGhDb21wb25lbnQoY2FzY2FkZXJDb21wb25lbnQ6IE56Q2FzY2FkZXJDb21wb25lbnRBc1NvdXJjZSk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogUmVzZXQgYWxsIG9wdGlvbnMuIFJlYnVpbGQgc2VhcmNoaW5nIG9wdGlvbnMgaWYgaW4gc2VhcmNoaW5nIG1vZGUuXG4gICAgICovXG4gICAgd2l0aE9wdGlvbnMob3B0aW9uczogTnpDYXNjYWRlck9wdGlvbltdIHwgbnVsbCk6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogVHJ5IHRvIHNldCBhIG9wdGlvbiBhcyBhY3RpdmF0ZWQuXG4gICAgICogQHBhcmFtIG9wdGlvbiBDYXNjYWRlciBvcHRpb25cbiAgICAgKiBAcGFyYW0gY29sdW1uSW5kZXggT2Ygd2hpY2ggY29sdW1uIHRoaXMgb3B0aW9uIGlzIGluXG4gICAgICogQHBhcmFtIHBlcmZvcm1TZWxlY3QgU2VsZWN0XG4gICAgICogQHBhcmFtIGxvYWRpbmdDaGlsZHJlbiBUcnkgdG8gbG9hZCBjaGlsZHJlbiBhc3luY2hyb25vdXNseS5cbiAgICAgKi9cbiAgICBzZXRPcHRpb25BY3RpdmF0ZWQob3B0aW9uOiBOekNhc2NhZGVyT3B0aW9uLCBjb2x1bW5JbmRleDogbnVtYmVyLCBwZXJmb3JtU2VsZWN0PzogYm9vbGVhbiwgbG9hZGluZ0NoaWxkcmVuPzogYm9vbGVhbik6IHZvaWQ7XG4gICAgc2V0T3B0aW9uU2VsZWN0ZWQob3B0aW9uOiBOekNhc2NhZGVyT3B0aW9uLCBpbmRleDogbnVtYmVyKTogdm9pZDtcbiAgICBzZXRPcHRpb25EZWFjdGl2YXRlZFNpbmNlQ29sdW1uKGNvbHVtbjogbnVtYmVyKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBTZXQgYSBzZWFyY2hpbmcgb3B0aW9uIGFzIHNlbGVjdGVkLCBmaW5pc2hpbmcgdXAgdGhpbmdzLlxuICAgICAqIEBwYXJhbSBvcHRpb25cbiAgICAgKi9cbiAgICBzZXRTZWFyY2hPcHRpb25TZWxlY3RlZChvcHRpb246IE56Q2FzY2FkZXJTZWFyY2hPcHRpb24pOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIEZpbHRlciBjYXNjYWRlciBvcHRpb25zIHRvIHJlc2V0IGBjb2x1bW5zYC5cbiAgICAgKiBAcGFyYW0gc2VhcmNoVmFsdWUgVGhlIHN0cmluZyB1c2VyIHdhbnRzIHRvIHNlYXJjaC5cbiAgICAgKi9cbiAgICBwcmVwYXJlU2VhcmNoT3B0aW9ucyhzZWFyY2hWYWx1ZTogc3RyaW5nKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBUb2dnbGUgc2VhcmNoaW5nIG1vZGUgYnkgVUkuIEl0IGRlYWxzIHdpdGggdGhpbmdzIG5vdCBkaXJlY3RseSByZWxhdGVkIHRvIFVJLlxuICAgICAqIEBwYXJhbSB0b1NlYXJjaGluZyBJZiB0aGlzIGNhc2NhZGVyIGlzIGVudGVyaW5nIHNlYXJjaGluZyBtb2RlXG4gICAgICovXG4gICAgdG9nZ2xlU2VhcmNoaW5nTW9kZSh0b1NlYXJjaGluZzogYm9vbGVhbik6IHZvaWQ7XG4gICAgLyoqXG4gICAgICogQ2xlYXIgc2VsZWN0ZWQgb3B0aW9ucy5cbiAgICAgKi9cbiAgICBjbGVhcigpOiB2b2lkO1xuICAgIGdldE9wdGlvbkxhYmVsKG86IE56Q2FzY2FkZXJPcHRpb24pOiBzdHJpbmc7XG4gICAgZ2V0T3B0aW9uVmFsdWUobzogTnpDYXNjYWRlck9wdGlvbik6IGFueTtcbiAgICAvKipcbiAgICAgKiBUcnkgdG8gaW5zZXJ0IG9wdGlvbnMgaW50byBhIGNvbHVtbi5cbiAgICAgKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zIHRvIGluc2VydFxuICAgICAqIEBwYXJhbSBjb2x1bW5JbmRleCBQb3NpdGlvblxuICAgICAqL1xuICAgIHByaXZhdGUgc2V0Q29sdW1uRGF0YTtcbiAgICAvKipcbiAgICAgKiBTZXQgYWxsIGFuY2VzdG9yIG9wdGlvbnMgYXMgYWN0aXZhdGVkLlxuICAgICAqL1xuICAgIHByaXZhdGUgdHJhY2tBbmNlc3RvckFjdGl2YXRlZE9wdGlvbnM7XG4gICAgcHJpdmF0ZSBkcm9wQmVoaW5kQWN0aXZhdGVkT3B0aW9ucztcbiAgICBwcml2YXRlIGRyb3BCZWhpbmRDb2x1bW5zO1xuICAgIC8qKlxuICAgICAqIExvYWQgY2hpbGRyZW4gb2YgYW4gb3B0aW9uIGFzeW5jaHJvbm91c2x5LlxuICAgICAqL1xuICAgIGxvYWRDaGlsZHJlbihvcHRpb246IE56Q2FzY2FkZXJPcHRpb24gfCBhbnksIC8vIHRzbGludDpkaXNhYmxlLWxpbmU6bm8tYW55XG4gICAgY29sdW1uSW5kZXg6IG51bWJlciwgc3VjY2Vzcz86IFZvaWRGdW5jdGlvbiwgZmFpbHVyZT86IFZvaWRGdW5jdGlvbik6IHZvaWQ7XG4gICAgcHJpdmF0ZSBpc0xvYWRlZDtcbiAgICAvKipcbiAgICAgKiBGaW5kIGEgb3B0aW9uIHRoYXQgaGFzIGEgZ2l2ZW4gdmFsdWUgaW4gYSBnaXZlbiBjb2x1bW4uXG4gICAgICovXG4gICAgcHJpdmF0ZSBmaW5kT3B0aW9uV2l0aFZhbHVlO1xuICAgIHByaXZhdGUgcHJlcGFyZUVtaXRWYWx1ZTtcbn1cbiJdfQ==