/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, ElementRef, Renderer2, TemplateRef } from '@angular/core';
import { NzCascaderOption } from './nz-cascader-definitions';
import * as ɵngcc0 from '@angular/core';
export declare class NzCascaderOptionComponent {
    private cdr;
    optionTemplate: TemplateRef<NzCascaderOption> | null;
    option: NzCascaderOption;
    activated: boolean;
    highlightText: string;
    nzLabelProperty: string;
    columnIndex: number;
    constructor(cdr: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2);
    readonly optionLabel: string;
    markForCheck(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCascaderOptionComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzCascaderOptionComponent, "[nz-cascader-option]", ["nzCascaderOption"], {
    "optionTemplate": "optionTemplate";
    "activated": "activated";
    "nzLabelProperty": "nzLabelProperty";
    "option": "option";
    "highlightText": "highlightText";
    "columnIndex": "columnIndex";
}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY2FzY2FkZXItbGkuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWNhc2NhZGVyLWxpLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7O0FBU0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBV0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IENoYW5nZURldGVjdG9yUmVmLCBFbGVtZW50UmVmLCBSZW5kZXJlcjIsIFRlbXBsYXRlUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOekNhc2NhZGVyT3B0aW9uIH0gZnJvbSAnLi9uei1jYXNjYWRlci1kZWZpbml0aW9ucyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekNhc2NhZGVyT3B0aW9uQ29tcG9uZW50IHtcbiAgICBwcml2YXRlIGNkcjtcbiAgICBvcHRpb25UZW1wbGF0ZTogVGVtcGxhdGVSZWY8TnpDYXNjYWRlck9wdGlvbj4gfCBudWxsO1xuICAgIG9wdGlvbjogTnpDYXNjYWRlck9wdGlvbjtcbiAgICBhY3RpdmF0ZWQ6IGJvb2xlYW47XG4gICAgaGlnaGxpZ2h0VGV4dDogc3RyaW5nO1xuICAgIG56TGFiZWxQcm9wZXJ0eTogc3RyaW5nO1xuICAgIGNvbHVtbkluZGV4OiBudW1iZXI7XG4gICAgY29uc3RydWN0b3IoY2RyOiBDaGFuZ2VEZXRlY3RvclJlZiwgZWxlbWVudFJlZjogRWxlbWVudFJlZiwgcmVuZGVyZXI6IFJlbmRlcmVyMik7XG4gICAgcmVhZG9ubHkgb3B0aW9uTGFiZWw6IHN0cmluZztcbiAgICBtYXJrRm9yQ2hlY2soKTogdm9pZDtcbn1cbiJdfQ==