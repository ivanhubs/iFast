/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { CdkConnectedOverlay, ConnectedOverlayPositionChange, ConnectionPositionPair } from '@angular/cdk/overlay';
import { ChangeDetectorRef, ElementRef, EventEmitter, OnDestroy, OnInit, QueryList, Renderer2, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgClassType, NgStyleInterface, NzConfigService, NzNoAnimationDirective } from 'ng-zorro-antd/core';
import { NzCascaderI18nInterface, NzI18nService } from 'ng-zorro-antd/i18n';
import { NzCascaderComponentAsSource, NzCascaderExpandTrigger, NzCascaderOption, NzCascaderSize, NzCascaderTriggerType, NzShowSearchOptions } from './nz-cascader-definitions';
import { NzCascaderOptionComponent } from './nz-cascader-li.component';
import { NzCascaderService } from './nz-cascader.service';
import * as ɵngcc0 from '@angular/core';
export declare class NzCascaderComponent implements NzCascaderComponentAsSource, OnInit, OnDestroy, ControlValueAccessor {
    cascaderService: NzCascaderService;
    private i18nService;
    nzConfigService: NzConfigService;
    private cdr;
    noAnimation?: NzNoAnimationDirective | undefined;
    input: ElementRef;
    menu: ElementRef;
    overlay: CdkConnectedOverlay;
    cascaderItems: QueryList<NzCascaderOptionComponent>;
    nzOptionRender: TemplateRef<{
        $implicit: NzCascaderOption;
        index: number;
    }> | null;
    nzShowInput: boolean;
    nzShowArrow: boolean;
    nzAllowClear: boolean;
    nzAutoFocus: boolean;
    nzChangeOnSelect: boolean;
    nzDisabled: boolean;
    nzColumnClassName: string;
    nzExpandTrigger: NzCascaderExpandTrigger;
    nzValueProperty: string;
    nzLabelRender: TemplateRef<void>;
    nzLabelProperty: string;
    nzNotFoundContent: string | TemplateRef<void>;
    nzSize: NzCascaderSize;
    nzShowSearch: boolean | NzShowSearchOptions;
    nzPlaceHolder: string;
    nzMenuClassName: string;
    nzMenuStyle: NgStyleInterface;
    nzMouseEnterDelay: number;
    nzMouseLeaveDelay: number;
    nzTriggerAction: NzCascaderTriggerType | NzCascaderTriggerType[];
    nzChangeOn: (option: NzCascaderOption, level: number) => boolean;
    nzLoadData: (node: NzCascaderOption, index?: number) => PromiseLike<any>;
    nzOptions: NzCascaderOption[] | null;
    readonly nzVisibleChange: EventEmitter<boolean>;
    readonly nzSelectionChange: EventEmitter<import("./nz-cascader-definitions").CascaderOption[]>;
    /**
     * @deprecated 9.0.0. This api is a duplication of `ngModelChange`.
     */
    readonly nzSelect: EventEmitter<{
        option: import("./nz-cascader-definitions").CascaderOption;
        index: number;
    } | null>;
    readonly nzClear: EventEmitter<void>;
    el: HTMLElement;
    dropDownPosition: string;
    menuVisible: boolean;
    isLoading: boolean;
    labelRenderText: string;
    labelRenderContext: {};
    onChange: Function;
    onTouched: Function;
    positions: ConnectionPositionPair[];
    dropdownWidthStyle: string;
    isFocused: boolean;
    locale: NzCascaderI18nInterface;
    private $destroy;
    private inputString;
    private isOpening;
    private delayMenuTimer;
    private delaySelectTimer;
    readonly inSearchingMode: boolean;
    inputValue: string;
    readonly menuCls: NgClassType;
    readonly menuColumnCls: NgClassType;
    private readonly hasInput;
    private readonly hasValue;
    readonly showPlaceholder: boolean;
    readonly clearIconVisible: boolean;
    readonly isLabelRenderTemplate: boolean;
    constructor(cascaderService: NzCascaderService, i18nService: NzI18nService, nzConfigService: NzConfigService, cdr: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2, noAnimation?: NzNoAnimationDirective | undefined);
    ngOnInit(): void;
    ngOnDestroy(): void;
    registerOnChange(fn: () => {}): void;
    registerOnTouched(fn: () => {}): void;
    writeValue(value: any): void;
    delaySetMenuVisible(visible: boolean, delay?: number, setOpening?: boolean): void;
    setMenuVisible(visible: boolean): void;
    private clearDelayMenuTimer;
    clearSelection(event?: Event): void;
    getSubmitValue(): any[];
    focus(): void;
    blur(): void;
    handleInputBlur(): void;
    handleInputFocus(): void;
    onKeyDown(event: KeyboardEvent): void;
    onTriggerClick(): void;
    onTriggerMouseEnter(): void;
    onTriggerMouseLeave(event: MouseEvent): void;
    onOptionMouseEnter(option: NzCascaderOption, columnIndex: number, event: Event): void;
    onOptionMouseLeave(option: NzCascaderOption, _columnIndex: number, event: Event): void;
    onOptionClick(option: NzCascaderOption, columnIndex: number, event: Event): void;
    private isActionTrigger;
    private onEnter;
    private moveUpOrDown;
    private moveLeft;
    private moveRight;
    private clearDelaySelectTimer;
    private delaySetOptionActivated;
    private toggleSearchingMode;
    isOptionActivated(option: NzCascaderOption, index: number): boolean;
    setDisabledState(isDisabled: boolean): void;
    closeMenu(): void;
    onPositionChange(position: ConnectedOverlayPositionChange): void;
    /**
     * Reposition the cascader panel. When a menu opens, the cascader expands
     * and may exceed the boundary of browser's window.
     */
    private reposition;
    /**
     * When a cascader options is changed, a child needs to know that it should re-render.
     */
    private checkChildren;
    private buildDisplayLabel;
    private setLocale;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCascaderComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzCascaderComponent, "nz-cascader, [nz-cascader]", ["nzCascader"], {
    "nzOptionRender": "nzOptionRender";
    "nzShowInput": "nzShowInput";
    "nzShowArrow": "nzShowArrow";
    "nzAllowClear": "nzAllowClear";
    "nzAutoFocus": "nzAutoFocus";
    "nzChangeOnSelect": "nzChangeOnSelect";
    "nzDisabled": "nzDisabled";
    "nzExpandTrigger": "nzExpandTrigger";
    "nzValueProperty": "nzValueProperty";
    "nzLabelProperty": "nzLabelProperty";
    "nzMouseEnterDelay": "nzMouseEnterDelay";
    "nzMouseLeaveDelay": "nzMouseLeaveDelay";
    "nzTriggerAction": "nzTriggerAction";
    "nzOptions": "nzOptions";
    "nzColumnClassName": "nzColumnClassName";
    "nzLabelRender": "nzLabelRender";
    "nzNotFoundContent": "nzNotFoundContent";
    "nzSize": "nzSize";
    "nzShowSearch": "nzShowSearch";
    "nzPlaceHolder": "nzPlaceHolder";
    "nzMenuClassName": "nzMenuClassName";
    "nzMenuStyle": "nzMenuStyle";
    "nzChangeOn": "nzChangeOn";
    "nzLoadData": "nzLoadData";
}, {
    "nzVisibleChange": "nzVisibleChange";
    "nzSelectionChange": "nzSelectionChange";
    "nzSelect": "nzSelect";
    "nzClear": "nzClear";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY2FzY2FkZXIuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWNhc2NhZGVyLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7Ozs7O0FBZUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNIQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgQ2RrQ29ubmVjdGVkT3ZlcmxheSwgQ29ubmVjdGVkT3ZlcmxheVBvc2l0aW9uQ2hhbmdlLCBDb25uZWN0aW9uUG9zaXRpb25QYWlyIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL292ZXJsYXknO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0b3JSZWYsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgT25EZXN0cm95LCBPbkluaXQsIFF1ZXJ5TGlzdCwgUmVuZGVyZXIyLCBUZW1wbGF0ZVJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBOZ0NsYXNzVHlwZSwgTmdTdHlsZUludGVyZmFjZSwgTnpDb25maWdTZXJ2aWNlLCBOek5vQW5pbWF0aW9uRGlyZWN0aXZlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmltcG9ydCB7IE56Q2FzY2FkZXJJMThuSW50ZXJmYWNlLCBOekkxOG5TZXJ2aWNlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9pMThuJztcbmltcG9ydCB7IE56Q2FzY2FkZXJDb21wb25lbnRBc1NvdXJjZSwgTnpDYXNjYWRlckV4cGFuZFRyaWdnZXIsIE56Q2FzY2FkZXJPcHRpb24sIE56Q2FzY2FkZXJTaXplLCBOekNhc2NhZGVyVHJpZ2dlclR5cGUsIE56U2hvd1NlYXJjaE9wdGlvbnMgfSBmcm9tICcuL256LWNhc2NhZGVyLWRlZmluaXRpb25zJztcbmltcG9ydCB7IE56Q2FzY2FkZXJPcHRpb25Db21wb25lbnQgfSBmcm9tICcuL256LWNhc2NhZGVyLWxpLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBOekNhc2NhZGVyU2VydmljZSB9IGZyb20gJy4vbnotY2FzY2FkZXIuc2VydmljZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekNhc2NhZGVyQ29tcG9uZW50IGltcGxlbWVudHMgTnpDYXNjYWRlckNvbXBvbmVudEFzU291cmNlLCBPbkluaXQsIE9uRGVzdHJveSwgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuICAgIGNhc2NhZGVyU2VydmljZTogTnpDYXNjYWRlclNlcnZpY2U7XG4gICAgcHJpdmF0ZSBpMThuU2VydmljZTtcbiAgICBuekNvbmZpZ1NlcnZpY2U6IE56Q29uZmlnU2VydmljZTtcbiAgICBwcml2YXRlIGNkcjtcbiAgICBub0FuaW1hdGlvbj86IE56Tm9BbmltYXRpb25EaXJlY3RpdmUgfCB1bmRlZmluZWQ7XG4gICAgaW5wdXQ6IEVsZW1lbnRSZWY7XG4gICAgbWVudTogRWxlbWVudFJlZjtcbiAgICBvdmVybGF5OiBDZGtDb25uZWN0ZWRPdmVybGF5O1xuICAgIGNhc2NhZGVySXRlbXM6IFF1ZXJ5TGlzdDxOekNhc2NhZGVyT3B0aW9uQ29tcG9uZW50PjtcbiAgICBuek9wdGlvblJlbmRlcjogVGVtcGxhdGVSZWY8e1xuICAgICAgICAkaW1wbGljaXQ6IE56Q2FzY2FkZXJPcHRpb247XG4gICAgICAgIGluZGV4OiBudW1iZXI7XG4gICAgfT4gfCBudWxsO1xuICAgIG56U2hvd0lucHV0OiBib29sZWFuO1xuICAgIG56U2hvd0Fycm93OiBib29sZWFuO1xuICAgIG56QWxsb3dDbGVhcjogYm9vbGVhbjtcbiAgICBuekF1dG9Gb2N1czogYm9vbGVhbjtcbiAgICBuekNoYW5nZU9uU2VsZWN0OiBib29sZWFuO1xuICAgIG56RGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgbnpDb2x1bW5DbGFzc05hbWU6IHN0cmluZztcbiAgICBuekV4cGFuZFRyaWdnZXI6IE56Q2FzY2FkZXJFeHBhbmRUcmlnZ2VyO1xuICAgIG56VmFsdWVQcm9wZXJ0eTogc3RyaW5nO1xuICAgIG56TGFiZWxSZW5kZXI6IFRlbXBsYXRlUmVmPHZvaWQ+O1xuICAgIG56TGFiZWxQcm9wZXJ0eTogc3RyaW5nO1xuICAgIG56Tm90Rm91bmRDb250ZW50OiBzdHJpbmcgfCBUZW1wbGF0ZVJlZjx2b2lkPjtcbiAgICBuelNpemU6IE56Q2FzY2FkZXJTaXplO1xuICAgIG56U2hvd1NlYXJjaDogYm9vbGVhbiB8IE56U2hvd1NlYXJjaE9wdGlvbnM7XG4gICAgbnpQbGFjZUhvbGRlcjogc3RyaW5nO1xuICAgIG56TWVudUNsYXNzTmFtZTogc3RyaW5nO1xuICAgIG56TWVudVN0eWxlOiBOZ1N0eWxlSW50ZXJmYWNlO1xuICAgIG56TW91c2VFbnRlckRlbGF5OiBudW1iZXI7XG4gICAgbnpNb3VzZUxlYXZlRGVsYXk6IG51bWJlcjtcbiAgICBuelRyaWdnZXJBY3Rpb246IE56Q2FzY2FkZXJUcmlnZ2VyVHlwZSB8IE56Q2FzY2FkZXJUcmlnZ2VyVHlwZVtdO1xuICAgIG56Q2hhbmdlT246IChvcHRpb246IE56Q2FzY2FkZXJPcHRpb24sIGxldmVsOiBudW1iZXIpID0+IGJvb2xlYW47XG4gICAgbnpMb2FkRGF0YTogKG5vZGU6IE56Q2FzY2FkZXJPcHRpb24sIGluZGV4PzogbnVtYmVyKSA9PiBQcm9taXNlTGlrZTxhbnk+O1xuICAgIG56T3B0aW9uczogTnpDYXNjYWRlck9wdGlvbltdIHwgbnVsbDtcbiAgICByZWFkb25seSBuelZpc2libGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxib29sZWFuPjtcbiAgICByZWFkb25seSBuelNlbGVjdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPGltcG9ydChcIi4vbnotY2FzY2FkZXItZGVmaW5pdGlvbnNcIikuQ2FzY2FkZXJPcHRpb25bXT47XG4gICAgLyoqXG4gICAgICogQGRlcHJlY2F0ZWQgOS4wLjAuIFRoaXMgYXBpIGlzIGEgZHVwbGljYXRpb24gb2YgYG5nTW9kZWxDaGFuZ2VgLlxuICAgICAqL1xuICAgIHJlYWRvbmx5IG56U2VsZWN0OiBFdmVudEVtaXR0ZXI8e1xuICAgICAgICBvcHRpb246IGltcG9ydChcIi4vbnotY2FzY2FkZXItZGVmaW5pdGlvbnNcIikuQ2FzY2FkZXJPcHRpb247XG4gICAgICAgIGluZGV4OiBudW1iZXI7XG4gICAgfSB8IG51bGw+O1xuICAgIHJlYWRvbmx5IG56Q2xlYXI6IEV2ZW50RW1pdHRlcjx2b2lkPjtcbiAgICBlbDogSFRNTEVsZW1lbnQ7XG4gICAgZHJvcERvd25Qb3NpdGlvbjogc3RyaW5nO1xuICAgIG1lbnVWaXNpYmxlOiBib29sZWFuO1xuICAgIGlzTG9hZGluZzogYm9vbGVhbjtcbiAgICBsYWJlbFJlbmRlclRleHQ6IHN0cmluZztcbiAgICBsYWJlbFJlbmRlckNvbnRleHQ6IHt9O1xuICAgIG9uQ2hhbmdlOiBGdW5jdGlvbjtcbiAgICBvblRvdWNoZWQ6IEZ1bmN0aW9uO1xuICAgIHBvc2l0aW9uczogQ29ubmVjdGlvblBvc2l0aW9uUGFpcltdO1xuICAgIGRyb3Bkb3duV2lkdGhTdHlsZTogc3RyaW5nO1xuICAgIGlzRm9jdXNlZDogYm9vbGVhbjtcbiAgICBsb2NhbGU6IE56Q2FzY2FkZXJJMThuSW50ZXJmYWNlO1xuICAgIHByaXZhdGUgJGRlc3Ryb3k7XG4gICAgcHJpdmF0ZSBpbnB1dFN0cmluZztcbiAgICBwcml2YXRlIGlzT3BlbmluZztcbiAgICBwcml2YXRlIGRlbGF5TWVudVRpbWVyO1xuICAgIHByaXZhdGUgZGVsYXlTZWxlY3RUaW1lcjtcbiAgICByZWFkb25seSBpblNlYXJjaGluZ01vZGU6IGJvb2xlYW47XG4gICAgaW5wdXRWYWx1ZTogc3RyaW5nO1xuICAgIHJlYWRvbmx5IG1lbnVDbHM6IE5nQ2xhc3NUeXBlO1xuICAgIHJlYWRvbmx5IG1lbnVDb2x1bW5DbHM6IE5nQ2xhc3NUeXBlO1xuICAgIHByaXZhdGUgcmVhZG9ubHkgaGFzSW5wdXQ7XG4gICAgcHJpdmF0ZSByZWFkb25seSBoYXNWYWx1ZTtcbiAgICByZWFkb25seSBzaG93UGxhY2Vob2xkZXI6IGJvb2xlYW47XG4gICAgcmVhZG9ubHkgY2xlYXJJY29uVmlzaWJsZTogYm9vbGVhbjtcbiAgICByZWFkb25seSBpc0xhYmVsUmVuZGVyVGVtcGxhdGU6IGJvb2xlYW47XG4gICAgY29uc3RydWN0b3IoY2FzY2FkZXJTZXJ2aWNlOiBOekNhc2NhZGVyU2VydmljZSwgaTE4blNlcnZpY2U6IE56STE4blNlcnZpY2UsIG56Q29uZmlnU2VydmljZTogTnpDb25maWdTZXJ2aWNlLCBjZHI6IENoYW5nZURldGVjdG9yUmVmLCBlbGVtZW50UmVmOiBFbGVtZW50UmVmLCByZW5kZXJlcjogUmVuZGVyZXIyLCBub0FuaW1hdGlvbj86IE56Tm9BbmltYXRpb25EaXJlY3RpdmUgfCB1bmRlZmluZWQpO1xuICAgIG5nT25Jbml0KCk6IHZvaWQ7XG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZDtcbiAgICByZWdpc3Rlck9uQ2hhbmdlKGZuOiAoKSA9PiB7fSk6IHZvaWQ7XG4gICAgcmVnaXN0ZXJPblRvdWNoZWQoZm46ICgpID0+IHt9KTogdm9pZDtcbiAgICB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkO1xuICAgIGRlbGF5U2V0TWVudVZpc2libGUodmlzaWJsZTogYm9vbGVhbiwgZGVsYXk/OiBudW1iZXIsIHNldE9wZW5pbmc/OiBib29sZWFuKTogdm9pZDtcbiAgICBzZXRNZW51VmlzaWJsZSh2aXNpYmxlOiBib29sZWFuKTogdm9pZDtcbiAgICBwcml2YXRlIGNsZWFyRGVsYXlNZW51VGltZXI7XG4gICAgY2xlYXJTZWxlY3Rpb24oZXZlbnQ/OiBFdmVudCk6IHZvaWQ7XG4gICAgZ2V0U3VibWl0VmFsdWUoKTogYW55W107XG4gICAgZm9jdXMoKTogdm9pZDtcbiAgICBibHVyKCk6IHZvaWQ7XG4gICAgaGFuZGxlSW5wdXRCbHVyKCk6IHZvaWQ7XG4gICAgaGFuZGxlSW5wdXRGb2N1cygpOiB2b2lkO1xuICAgIG9uS2V5RG93bihldmVudDogS2V5Ym9hcmRFdmVudCk6IHZvaWQ7XG4gICAgb25UcmlnZ2VyQ2xpY2soKTogdm9pZDtcbiAgICBvblRyaWdnZXJNb3VzZUVudGVyKCk6IHZvaWQ7XG4gICAgb25UcmlnZ2VyTW91c2VMZWF2ZShldmVudDogTW91c2VFdmVudCk6IHZvaWQ7XG4gICAgb25PcHRpb25Nb3VzZUVudGVyKG9wdGlvbjogTnpDYXNjYWRlck9wdGlvbiwgY29sdW1uSW5kZXg6IG51bWJlciwgZXZlbnQ6IEV2ZW50KTogdm9pZDtcbiAgICBvbk9wdGlvbk1vdXNlTGVhdmUob3B0aW9uOiBOekNhc2NhZGVyT3B0aW9uLCBfY29sdW1uSW5kZXg6IG51bWJlciwgZXZlbnQ6IEV2ZW50KTogdm9pZDtcbiAgICBvbk9wdGlvbkNsaWNrKG9wdGlvbjogTnpDYXNjYWRlck9wdGlvbiwgY29sdW1uSW5kZXg6IG51bWJlciwgZXZlbnQ6IEV2ZW50KTogdm9pZDtcbiAgICBwcml2YXRlIGlzQWN0aW9uVHJpZ2dlcjtcbiAgICBwcml2YXRlIG9uRW50ZXI7XG4gICAgcHJpdmF0ZSBtb3ZlVXBPckRvd247XG4gICAgcHJpdmF0ZSBtb3ZlTGVmdDtcbiAgICBwcml2YXRlIG1vdmVSaWdodDtcbiAgICBwcml2YXRlIGNsZWFyRGVsYXlTZWxlY3RUaW1lcjtcbiAgICBwcml2YXRlIGRlbGF5U2V0T3B0aW9uQWN0aXZhdGVkO1xuICAgIHByaXZhdGUgdG9nZ2xlU2VhcmNoaW5nTW9kZTtcbiAgICBpc09wdGlvbkFjdGl2YXRlZChvcHRpb246IE56Q2FzY2FkZXJPcHRpb24sIGluZGV4OiBudW1iZXIpOiBib29sZWFuO1xuICAgIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQ7XG4gICAgY2xvc2VNZW51KCk6IHZvaWQ7XG4gICAgb25Qb3NpdGlvbkNoYW5nZShwb3NpdGlvbjogQ29ubmVjdGVkT3ZlcmxheVBvc2l0aW9uQ2hhbmdlKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBSZXBvc2l0aW9uIHRoZSBjYXNjYWRlciBwYW5lbC4gV2hlbiBhIG1lbnUgb3BlbnMsIHRoZSBjYXNjYWRlciBleHBhbmRzXG4gICAgICogYW5kIG1heSBleGNlZWQgdGhlIGJvdW5kYXJ5IG9mIGJyb3dzZXIncyB3aW5kb3cuXG4gICAgICovXG4gICAgcHJpdmF0ZSByZXBvc2l0aW9uO1xuICAgIC8qKlxuICAgICAqIFdoZW4gYSBjYXNjYWRlciBvcHRpb25zIGlzIGNoYW5nZWQsIGEgY2hpbGQgbmVlZHMgdG8ga25vdyB0aGF0IGl0IHNob3VsZCByZS1yZW5kZXIuXG4gICAgICovXG4gICAgcHJpdmF0ZSBjaGVja0NoaWxkcmVuO1xuICAgIHByaXZhdGUgYnVpbGREaXNwbGF5TGFiZWw7XG4gICAgcHJpdmF0ZSBzZXRMb2NhbGU7XG59XG4iXX0=