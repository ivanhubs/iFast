/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ConnectionPositionPair, Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { Platform } from '@angular/cdk/platform';
import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnDestroy, Renderer2, SimpleChanges, ViewContainerRef } from '@angular/core';
import { NzButtonComponent, NzButtonGroupComponent } from 'ng-zorro-antd/button';
import { Observable } from 'rxjs';
import { NzDropdownMenuComponent, NzPlacementType } from './nz-dropdown-menu.component';
import * as ɵngcc0 from '@angular/core';
export declare class NzDropDownDirective implements AfterViewInit, OnDestroy, OnChanges {
    elementRef: ElementRef;
    private renderer;
    private overlay;
    private platform;
    private nzButtonComponent;
    private nzButtonGroupComponent;
    private viewContainerRef;
    private portal;
    private overlayRef;
    private destroy$;
    private triggerWidth;
    private el;
    private dropdownOpen;
    private positionStrategy;
    private positions;
    private positionSubscription;
    private overlaySubscription;
    readonly hover$: Observable<boolean>;
    readonly $click: Observable<boolean>;
    nzDropdownMenu: NzDropdownMenuComponent;
    nzTrigger: 'click' | 'hover';
    nzMatchWidthElement: ElementRef;
    nzBackdrop: boolean;
    nzClickHide: boolean;
    nzDisabled: boolean;
    nzVisible: boolean;
    nzTableFilter: boolean;
    nzOverlayClassName: string;
    nzOverlayStyle: {
        [key: string]: string;
    };
    nzPlacement: NzPlacementType;
    readonly nzVisibleChange: EventEmitter<boolean>;
    setDisabled(disabled: boolean): void;
    private getOverlayConfig;
    private createOverlay;
    updateOverlayConfig(overlayConfig: OverlayConfig): OverlayConfig;
    dispose(): void;
    private subscribeToPositions;
    private subscribeOverlayEvent;
    private getPortal;
    private openMenu;
    private closeMenu;
    private setPosition;
    private updatePositionStrategy;
    private setTriggerWidth;
    initActionSubscribe(): void;
    updateOverlayByVisible(): void;
    updateDisabledState(): void;
    regeneratePosition(placement: NzPlacementType, positions: ConnectionPositionPair[]): ConnectionPositionPair[];
    constructor(elementRef: ElementRef, renderer: Renderer2, overlay: Overlay, platform: Platform, nzButtonComponent: NzButtonComponent, nzButtonGroupComponent: NzButtonGroupComponent, viewContainerRef: ViewContainerRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzDropDownDirective>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NzDropDownDirective, "[nz-dropdown]", ["nzDropdown"], {
    "nzTrigger": "nzTrigger";
    "nzBackdrop": "nzBackdrop";
    "nzClickHide": "nzClickHide";
    "nzDisabled": "nzDisabled";
    "nzVisible": "nzVisible";
    "nzTableFilter": "nzTableFilter";
    "nzOverlayClassName": "nzOverlayClassName";
    "nzOverlayStyle": "nzOverlayStyle";
    "nzPlacement": "nzPlacement";
    "nzDropdownMenu": "nzDropdownMenu";
    "nzMatchWidthElement": "nzMatchWidthElement";
}, {
    "nzVisibleChange": "nzVisibleChange";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZHJvcGRvd24uZGlyZWN0aXZlLmQudHMiLCJzb3VyY2VzIjpbIm56LWRyb3Bkb3duLmRpcmVjdGl2ZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7OztBQWFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVEQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgQ29ubmVjdGlvblBvc2l0aW9uUGFpciwgT3ZlcmxheSwgT3ZlcmxheUNvbmZpZyB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IFBsYXRmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL3BsYXRmb3JtJztcbmltcG9ydCB7IEFmdGVyVmlld0luaXQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgT25DaGFuZ2VzLCBPbkRlc3Ryb3ksIFJlbmRlcmVyMiwgU2ltcGxlQ2hhbmdlcywgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTnpCdXR0b25Db21wb25lbnQsIE56QnV0dG9uR3JvdXBDb21wb25lbnQgfSBmcm9tICduZy16b3Jyby1hbnRkL2J1dHRvbic7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBOekRyb3Bkb3duTWVudUNvbXBvbmVudCwgTnpQbGFjZW1lbnRUeXBlIH0gZnJvbSAnLi9uei1kcm9wZG93bi1tZW51LmNvbXBvbmVudCc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekRyb3BEb3duRGlyZWN0aXZlIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXMge1xuICAgIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWY7XG4gICAgcHJpdmF0ZSByZW5kZXJlcjtcbiAgICBwcml2YXRlIG92ZXJsYXk7XG4gICAgcHJpdmF0ZSBwbGF0Zm9ybTtcbiAgICBwcml2YXRlIG56QnV0dG9uQ29tcG9uZW50O1xuICAgIHByaXZhdGUgbnpCdXR0b25Hcm91cENvbXBvbmVudDtcbiAgICBwcml2YXRlIHZpZXdDb250YWluZXJSZWY7XG4gICAgcHJpdmF0ZSBwb3J0YWw7XG4gICAgcHJpdmF0ZSBvdmVybGF5UmVmO1xuICAgIHByaXZhdGUgZGVzdHJveSQ7XG4gICAgcHJpdmF0ZSB0cmlnZ2VyV2lkdGg7XG4gICAgcHJpdmF0ZSBlbDtcbiAgICBwcml2YXRlIGRyb3Bkb3duT3BlbjtcbiAgICBwcml2YXRlIHBvc2l0aW9uU3RyYXRlZ3k7XG4gICAgcHJpdmF0ZSBwb3NpdGlvbnM7XG4gICAgcHJpdmF0ZSBwb3NpdGlvblN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIG92ZXJsYXlTdWJzY3JpcHRpb247XG4gICAgcmVhZG9ubHkgaG92ZXIkOiBPYnNlcnZhYmxlPGJvb2xlYW4+O1xuICAgIHJlYWRvbmx5ICRjbGljazogT2JzZXJ2YWJsZTxib29sZWFuPjtcbiAgICBuekRyb3Bkb3duTWVudTogTnpEcm9wZG93bk1lbnVDb21wb25lbnQ7XG4gICAgbnpUcmlnZ2VyOiAnY2xpY2snIHwgJ2hvdmVyJztcbiAgICBuek1hdGNoV2lkdGhFbGVtZW50OiBFbGVtZW50UmVmO1xuICAgIG56QmFja2Ryb3A6IGJvb2xlYW47XG4gICAgbnpDbGlja0hpZGU6IGJvb2xlYW47XG4gICAgbnpEaXNhYmxlZDogYm9vbGVhbjtcbiAgICBuelZpc2libGU6IGJvb2xlYW47XG4gICAgbnpUYWJsZUZpbHRlcjogYm9vbGVhbjtcbiAgICBuek92ZXJsYXlDbGFzc05hbWU6IHN0cmluZztcbiAgICBuek92ZXJsYXlTdHlsZToge1xuICAgICAgICBba2V5OiBzdHJpbmddOiBzdHJpbmc7XG4gICAgfTtcbiAgICBuelBsYWNlbWVudDogTnpQbGFjZW1lbnRUeXBlO1xuICAgIHJlYWRvbmx5IG56VmlzaWJsZUNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuICAgIHNldERpc2FibGVkKGRpc2FibGVkOiBib29sZWFuKTogdm9pZDtcbiAgICBwcml2YXRlIGdldE92ZXJsYXlDb25maWc7XG4gICAgcHJpdmF0ZSBjcmVhdGVPdmVybGF5O1xuICAgIHVwZGF0ZU92ZXJsYXlDb25maWcob3ZlcmxheUNvbmZpZzogT3ZlcmxheUNvbmZpZyk6IE92ZXJsYXlDb25maWc7XG4gICAgZGlzcG9zZSgpOiB2b2lkO1xuICAgIHByaXZhdGUgc3Vic2NyaWJlVG9Qb3NpdGlvbnM7XG4gICAgcHJpdmF0ZSBzdWJzY3JpYmVPdmVybGF5RXZlbnQ7XG4gICAgcHJpdmF0ZSBnZXRQb3J0YWw7XG4gICAgcHJpdmF0ZSBvcGVuTWVudTtcbiAgICBwcml2YXRlIGNsb3NlTWVudTtcbiAgICBwcml2YXRlIHNldFBvc2l0aW9uO1xuICAgIHByaXZhdGUgdXBkYXRlUG9zaXRpb25TdHJhdGVneTtcbiAgICBwcml2YXRlIHNldFRyaWdnZXJXaWR0aDtcbiAgICBpbml0QWN0aW9uU3Vic2NyaWJlKCk6IHZvaWQ7XG4gICAgdXBkYXRlT3ZlcmxheUJ5VmlzaWJsZSgpOiB2b2lkO1xuICAgIHVwZGF0ZURpc2FibGVkU3RhdGUoKTogdm9pZDtcbiAgICByZWdlbmVyYXRlUG9zaXRpb24ocGxhY2VtZW50OiBOelBsYWNlbWVudFR5cGUsIHBvc2l0aW9uczogQ29ubmVjdGlvblBvc2l0aW9uUGFpcltdKTogQ29ubmVjdGlvblBvc2l0aW9uUGFpcltdO1xuICAgIGNvbnN0cnVjdG9yKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIHJlbmRlcmVyOiBSZW5kZXJlcjIsIG92ZXJsYXk6IE92ZXJsYXksIHBsYXRmb3JtOiBQbGF0Zm9ybSwgbnpCdXR0b25Db21wb25lbnQ6IE56QnV0dG9uQ29tcG9uZW50LCBuekJ1dHRvbkdyb3VwQ29tcG9uZW50OiBOekJ1dHRvbkdyb3VwQ29tcG9uZW50LCB2aWV3Q29udGFpbmVyUmVmOiBWaWV3Q29udGFpbmVyUmVmKTtcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZDtcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkO1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkO1xufVxuIl19