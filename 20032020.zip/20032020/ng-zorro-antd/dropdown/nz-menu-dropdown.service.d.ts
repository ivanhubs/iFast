/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { NzMenuBaseService } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzMenuDropdownService extends NzMenuBaseService {
    isInDropDown: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzMenuDropdownService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzMenuDropdownService>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotbWVudS1kcm9wZG93bi5zZXJ2aWNlLmQudHMiLCJzb3VyY2VzIjpbIm56LW1lbnUtZHJvcGRvd24uc2VydmljZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7QUFRQTs7OztBQUVBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5pbXBvcnQgeyBOek1lbnVCYXNlU2VydmljZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOek1lbnVEcm9wZG93blNlcnZpY2UgZXh0ZW5kcyBOek1lbnVCYXNlU2VydmljZSB7XG4gICAgaXNJbkRyb3BEb3duOiBib29sZWFuO1xufVxuIl19