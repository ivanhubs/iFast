/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
/** keep track https://github.com/angular/material2/issues/5007 **/
import { Overlay } from '@angular/cdk/overlay';
import { NzDropdownMenuComponent } from './nz-dropdown-menu.component';
import * as ɵngcc0 from '@angular/core';
export declare class NzContextMenuService {
    private overlay;
    private overlayRef;
    private nzDropdownMenuComponent;
    private clickOutsideSubscription;
    private clickMenuSubscription;
    private positionSubscription;
    constructor(overlay: Overlay);
    create($event: MouseEvent, nzDropdownMenuComponent: NzDropdownMenuComponent): void;
    close(): void;
    private handleClickOutside;
    private attachTemplatePortal;
    private setOpenState;
    private getOverlayConfig;
    private generatePositionStrategy;
    private subscribeToPositions;
    private createOverlay;
    private updatePosition;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzContextMenuService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzContextMenuService>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY29udGV4dC1tZW51LnNlcnZpY2UuZC50cyIsInNvdXJjZXMiOlsibnotY29udGV4dC1tZW51LnNlcnZpY2UuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7QUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQkEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbi8qKiBrZWVwIHRyYWNrIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL21hdGVyaWFsMi9pc3N1ZXMvNTAwNyAqKi9cbmltcG9ydCB7IE92ZXJsYXkgfSBmcm9tICdAYW5ndWxhci9jZGsvb3ZlcmxheSc7XG5pbXBvcnQgeyBOekRyb3Bkb3duTWVudUNvbXBvbmVudCB9IGZyb20gJy4vbnotZHJvcGRvd24tbWVudS5jb21wb25lbnQnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpDb250ZXh0TWVudVNlcnZpY2Uge1xuICAgIHByaXZhdGUgb3ZlcmxheTtcbiAgICBwcml2YXRlIG92ZXJsYXlSZWY7XG4gICAgcHJpdmF0ZSBuekRyb3Bkb3duTWVudUNvbXBvbmVudDtcbiAgICBwcml2YXRlIGNsaWNrT3V0c2lkZVN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIGNsaWNrTWVudVN1YnNjcmlwdGlvbjtcbiAgICBwcml2YXRlIHBvc2l0aW9uU3Vic2NyaXB0aW9uO1xuICAgIGNvbnN0cnVjdG9yKG92ZXJsYXk6IE92ZXJsYXkpO1xuICAgIGNyZWF0ZSgkZXZlbnQ6IE1vdXNlRXZlbnQsIG56RHJvcGRvd25NZW51Q29tcG9uZW50OiBOekRyb3Bkb3duTWVudUNvbXBvbmVudCk6IHZvaWQ7XG4gICAgY2xvc2UoKTogdm9pZDtcbiAgICBwcml2YXRlIGhhbmRsZUNsaWNrT3V0c2lkZTtcbiAgICBwcml2YXRlIGF0dGFjaFRlbXBsYXRlUG9ydGFsO1xuICAgIHByaXZhdGUgc2V0T3BlblN0YXRlO1xuICAgIHByaXZhdGUgZ2V0T3ZlcmxheUNvbmZpZztcbiAgICBwcml2YXRlIGdlbmVyYXRlUG9zaXRpb25TdHJhdGVneTtcbiAgICBwcml2YXRlIHN1YnNjcmliZVRvUG9zaXRpb25zO1xuICAgIHByaXZhdGUgY3JlYXRlT3ZlcmxheTtcbiAgICBwcml2YXRlIHVwZGF0ZVBvc2l0aW9uO1xufVxuIl19