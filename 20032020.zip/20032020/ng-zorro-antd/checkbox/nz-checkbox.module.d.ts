/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-checkbox.component';
import * as ɵngcc2 from './nz-checkbox-group.component';
import * as ɵngcc3 from './nz-checkbox-wrapper.component';
import * as ɵngcc4 from '@angular/common';
import * as ɵngcc5 from '@angular/forms';
import * as ɵngcc6 from '@angular/cdk/observers';
export declare class NzCheckboxModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzCheckboxModule, [typeof ɵngcc1.NzCheckboxComponent, typeof ɵngcc2.NzCheckboxGroupComponent, typeof ɵngcc3.NzCheckboxWrapperComponent], [typeof ɵngcc4.CommonModule, typeof ɵngcc5.FormsModule, typeof ɵngcc6.ObserversModule], [typeof ɵngcc1.NzCheckboxComponent, typeof ɵngcc2.NzCheckboxGroupComponent, typeof ɵngcc3.NzCheckboxWrapperComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzCheckboxModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY2hlY2tib3gubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm56LWNoZWNrYm94Lm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7OztBQU9BOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpDaGVja2JveE1vZHVsZSB7XG59XG4iXX0=