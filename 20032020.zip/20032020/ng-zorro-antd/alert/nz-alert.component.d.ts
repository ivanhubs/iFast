/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { NgClassType, NzConfigService } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzAlertComponent implements OnChanges {
    nzConfigService: NzConfigService;
    nzCloseText: string | TemplateRef<void>;
    nzIconType: NgClassType;
    nzMessage: string | TemplateRef<void>;
    nzDescription: string | TemplateRef<void>;
    nzType: 'success' | 'info' | 'warning' | 'error';
    nzCloseable: boolean;
    nzShowIcon: boolean;
    nzBanner: boolean;
    readonly nzOnClose: EventEmitter<boolean>;
    readonly iconType: NgClassType;
    destroy: boolean;
    iconTheme: string;
    isIconTypeObject: boolean;
    private isTypeSet;
    private isShowIconSet;
    private inferredIconType;
    constructor(nzConfigService: NzConfigService);
    closeAlert(): void;
    onFadeAnimationDone(): void;
    updateIconClassMap(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzAlertComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzAlertComponent, "nz-alert", ["nzAlert"], {
    "nzType": "nzType";
    "nzBanner": "nzBanner";
    "nzShowIcon": "nzShowIcon";
    "nzCloseText": "nzCloseText";
    "nzIconType": "nzIconType";
    "nzMessage": "nzMessage";
    "nzDescription": "nzDescription";
    "nzCloseable": "nzCloseable";
}, {
    "nzOnClose": "nzOnClose";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYWxlcnQuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWFsZXJ0LmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7O0FBU0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyLCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMsIFRlbXBsYXRlUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ0NsYXNzVHlwZSwgTnpDb25maWdTZXJ2aWNlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56QWxlcnRDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAgIG56Q29uZmlnU2VydmljZTogTnpDb25maWdTZXJ2aWNlO1xuICAgIG56Q2xvc2VUZXh0OiBzdHJpbmcgfCBUZW1wbGF0ZVJlZjx2b2lkPjtcbiAgICBuekljb25UeXBlOiBOZ0NsYXNzVHlwZTtcbiAgICBuek1lc3NhZ2U6IHN0cmluZyB8IFRlbXBsYXRlUmVmPHZvaWQ+O1xuICAgIG56RGVzY3JpcHRpb246IHN0cmluZyB8IFRlbXBsYXRlUmVmPHZvaWQ+O1xuICAgIG56VHlwZTogJ3N1Y2Nlc3MnIHwgJ2luZm8nIHwgJ3dhcm5pbmcnIHwgJ2Vycm9yJztcbiAgICBuekNsb3NlYWJsZTogYm9vbGVhbjtcbiAgICBuelNob3dJY29uOiBib29sZWFuO1xuICAgIG56QmFubmVyOiBib29sZWFuO1xuICAgIHJlYWRvbmx5IG56T25DbG9zZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuICAgIHJlYWRvbmx5IGljb25UeXBlOiBOZ0NsYXNzVHlwZTtcbiAgICBkZXN0cm95OiBib29sZWFuO1xuICAgIGljb25UaGVtZTogc3RyaW5nO1xuICAgIGlzSWNvblR5cGVPYmplY3Q6IGJvb2xlYW47XG4gICAgcHJpdmF0ZSBpc1R5cGVTZXQ7XG4gICAgcHJpdmF0ZSBpc1Nob3dJY29uU2V0O1xuICAgIHByaXZhdGUgaW5mZXJyZWRJY29uVHlwZTtcbiAgICBjb25zdHJ1Y3RvcihuekNvbmZpZ1NlcnZpY2U6IE56Q29uZmlnU2VydmljZSk7XG4gICAgY2xvc2VBbGVydCgpOiB2b2lkO1xuICAgIG9uRmFkZUFuaW1hdGlvbkRvbmUoKTogdm9pZDtcbiAgICB1cGRhdGVJY29uQ2xhc3NNYXAoKTogdm9pZDtcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZDtcbn1cbiJdfQ==