/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { TemplateRef, Type } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { NzConfigService } from 'ng-zorro-antd/core';
import { NzEmptyCustomContent } from './nz-empty-config';
import * as ɵngcc0 from '@angular/core';
export declare class NzEmptyService<T = any> {
    private nzConfigService;
    private legacyDefaultEmptyContent;
    userDefaultContent$: BehaviorSubject<string | Type<any> | TemplateRef<any> | undefined>;
    constructor(nzConfigService: NzConfigService, legacyDefaultEmptyContent: Type<T>);
    setDefaultContent(content?: NzEmptyCustomContent): void;
    resetDefault(): void;
    private getUserDefaultEmptyContent;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzEmptyService<any>>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzEmptyService<any>>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZW1wdHkuc2VydmljZS5kLnRzIiwic291cmNlcyI6WyJuei1lbXB0eS5zZXJ2aWNlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7OztBQVdBOzs7Ozs7Ozs7O0FBUUEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IFRlbXBsYXRlUmVmLCBUeXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE56Q29uZmlnU2VydmljZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvY29yZSc7XG5pbXBvcnQgeyBOekVtcHR5Q3VzdG9tQ29udGVudCB9IGZyb20gJy4vbnotZW1wdHktY29uZmlnJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56RW1wdHlTZXJ2aWNlPFQgPSBhbnk+IHtcbiAgICBwcml2YXRlIG56Q29uZmlnU2VydmljZTtcbiAgICBwcml2YXRlIGxlZ2FjeURlZmF1bHRFbXB0eUNvbnRlbnQ7XG4gICAgdXNlckRlZmF1bHRDb250ZW50JDogQmVoYXZpb3JTdWJqZWN0PHN0cmluZyB8IFR5cGU8YW55PiB8IFRlbXBsYXRlUmVmPGFueT4gfCB1bmRlZmluZWQ+O1xuICAgIGNvbnN0cnVjdG9yKG56Q29uZmlnU2VydmljZTogTnpDb25maWdTZXJ2aWNlLCBsZWdhY3lEZWZhdWx0RW1wdHlDb250ZW50OiBUeXBlPFQ+KTtcbiAgICBzZXREZWZhdWx0Q29udGVudChjb250ZW50PzogTnpFbXB0eUN1c3RvbUNvbnRlbnQpOiB2b2lkO1xuICAgIHJlc2V0RGVmYXVsdCgpOiB2b2lkO1xuICAgIHByaXZhdGUgZ2V0VXNlckRlZmF1bHRFbXB0eUNvbnRlbnQ7XG59XG4iXX0=