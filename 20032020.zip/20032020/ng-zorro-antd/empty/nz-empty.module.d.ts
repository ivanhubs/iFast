/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-empty.component';
import * as ɵngcc2 from './nz-embed-empty.component';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from '@angular/cdk/portal';
import * as ɵngcc5 from 'ng-zorro-antd/core';
import * as ɵngcc6 from 'ng-zorro-antd/i18n';
export declare class NzEmptyModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzEmptyModule, [typeof ɵngcc1.NzEmptyComponent, typeof ɵngcc2.NzEmbedEmptyComponent], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.PortalModule, typeof ɵngcc5.NzAddOnModule, typeof ɵngcc6.NzI18nModule], [typeof ɵngcc1.NzEmptyComponent, typeof ɵngcc2.NzEmbedEmptyComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzEmptyModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZW1wdHkubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm56LWVtcHR5Lm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7OztBQU9BOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpFbXB0eU1vZHVsZSB7XG59XG4iXX0=