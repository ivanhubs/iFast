/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { NzConfigService, NzScrollService } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
interface SimpleRect {
    top: number;
    left: number;
    width?: number;
    height?: number;
    bottom?: number;
}
export declare class NzAffixComponent implements AfterViewInit, OnChanges, OnDestroy {
    nzConfigService: NzConfigService;
    private scrollSrv;
    private ngZone;
    private platform;
    private fixedEl;
    nzTarget: string | Element | Window;
    nzOffsetTop: null | number;
    nzOffsetBottom: null | number;
    readonly nzChange: EventEmitter<boolean>;
    private readonly placeholderNode;
    private affixStyle?;
    private placeholderStyle?;
    private scroll$;
    private timeout?;
    private document;
    private readonly target;
    constructor(el: ElementRef, doc: any, // tslint:disable-line no-any
    nzConfigService: NzConfigService, scrollSrv: NzScrollService, ngZone: NgZone, platform: Platform);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private registerListeners;
    private removeListeners;
    getOffset(element: Element, target: Element | Window | undefined): SimpleRect;
    private getTargetRect;
    private setAffixStyle;
    private setPlaceholderStyle;
    private syncPlaceholderStyle;
    updatePosition(e: Event): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzAffixComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzAffixComponent, "nz-affix", ["nzAffix"], {
    "nzTarget": "nzTarget";
    "nzOffsetTop": "nzOffsetTop";
    "nzOffsetBottom": "nzOffsetBottom";
}, {
    "nzChange": "nzChange";
}, never>;
}
export {};

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYWZmaXguY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWFmZml4LmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IFBsYXRmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL3BsYXRmb3JtJztcbmltcG9ydCB7IEFmdGVyVmlld0luaXQsIEVsZW1lbnRSZWYsIEV2ZW50RW1pdHRlciwgTmdab25lLCBPbkNoYW5nZXMsIE9uRGVzdHJveSwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTnpDb25maWdTZXJ2aWNlLCBOelNjcm9sbFNlcnZpY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL2NvcmUnO1xuaW50ZXJmYWNlIFNpbXBsZVJlY3Qge1xuICAgIHRvcDogbnVtYmVyO1xuICAgIGxlZnQ6IG51bWJlcjtcbiAgICB3aWR0aD86IG51bWJlcjtcbiAgICBoZWlnaHQ/OiBudW1iZXI7XG4gICAgYm90dG9tPzogbnVtYmVyO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpBZmZpeENvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcbiAgICBuekNvbmZpZ1NlcnZpY2U6IE56Q29uZmlnU2VydmljZTtcbiAgICBwcml2YXRlIHNjcm9sbFNydjtcbiAgICBwcml2YXRlIG5nWm9uZTtcbiAgICBwcml2YXRlIHBsYXRmb3JtO1xuICAgIHByaXZhdGUgZml4ZWRFbDtcbiAgICBuelRhcmdldDogc3RyaW5nIHwgRWxlbWVudCB8IFdpbmRvdztcbiAgICBuek9mZnNldFRvcDogbnVsbCB8IG51bWJlcjtcbiAgICBuek9mZnNldEJvdHRvbTogbnVsbCB8IG51bWJlcjtcbiAgICByZWFkb25seSBuekNoYW5nZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+O1xuICAgIHByaXZhdGUgcmVhZG9ubHkgcGxhY2Vob2xkZXJOb2RlO1xuICAgIHByaXZhdGUgYWZmaXhTdHlsZT87XG4gICAgcHJpdmF0ZSBwbGFjZWhvbGRlclN0eWxlPztcbiAgICBwcml2YXRlIHNjcm9sbCQ7XG4gICAgcHJpdmF0ZSB0aW1lb3V0PztcbiAgICBwcml2YXRlIGRvY3VtZW50O1xuICAgIHByaXZhdGUgcmVhZG9ubHkgdGFyZ2V0O1xuICAgIGNvbnN0cnVjdG9yKGVsOiBFbGVtZW50UmVmLCBkb2M6IGFueSwgLy8gdHNsaW50OmRpc2FibGUtbGluZSBuby1hbnlcbiAgICBuekNvbmZpZ1NlcnZpY2U6IE56Q29uZmlnU2VydmljZSwgc2Nyb2xsU3J2OiBOelNjcm9sbFNlcnZpY2UsIG5nWm9uZTogTmdab25lLCBwbGF0Zm9ybTogUGxhdGZvcm0pO1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkO1xuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkO1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQ7XG4gICAgcHJpdmF0ZSByZWdpc3Rlckxpc3RlbmVycztcbiAgICBwcml2YXRlIHJlbW92ZUxpc3RlbmVycztcbiAgICBnZXRPZmZzZXQoZWxlbWVudDogRWxlbWVudCwgdGFyZ2V0OiBFbGVtZW50IHwgV2luZG93IHwgdW5kZWZpbmVkKTogU2ltcGxlUmVjdDtcbiAgICBwcml2YXRlIGdldFRhcmdldFJlY3Q7XG4gICAgcHJpdmF0ZSBzZXRBZmZpeFN0eWxlO1xuICAgIHByaXZhdGUgc2V0UGxhY2Vob2xkZXJTdHlsZTtcbiAgICBwcml2YXRlIHN5bmNQbGFjZWhvbGRlclN0eWxlO1xuICAgIHVwZGF0ZVBvc2l0aW9uKGU6IEV2ZW50KTogdm9pZDtcbn1cbmV4cG9ydCB7fTtcbiJdfQ==