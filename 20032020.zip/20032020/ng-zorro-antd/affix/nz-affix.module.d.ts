import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-affix.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/cdk/platform';
export declare class NzAffixModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzAffixModule, [typeof ɵngcc1.NzAffixComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.PlatformModule], [typeof ɵngcc1.NzAffixComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzAffixModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYWZmaXgubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm56LWFmZml4Lm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVjbGFyZSBjbGFzcyBOekFmZml4TW9kdWxlIHtcbn1cbiJdfQ==