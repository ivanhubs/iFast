/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-drawer.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/cdk/overlay';
import * as ɵngcc4 from '@angular/cdk/portal';
import * as ɵngcc5 from 'ng-zorro-antd/icon';
import * as ɵngcc6 from 'ng-zorro-antd/core';
import * as ɵngcc7 from './nz-drawer.service.module';
export declare class NzDrawerModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzDrawerModule, [typeof ɵngcc1.NzDrawerComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.OverlayModule, typeof ɵngcc4.PortalModule, typeof ɵngcc5.NzIconModule, typeof ɵngcc6.NzAddOnModule, typeof ɵngcc6.NzNoAnimationModule, typeof ɵngcc7.NzDrawerServiceModule], [typeof ɵngcc1.NzDrawerComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzDrawerModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZHJhd2VyLm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJuei1kcmF3ZXIubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7OztBQU9BOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpEcmF3ZXJNb2R1bGUge1xufVxuIl19