/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Overlay } from '@angular/cdk/overlay';
import { NzDrawerOptions, NzDrawerOptionsOfComponent } from './nz-drawer-options';
import { NzDrawerRef } from './nz-drawer-ref';
import * as ɵngcc0 from '@angular/core';
export declare class DrawerBuilderForService<R> {
    private overlay;
    private options;
    private drawerRef;
    private overlayRef;
    private unsubscribe$;
    constructor(overlay: Overlay, options: NzDrawerOptions);
    getInstance(): NzDrawerRef<R>;
    createDrawer(): void;
    updateOptions(options: NzDrawerOptionsOfComponent): void;
}
export declare class NzDrawerService {
    private overlay;
    constructor(overlay: Overlay);
    create<T = any, D = any, R = any>(options: NzDrawerOptions<T, D>): NzDrawerRef<R>;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzDrawerService>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NzDrawerService>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotZHJhd2VyLnNlcnZpY2UuZC50cyIsInNvdXJjZXMiOlsibnotZHJhd2VyLnNlcnZpY2UuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7QUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFlQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgT3ZlcmxheSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IE56RHJhd2VyT3B0aW9ucywgTnpEcmF3ZXJPcHRpb25zT2ZDb21wb25lbnQgfSBmcm9tICcuL256LWRyYXdlci1vcHRpb25zJztcbmltcG9ydCB7IE56RHJhd2VyUmVmIH0gZnJvbSAnLi9uei1kcmF3ZXItcmVmJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIERyYXdlckJ1aWxkZXJGb3JTZXJ2aWNlPFI+IHtcbiAgICBwcml2YXRlIG92ZXJsYXk7XG4gICAgcHJpdmF0ZSBvcHRpb25zO1xuICAgIHByaXZhdGUgZHJhd2VyUmVmO1xuICAgIHByaXZhdGUgb3ZlcmxheVJlZjtcbiAgICBwcml2YXRlIHVuc3Vic2NyaWJlJDtcbiAgICBjb25zdHJ1Y3RvcihvdmVybGF5OiBPdmVybGF5LCBvcHRpb25zOiBOekRyYXdlck9wdGlvbnMpO1xuICAgIGdldEluc3RhbmNlKCk6IE56RHJhd2VyUmVmPFI+O1xuICAgIGNyZWF0ZURyYXdlcigpOiB2b2lkO1xuICAgIHVwZGF0ZU9wdGlvbnMob3B0aW9uczogTnpEcmF3ZXJPcHRpb25zT2ZDb21wb25lbnQpOiB2b2lkO1xufVxuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTnpEcmF3ZXJTZXJ2aWNlIHtcbiAgICBwcml2YXRlIG92ZXJsYXk7XG4gICAgY29uc3RydWN0b3Iob3ZlcmxheTogT3ZlcmxheSk7XG4gICAgY3JlYXRlPFQgPSBhbnksIEQgPSBhbnksIFIgPSBhbnk+KG9wdGlvbnM6IE56RHJhd2VyT3B0aW9uczxULCBEPik6IE56RHJhd2VyUmVmPFI+O1xufVxuIl19