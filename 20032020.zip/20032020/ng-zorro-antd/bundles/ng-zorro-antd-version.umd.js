(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
	typeof define === 'function' && define.amd ? define('ng-zorro-antd/version', ['exports', '@angular/core'], factory) :
	(global = global || self, factory((global['ng-zorro-antd'] = global['ng-zorro-antd'] || {}, global['ng-zorro-antd'].version = {}), global.ng.core));
}(this, (function (exports, core) { 'use strict';

	/**
	 * @fileoverview added by tsickle
	 * Generated from: version.ts
	 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
	 */
	/** @type {?} */
	var VERSION = new core.Version('8.5.2');

	exports.VERSION = VERSION;

	Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-zorro-antd-version.umd.js.map
