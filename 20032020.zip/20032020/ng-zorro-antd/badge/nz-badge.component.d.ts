/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ContentObserver } from '@angular/cdk/observers';
import { AfterViewInit, ChangeDetectorRef, ElementRef, NgZone, OnChanges, OnDestroy, OnInit, Renderer2, SimpleChanges, TemplateRef } from '@angular/core';
import { NzConfigService } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
export declare type NzBadgeStatusType = 'success' | 'processing' | 'default' | 'error' | 'warning';
export declare class NzBadgeComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
    nzConfigService: NzConfigService;
    private renderer;
    private elementRef;
    private contentObserver;
    private cdr;
    private ngZone;
    private destroy$;
    notWrapper: boolean;
    viewInit: boolean;
    maxNumberArray: string[];
    countArray: number[];
    countSingleArray: number[];
    colorArray: string[];
    presetColor: string | null;
    count: number;
    contentElement: ElementRef;
    nzShowZero: boolean;
    nzShowDot: boolean;
    nzDot: boolean;
    nzOverflowCount: number;
    nzText: string;
    nzColor: string;
    nzTitle: string;
    nzStyle: {
        [key: string]: string;
    };
    nzStatus: NzBadgeStatusType;
    nzCount: number | TemplateRef<void>;
    nzOffset: [number, number];
    checkContent(): void;
    readonly showSup: boolean;
    generateMaxNumberArray(): void;
    constructor(nzConfigService: NzConfigService, renderer: Renderer2, elementRef: ElementRef, contentObserver: ContentObserver, cdr: ChangeDetectorRef, ngZone: NgZone);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzBadgeComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzBadgeComponent, "nz-badge", ["nzBadge"], {
    "nzShowZero": "nzShowZero";
    "nzShowDot": "nzShowDot";
    "nzDot": "nzDot";
    "nzOverflowCount": "nzOverflowCount";
    "nzText": "nzText";
    "nzColor": "nzColor";
    "nzTitle": "nzTitle";
    "nzStyle": "nzStyle";
    "nzStatus": "nzStatus";
    "nzCount": "nzCount";
    "nzOffset": "nzOffset";
}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYmFkZ2UuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWJhZGdlLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgQ29udGVudE9ic2VydmVyIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL29ic2VydmVycyc7XG5pbXBvcnQgeyBBZnRlclZpZXdJbml0LCBDaGFuZ2VEZXRlY3RvclJlZiwgRWxlbWVudFJlZiwgTmdab25lLCBPbkNoYW5nZXMsIE9uRGVzdHJveSwgT25Jbml0LCBSZW5kZXJlcjIsIFNpbXBsZUNoYW5nZXMsIFRlbXBsYXRlUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOekNvbmZpZ1NlcnZpY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL2NvcmUnO1xuZXhwb3J0IGRlY2xhcmUgdHlwZSBOekJhZGdlU3RhdHVzVHlwZSA9ICdzdWNjZXNzJyB8ICdwcm9jZXNzaW5nJyB8ICdkZWZhdWx0JyB8ICdlcnJvcicgfCAnd2FybmluZyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekJhZGdlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XG4gICAgbnpDb25maWdTZXJ2aWNlOiBOekNvbmZpZ1NlcnZpY2U7XG4gICAgcHJpdmF0ZSByZW5kZXJlcjtcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY7XG4gICAgcHJpdmF0ZSBjb250ZW50T2JzZXJ2ZXI7XG4gICAgcHJpdmF0ZSBjZHI7XG4gICAgcHJpdmF0ZSBuZ1pvbmU7XG4gICAgcHJpdmF0ZSBkZXN0cm95JDtcbiAgICBub3RXcmFwcGVyOiBib29sZWFuO1xuICAgIHZpZXdJbml0OiBib29sZWFuO1xuICAgIG1heE51bWJlckFycmF5OiBzdHJpbmdbXTtcbiAgICBjb3VudEFycmF5OiBudW1iZXJbXTtcbiAgICBjb3VudFNpbmdsZUFycmF5OiBudW1iZXJbXTtcbiAgICBjb2xvckFycmF5OiBzdHJpbmdbXTtcbiAgICBwcmVzZXRDb2xvcjogc3RyaW5nIHwgbnVsbDtcbiAgICBjb3VudDogbnVtYmVyO1xuICAgIGNvbnRlbnRFbGVtZW50OiBFbGVtZW50UmVmO1xuICAgIG56U2hvd1plcm86IGJvb2xlYW47XG4gICAgbnpTaG93RG90OiBib29sZWFuO1xuICAgIG56RG90OiBib29sZWFuO1xuICAgIG56T3ZlcmZsb3dDb3VudDogbnVtYmVyO1xuICAgIG56VGV4dDogc3RyaW5nO1xuICAgIG56Q29sb3I6IHN0cmluZztcbiAgICBuelRpdGxlOiBzdHJpbmc7XG4gICAgbnpTdHlsZToge1xuICAgICAgICBba2V5OiBzdHJpbmddOiBzdHJpbmc7XG4gICAgfTtcbiAgICBuelN0YXR1czogTnpCYWRnZVN0YXR1c1R5cGU7XG4gICAgbnpDb3VudDogbnVtYmVyIHwgVGVtcGxhdGVSZWY8dm9pZD47XG4gICAgbnpPZmZzZXQ6IFtudW1iZXIsIG51bWJlcl07XG4gICAgY2hlY2tDb250ZW50KCk6IHZvaWQ7XG4gICAgcmVhZG9ubHkgc2hvd1N1cDogYm9vbGVhbjtcbiAgICBnZW5lcmF0ZU1heE51bWJlckFycmF5KCk6IHZvaWQ7XG4gICAgY29uc3RydWN0b3IobnpDb25maWdTZXJ2aWNlOiBOekNvbmZpZ1NlcnZpY2UsIHJlbmRlcmVyOiBSZW5kZXJlcjIsIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIGNvbnRlbnRPYnNlcnZlcjogQ29udGVudE9ic2VydmVyLCBjZHI6IENoYW5nZURldGVjdG9yUmVmLCBuZ1pvbmU6IE5nWm9uZSk7XG4gICAgbmdPbkluaXQoKTogdm9pZDtcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZDtcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZDtcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkO1xufVxuIl19