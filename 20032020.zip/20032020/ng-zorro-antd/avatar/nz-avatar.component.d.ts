/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { Platform } from '@angular/cdk/platform';
import { ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, Renderer2, SimpleChanges } from '@angular/core';
import { NzConfigService, NzShapeSCType, NzSizeLDSType, NzUpdateHostClassService } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzAvatarComponent implements OnChanges {
    nzConfigService: NzConfigService;
    private elementRef;
    private cd;
    private updateHostClassService;
    private renderer;
    private platform;
    nzShape: NzShapeSCType;
    nzSize: NzSizeLDSType | number;
    nzText: string;
    nzSrc: string;
    nzSrcSet: string;
    nzAlt: string;
    nzIcon: string;
    readonly nzError: EventEmitter<Event>;
    oldAPIIcon: boolean;
    hasText: boolean;
    hasSrc: boolean;
    hasIcon: boolean;
    textStyles: {};
    textEl: ElementRef;
    private el;
    private prefixCls;
    private sizeMap;
    constructor(nzConfigService: NzConfigService, elementRef: ElementRef, cd: ChangeDetectorRef, updateHostClassService: NzUpdateHostClassService, renderer: Renderer2, platform: Platform);
    setClass(): this;
    imgError($event: Event): void;
    ngOnChanges(changes: SimpleChanges): void;
    private calcStringSize;
    private notifyCalc;
    private setSizeStyle;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzAvatarComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzAvatarComponent, "nz-avatar", ["nzAvatar"], {
    "nzShape": "nzShape";
    "nzSize": "nzSize";
    "nzText": "nzText";
    "nzSrc": "nzSrc";
    "nzSrcSet": "nzSrcSet";
    "nzAlt": "nzAlt";
    "nzIcon": "nzIcon";
}, {
    "nzError": "nzError";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYXZhdGFyLmNvbXBvbmVudC5kLnRzIiwic291cmNlcyI6WyJuei1hdmF0YXIuY29tcG9uZW50LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUErQkEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IFBsYXRmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL3BsYXRmb3JtJztcbmltcG9ydCB7IENoYW5nZURldGVjdG9yUmVmLCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIsIE9uQ2hhbmdlcywgUmVuZGVyZXIyLCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOekNvbmZpZ1NlcnZpY2UsIE56U2hhcGVTQ1R5cGUsIE56U2l6ZUxEU1R5cGUsIE56VXBkYXRlSG9zdENsYXNzU2VydmljZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekF2YXRhckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgbnpDb25maWdTZXJ2aWNlOiBOekNvbmZpZ1NlcnZpY2U7XG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmO1xuICAgIHByaXZhdGUgY2Q7XG4gICAgcHJpdmF0ZSB1cGRhdGVIb3N0Q2xhc3NTZXJ2aWNlO1xuICAgIHByaXZhdGUgcmVuZGVyZXI7XG4gICAgcHJpdmF0ZSBwbGF0Zm9ybTtcbiAgICBuelNoYXBlOiBOelNoYXBlU0NUeXBlO1xuICAgIG56U2l6ZTogTnpTaXplTERTVHlwZSB8IG51bWJlcjtcbiAgICBuelRleHQ6IHN0cmluZztcbiAgICBuelNyYzogc3RyaW5nO1xuICAgIG56U3JjU2V0OiBzdHJpbmc7XG4gICAgbnpBbHQ6IHN0cmluZztcbiAgICBuekljb246IHN0cmluZztcbiAgICByZWFkb25seSBuekVycm9yOiBFdmVudEVtaXR0ZXI8RXZlbnQ+O1xuICAgIG9sZEFQSUljb246IGJvb2xlYW47XG4gICAgaGFzVGV4dDogYm9vbGVhbjtcbiAgICBoYXNTcmM6IGJvb2xlYW47XG4gICAgaGFzSWNvbjogYm9vbGVhbjtcbiAgICB0ZXh0U3R5bGVzOiB7fTtcbiAgICB0ZXh0RWw6IEVsZW1lbnRSZWY7XG4gICAgcHJpdmF0ZSBlbDtcbiAgICBwcml2YXRlIHByZWZpeENscztcbiAgICBwcml2YXRlIHNpemVNYXA7XG4gICAgY29uc3RydWN0b3IobnpDb25maWdTZXJ2aWNlOiBOekNvbmZpZ1NlcnZpY2UsIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIGNkOiBDaGFuZ2VEZXRlY3RvclJlZiwgdXBkYXRlSG9zdENsYXNzU2VydmljZTogTnpVcGRhdGVIb3N0Q2xhc3NTZXJ2aWNlLCByZW5kZXJlcjogUmVuZGVyZXIyLCBwbGF0Zm9ybTogUGxhdGZvcm0pO1xuICAgIHNldENsYXNzKCk6IHRoaXM7XG4gICAgaW1nRXJyb3IoJGV2ZW50OiBFdmVudCk6IHZvaWQ7XG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQ7XG4gICAgcHJpdmF0ZSBjYWxjU3RyaW5nU2l6ZTtcbiAgICBwcml2YXRlIG5vdGlmeUNhbGM7XG4gICAgcHJpdmF0ZSBzZXRTaXplU3R5bGU7XG59XG4iXX0=