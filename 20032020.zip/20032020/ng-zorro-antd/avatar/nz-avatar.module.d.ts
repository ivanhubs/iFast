import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-avatar.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from 'ng-zorro-antd/icon';
import * as ɵngcc4 from '@angular/cdk/platform';
export declare class NzAvatarModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzAvatarModule, [typeof ɵngcc1.NzAvatarComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.NzIconModule, typeof ɵngcc4.PlatformModule], [typeof ɵngcc1.NzAvatarComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzAvatarModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYXZhdGFyLm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJuei1hdmF0YXIubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVjbGFyZSBjbGFzcyBOekF2YXRhck1vZHVsZSB7XG59XG4iXX0=