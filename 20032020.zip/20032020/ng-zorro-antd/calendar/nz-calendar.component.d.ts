/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, EventEmitter, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { CandyDate } from 'ng-zorro-antd/core';
import * as ɵngcc0 from '@angular/core';
export declare type ModeType = 'month' | 'year';
export declare type DateTemplate = TemplateRef<{
    $implicit: Date;
}>;
export declare class NzCalendarComponent implements ControlValueAccessor {
    private cdr;
    activeDate: CandyDate;
    prefixCls: string;
    private onChangeFn;
    private onTouchFn;
    nzMode: ModeType;
    readonly nzModeChange: EventEmitter<ModeType>;
    readonly nzPanelChange: EventEmitter<{
        date: Date;
        mode: ModeType;
    }>;
    readonly nzSelectChange: EventEmitter<Date>;
    nzValue: Date;
    readonly nzValueChange: EventEmitter<Date>;
    /**
     * Cannot use @Input and @ContentChild on one variable
     * because { static: false } will make @Input property get delayed
     **/
    nzDateCell: DateTemplate;
    nzDateCellChild: DateTemplate;
    readonly dateCell: DateTemplate;
    nzDateFullCell: DateTemplate;
    nzDateFullCellChild: DateTemplate;
    readonly dateFullCell: DateTemplate;
    nzMonthCell: DateTemplate;
    nzMonthCellChild: DateTemplate;
    readonly monthCell: DateTemplate;
    nzMonthFullCell: DateTemplate;
    nzMonthFullCellChild: DateTemplate;
    readonly monthFullCell: DateTemplate;
    nzFullscreen: boolean;
    /**
     * @deprecated use `[nzFullscreen]` instead.
     */
    nzCard: boolean;
    constructor(cdr: ChangeDetectorRef);
    onModeChange(mode: ModeType): void;
    onYearSelect(year: number): void;
    onMonthSelect(month: number): void;
    onDateSelect(date: CandyDate): void;
    writeValue(value: Date | null): void;
    registerOnChange(fn: (date: Date) => void): void;
    registerOnTouched(fn: () => void): void;
    private updateDate;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzCalendarComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzCalendarComponent, "nz-calendar", ["nzCalendar"], {
    "nzMode": "nzMode";
    "nzFullscreen": "nzFullscreen";
    "nzValue": "nzValue";
    "nzCard": "nzCard";
    "nzDateCell": "nzDateCell";
    "nzDateFullCell": "nzDateFullCell";
    "nzMonthCell": "nzMonthCell";
    "nzMonthFullCell": "nzMonthFullCell";
}, {
    "nzModeChange": "nzModeChange";
    "nzPanelChange": "nzPanelChange";
    "nzSelectChange": "nzSelectChange";
    "nzValueChange": "nzValueChange";
}, ["nzDateCellChild", "nzDateFullCellChild", "nzMonthCellChild", "nzMonthFullCellChild"]>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY2FsZW5kYXIuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbIm56LWNhbGVuZGFyLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWlEQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0b3JSZWYsIEV2ZW50RW1pdHRlciwgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQ2FuZHlEYXRlIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIHR5cGUgTW9kZVR5cGUgPSAnbW9udGgnIHwgJ3llYXInO1xuZXhwb3J0IGRlY2xhcmUgdHlwZSBEYXRlVGVtcGxhdGUgPSBUZW1wbGF0ZVJlZjx7XG4gICAgJGltcGxpY2l0OiBEYXRlO1xufT47XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekNhbGVuZGFyQ29tcG9uZW50IGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuICAgIHByaXZhdGUgY2RyO1xuICAgIGFjdGl2ZURhdGU6IENhbmR5RGF0ZTtcbiAgICBwcmVmaXhDbHM6IHN0cmluZztcbiAgICBwcml2YXRlIG9uQ2hhbmdlRm47XG4gICAgcHJpdmF0ZSBvblRvdWNoRm47XG4gICAgbnpNb2RlOiBNb2RlVHlwZTtcbiAgICByZWFkb25seSBuek1vZGVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxNb2RlVHlwZT47XG4gICAgcmVhZG9ubHkgbnpQYW5lbENoYW5nZTogRXZlbnRFbWl0dGVyPHtcbiAgICAgICAgZGF0ZTogRGF0ZTtcbiAgICAgICAgbW9kZTogTW9kZVR5cGU7XG4gICAgfT47XG4gICAgcmVhZG9ubHkgbnpTZWxlY3RDaGFuZ2U6IEV2ZW50RW1pdHRlcjxEYXRlPjtcbiAgICBuelZhbHVlOiBEYXRlO1xuICAgIHJlYWRvbmx5IG56VmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxEYXRlPjtcbiAgICAvKipcbiAgICAgKiBDYW5ub3QgdXNlIEBJbnB1dCBhbmQgQENvbnRlbnRDaGlsZCBvbiBvbmUgdmFyaWFibGVcbiAgICAgKiBiZWNhdXNlIHsgc3RhdGljOiBmYWxzZSB9IHdpbGwgbWFrZSBASW5wdXQgcHJvcGVydHkgZ2V0IGRlbGF5ZWRcbiAgICAgKiovXG4gICAgbnpEYXRlQ2VsbDogRGF0ZVRlbXBsYXRlO1xuICAgIG56RGF0ZUNlbGxDaGlsZDogRGF0ZVRlbXBsYXRlO1xuICAgIHJlYWRvbmx5IGRhdGVDZWxsOiBEYXRlVGVtcGxhdGU7XG4gICAgbnpEYXRlRnVsbENlbGw6IERhdGVUZW1wbGF0ZTtcbiAgICBuekRhdGVGdWxsQ2VsbENoaWxkOiBEYXRlVGVtcGxhdGU7XG4gICAgcmVhZG9ubHkgZGF0ZUZ1bGxDZWxsOiBEYXRlVGVtcGxhdGU7XG4gICAgbnpNb250aENlbGw6IERhdGVUZW1wbGF0ZTtcbiAgICBuek1vbnRoQ2VsbENoaWxkOiBEYXRlVGVtcGxhdGU7XG4gICAgcmVhZG9ubHkgbW9udGhDZWxsOiBEYXRlVGVtcGxhdGU7XG4gICAgbnpNb250aEZ1bGxDZWxsOiBEYXRlVGVtcGxhdGU7XG4gICAgbnpNb250aEZ1bGxDZWxsQ2hpbGQ6IERhdGVUZW1wbGF0ZTtcbiAgICByZWFkb25seSBtb250aEZ1bGxDZWxsOiBEYXRlVGVtcGxhdGU7XG4gICAgbnpGdWxsc2NyZWVuOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIEBkZXByZWNhdGVkIHVzZSBgW256RnVsbHNjcmVlbl1gIGluc3RlYWQuXG4gICAgICovXG4gICAgbnpDYXJkOiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWYpO1xuICAgIG9uTW9kZUNoYW5nZShtb2RlOiBNb2RlVHlwZSk6IHZvaWQ7XG4gICAgb25ZZWFyU2VsZWN0KHllYXI6IG51bWJlcik6IHZvaWQ7XG4gICAgb25Nb250aFNlbGVjdChtb250aDogbnVtYmVyKTogdm9pZDtcbiAgICBvbkRhdGVTZWxlY3QoZGF0ZTogQ2FuZHlEYXRlKTogdm9pZDtcbiAgICB3cml0ZVZhbHVlKHZhbHVlOiBEYXRlIHwgbnVsbCk6IHZvaWQ7XG4gICAgcmVnaXN0ZXJPbkNoYW5nZShmbjogKGRhdGU6IERhdGUpID0+IHZvaWQpOiB2b2lkO1xuICAgIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoKSA9PiB2b2lkKTogdm9pZDtcbiAgICBwcml2YXRlIHVwZGF0ZURhdGU7XG59XG4iXX0=