/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { CandyDate, FunctionProp } from 'ng-zorro-antd/core';
import { DateHelperService, NzCalendarI18nInterface, NzI18nService } from 'ng-zorro-antd/i18n';
import * as ɵngcc0 from '@angular/core';
export declare class DateTableComponent implements OnChanges, OnInit {
    private i18n;
    private dateHelper;
    _value: CandyDate;
    headWeekDays: WeekDayLabel[];
    weekRows: WeekRow[];
    prefixCls: string;
    locale: NzCalendarI18nInterface;
    selectedValue: CandyDate[];
    hoverValue: CandyDate[];
    value: CandyDate;
    activeDate: CandyDate;
    showWeek: boolean;
    disabledDate: (d: Date) => boolean;
    dateCellRender: FunctionProp<TemplateRef<Date> | string>;
    dateFullCellRender: FunctionProp<TemplateRef<Date> | string>;
    readonly dayHover: EventEmitter<CandyDate>;
    readonly valueChange: EventEmitter<CandyDate>;
    constructor(i18n: NzI18nService, dateHelper: DateHelperService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private isDateRealChange;
    private isSameDate;
    private render;
    private changeValueFromInside;
    private makeHeadWeekDays;
    private getVeryShortWeekFormat;
    private makeWeekRows;
    trackByDateFn(_index: number, item: DateCell): string;
    trackByWeekFn(_index: number, item: WeekRow): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<DateTableComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<DateTableComponent, "date-table", ["dateTable"], {
    "prefixCls": "prefixCls";
    "showWeek": "showWeek";
    "value": "value";
    "activeDate": "activeDate";
    "locale": "locale";
    "selectedValue": "selectedValue";
    "hoverValue": "hoverValue";
    "disabledDate": "disabledDate";
    "dateCellRender": "dateCellRender";
    "dateFullCellRender": "dateFullCellRender";
}, {
    "dayHover": "dayHover";
    "valueChange": "valueChange";
}, never>;
}
export interface WeekDayLabel {
    short: string;
    veryShort: string;
}
export interface DateCell {
    value: Date;
    label: string;
    title: string;
    dateCellRender: TemplateRef<Date> | string;
    dateFullCellRender: TemplateRef<Date> | string;
    content: string;
    isSelected?: boolean;
    isToday?: boolean;
    isDisabled?: boolean;
    isSelectedStartDate?: boolean;
    isSelectedEndDate?: boolean;
    isInRange?: boolean;
    classMap?: object;
    onClick(date: CandyDate): void;
    onMouseEnter(): void;
}
export interface WeekRow {
    isCurrent?: boolean;
    isActive?: boolean;
    weekNum?: number;
    year?: number;
    classMap?: object;
    dateCells: DateCell[];
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS10YWJsZS5jb21wb25lbnQuZC50cyIsInNvdXJjZXMiOlsiZGF0ZS10YWJsZS5jb21wb25lbnQuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7QUFVQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQThCQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBbGliYWJhLmNvbSBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZSBsaWNlbnNlIHRoYXQgY2FuIGJlXG4gKiBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ORy1aT1JSTy9uZy16b3Jyby1hbnRkL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyLCBPbkNoYW5nZXMsIE9uSW5pdCwgU2ltcGxlQ2hhbmdlcywgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENhbmR5RGF0ZSwgRnVuY3Rpb25Qcm9wIH0gZnJvbSAnbmctem9ycm8tYW50ZC9jb3JlJztcbmltcG9ydCB7IERhdGVIZWxwZXJTZXJ2aWNlLCBOekNhbGVuZGFySTE4bkludGVyZmFjZSwgTnpJMThuU2VydmljZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvaTE4bic7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBEYXRlVGFibGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMsIE9uSW5pdCB7XG4gICAgcHJpdmF0ZSBpMThuO1xuICAgIHByaXZhdGUgZGF0ZUhlbHBlcjtcbiAgICBfdmFsdWU6IENhbmR5RGF0ZTtcbiAgICBoZWFkV2Vla0RheXM6IFdlZWtEYXlMYWJlbFtdO1xuICAgIHdlZWtSb3dzOiBXZWVrUm93W107XG4gICAgcHJlZml4Q2xzOiBzdHJpbmc7XG4gICAgbG9jYWxlOiBOekNhbGVuZGFySTE4bkludGVyZmFjZTtcbiAgICBzZWxlY3RlZFZhbHVlOiBDYW5keURhdGVbXTtcbiAgICBob3ZlclZhbHVlOiBDYW5keURhdGVbXTtcbiAgICB2YWx1ZTogQ2FuZHlEYXRlO1xuICAgIGFjdGl2ZURhdGU6IENhbmR5RGF0ZTtcbiAgICBzaG93V2VlazogYm9vbGVhbjtcbiAgICBkaXNhYmxlZERhdGU6IChkOiBEYXRlKSA9PiBib29sZWFuO1xuICAgIGRhdGVDZWxsUmVuZGVyOiBGdW5jdGlvblByb3A8VGVtcGxhdGVSZWY8RGF0ZT4gfCBzdHJpbmc+O1xuICAgIGRhdGVGdWxsQ2VsbFJlbmRlcjogRnVuY3Rpb25Qcm9wPFRlbXBsYXRlUmVmPERhdGU+IHwgc3RyaW5nPjtcbiAgICByZWFkb25seSBkYXlIb3ZlcjogRXZlbnRFbWl0dGVyPENhbmR5RGF0ZT47XG4gICAgcmVhZG9ubHkgdmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxDYW5keURhdGU+O1xuICAgIGNvbnN0cnVjdG9yKGkxOG46IE56STE4blNlcnZpY2UsIGRhdGVIZWxwZXI6IERhdGVIZWxwZXJTZXJ2aWNlKTtcbiAgICBuZ09uSW5pdCgpOiB2b2lkO1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkO1xuICAgIHByaXZhdGUgaXNEYXRlUmVhbENoYW5nZTtcbiAgICBwcml2YXRlIGlzU2FtZURhdGU7XG4gICAgcHJpdmF0ZSByZW5kZXI7XG4gICAgcHJpdmF0ZSBjaGFuZ2VWYWx1ZUZyb21JbnNpZGU7XG4gICAgcHJpdmF0ZSBtYWtlSGVhZFdlZWtEYXlzO1xuICAgIHByaXZhdGUgZ2V0VmVyeVNob3J0V2Vla0Zvcm1hdDtcbiAgICBwcml2YXRlIG1ha2VXZWVrUm93cztcbiAgICB0cmFja0J5RGF0ZUZuKF9pbmRleDogbnVtYmVyLCBpdGVtOiBEYXRlQ2VsbCk6IHN0cmluZztcbiAgICB0cmFja0J5V2Vla0ZuKF9pbmRleDogbnVtYmVyLCBpdGVtOiBXZWVrUm93KTogc3RyaW5nO1xufVxuZXhwb3J0IGludGVyZmFjZSBXZWVrRGF5TGFiZWwge1xuICAgIHNob3J0OiBzdHJpbmc7XG4gICAgdmVyeVNob3J0OiBzdHJpbmc7XG59XG5leHBvcnQgaW50ZXJmYWNlIERhdGVDZWxsIHtcbiAgICB2YWx1ZTogRGF0ZTtcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgZGF0ZUNlbGxSZW5kZXI6IFRlbXBsYXRlUmVmPERhdGU+IHwgc3RyaW5nO1xuICAgIGRhdGVGdWxsQ2VsbFJlbmRlcjogVGVtcGxhdGVSZWY8RGF0ZT4gfCBzdHJpbmc7XG4gICAgY29udGVudDogc3RyaW5nO1xuICAgIGlzU2VsZWN0ZWQ/OiBib29sZWFuO1xuICAgIGlzVG9kYXk/OiBib29sZWFuO1xuICAgIGlzRGlzYWJsZWQ/OiBib29sZWFuO1xuICAgIGlzU2VsZWN0ZWRTdGFydERhdGU/OiBib29sZWFuO1xuICAgIGlzU2VsZWN0ZWRFbmREYXRlPzogYm9vbGVhbjtcbiAgICBpc0luUmFuZ2U/OiBib29sZWFuO1xuICAgIGNsYXNzTWFwPzogb2JqZWN0O1xuICAgIG9uQ2xpY2soZGF0ZTogQ2FuZHlEYXRlKTogdm9pZDtcbiAgICBvbk1vdXNlRW50ZXIoKTogdm9pZDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgV2Vla1JvdyB7XG4gICAgaXNDdXJyZW50PzogYm9vbGVhbjtcbiAgICBpc0FjdGl2ZT86IGJvb2xlYW47XG4gICAgd2Vla051bT86IG51bWJlcjtcbiAgICB5ZWFyPzogbnVtYmVyO1xuICAgIGNsYXNzTWFwPzogb2JqZWN0O1xuICAgIGRhdGVDZWxsczogRGF0ZUNlbGxbXTtcbn1cbiJdfQ==