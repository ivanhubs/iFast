/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import { ChangeDetectorRef, ElementRef, EventEmitter } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class NzOptionSelectionChange {
    source: NzAutocompleteOptionComponent;
    isUserInput: boolean;
    constructor(source: NzAutocompleteOptionComponent, isUserInput?: boolean);
}
export declare class NzAutocompleteOptionComponent {
    private changeDetectorRef;
    private element;
    nzValue: any;
    nzLabel: string;
    nzDisabled: boolean;
    readonly selectionChange: EventEmitter<NzOptionSelectionChange>;
    active: boolean;
    selected: boolean;
    constructor(changeDetectorRef: ChangeDetectorRef, element: ElementRef);
    select(emit?: boolean): void;
    deselect(): void;
    /** Git display label */
    getLabel(): string;
    /** Set active (only styles) */
    setActiveStyles(): void;
    /** Unset active (only styles) */
    setInactiveStyles(): void;
    scrollIntoViewIfNeeded(): void;
    selectViaInteraction(): void;
    private emitSelectionChangeEvent;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NzAutocompleteOptionComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NzAutocompleteOptionComponent, "nz-auto-option", ["nzAutoOption"], {
    "nzDisabled": "nzDisabled";
    "nzValue": "nzValue";
    "nzLabel": "nzLabel";
}, {
    "selectionChange": "selectionChange";
}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotYXV0b2NvbXBsZXRlLW9wdGlvbi5jb21wb25lbnQuZC50cyIsInNvdXJjZXMiOlsibnotYXV0b2NvbXBsZXRlLW9wdGlvbi5jb21wb25lbnQuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7O0FBUUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEwQkEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWxpYmFiYS5jb20gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2dpdGh1Yi5jb20vTkctWk9SUk8vbmctem9ycm8tYW50ZC9ibG9iL21hc3Rlci9MSUNFTlNFXG4gKi9cbmltcG9ydCB7IENoYW5nZURldGVjdG9yUmVmLCBFbGVtZW50UmVmLCBFdmVudEVtaXR0ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE56T3B0aW9uU2VsZWN0aW9uQ2hhbmdlIHtcbiAgICBzb3VyY2U6IE56QXV0b2NvbXBsZXRlT3B0aW9uQ29tcG9uZW50O1xuICAgIGlzVXNlcklucHV0OiBib29sZWFuO1xuICAgIGNvbnN0cnVjdG9yKHNvdXJjZTogTnpBdXRvY29tcGxldGVPcHRpb25Db21wb25lbnQsIGlzVXNlcklucHV0PzogYm9vbGVhbik7XG59XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekF1dG9jb21wbGV0ZU9wdGlvbkNvbXBvbmVudCB7XG4gICAgcHJpdmF0ZSBjaGFuZ2VEZXRlY3RvclJlZjtcbiAgICBwcml2YXRlIGVsZW1lbnQ7XG4gICAgbnpWYWx1ZTogYW55O1xuICAgIG56TGFiZWw6IHN0cmluZztcbiAgICBuekRpc2FibGVkOiBib29sZWFuO1xuICAgIHJlYWRvbmx5IHNlbGVjdGlvbkNoYW5nZTogRXZlbnRFbWl0dGVyPE56T3B0aW9uU2VsZWN0aW9uQ2hhbmdlPjtcbiAgICBhY3RpdmU6IGJvb2xlYW47XG4gICAgc2VsZWN0ZWQ6IGJvb2xlYW47XG4gICAgY29uc3RydWN0b3IoY2hhbmdlRGV0ZWN0b3JSZWY6IENoYW5nZURldGVjdG9yUmVmLCBlbGVtZW50OiBFbGVtZW50UmVmKTtcbiAgICBzZWxlY3QoZW1pdD86IGJvb2xlYW4pOiB2b2lkO1xuICAgIGRlc2VsZWN0KCk6IHZvaWQ7XG4gICAgLyoqIEdpdCBkaXNwbGF5IGxhYmVsICovXG4gICAgZ2V0TGFiZWwoKTogc3RyaW5nO1xuICAgIC8qKiBTZXQgYWN0aXZlIChvbmx5IHN0eWxlcykgKi9cbiAgICBzZXRBY3RpdmVTdHlsZXMoKTogdm9pZDtcbiAgICAvKiogVW5zZXQgYWN0aXZlIChvbmx5IHN0eWxlcykgKi9cbiAgICBzZXRJbmFjdGl2ZVN0eWxlcygpOiB2b2lkO1xuICAgIHNjcm9sbEludG9WaWV3SWZOZWVkZWQoKTogdm9pZDtcbiAgICBzZWxlY3RWaWFJbnRlcmFjdGlvbigpOiB2b2lkO1xuICAgIHByaXZhdGUgZW1pdFNlbGVjdGlvbkNoYW5nZUV2ZW50O1xufVxuIl19