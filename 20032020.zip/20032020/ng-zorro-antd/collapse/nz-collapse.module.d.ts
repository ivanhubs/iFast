/**
 * @license
 * Copyright Alibaba.com All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './nz-collapse-panel.component';
import * as ɵngcc2 from './nz-collapse.component';
import * as ɵngcc3 from '@angular/common';
import * as ɵngcc4 from 'ng-zorro-antd/icon';
import * as ɵngcc5 from 'ng-zorro-antd/core';
export declare class NzCollapseModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NzCollapseModule, [typeof ɵngcc1.NzCollapsePanelComponent, typeof ɵngcc2.NzCollapseComponent], [typeof ɵngcc3.CommonModule, typeof ɵngcc4.NzIconModule, typeof ɵngcc5.NzAddOnModule], [typeof ɵngcc1.NzCollapsePanelComponent, typeof ɵngcc2.NzCollapseComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NzCollapseModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibnotY29sbGFwc2UubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm56LWNvbGxhcHNlLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O0FBT0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFsaWJhYmEuY29tIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbiAqIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgYXQgaHR0cHM6Ly9naXRodWIuY29tL05HLVpPUlJPL25nLXpvcnJvLWFudGQvYmxvYi9tYXN0ZXIvTElDRU5TRVxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOekNvbGxhcHNlTW9kdWxlIHtcbn1cbiJdfQ==