import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fundfactsheet',
  templateUrl: './fundfactsheet.component.html',
  styleUrls: ['./fundfactsheet.component.css']
})
export class FundfactsheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
