import { Component, OnInit } from '@angular/core';

import {TransactionInfo} from '../transaction-info/transactionInfo';
@Component({
  selector: 'app-charges',
  templateUrl: './charges.component.html',
  styleUrls: ['./charges.component.css']
})
export class ChargesComponent implements OnInit {
  transactionData:TransactionInfo[]=[
    {key:"Sales Charges",value :"1.75%"},
    {key:"Annual Management Fee",value :"1.75%"},
    {key:"Switching Fee",value:"Not Applicable"},
    {key:"Redemption Fee",value:"-"},
    {key: "Annual Expense Ratio",value:"2.31% as at 30 Jun 2018"},
    {key:"Trusted Fee",value:"0.08% p.a. of NAV"}
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
