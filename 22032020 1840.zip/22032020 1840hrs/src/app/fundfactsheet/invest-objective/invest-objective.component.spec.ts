import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvestObjectiveComponent } from './invest-objective.component';

describe('InvestObjectiveComponent', () => {
  let component: InvestObjectiveComponent;
  let fixture: ComponentFixture<InvestObjectiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvestObjectiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvestObjectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
