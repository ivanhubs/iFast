import { Component, OnInit } from '@angular/core';
import {TransactionInfo} from './transactionInfo';
@Component({
  selector: 'app-transaction-info',
  templateUrl: './transaction-info.component.html',
  styleUrls: ['./transaction-info.component.css']
})
export class TransactionInfoComponent implements OnInit {
  transactionData:TransactionInfo[]=[
  {key:"Minimum Initial Investment",value :"MYR 1000"},
  {key:"Minimum Subsequent Investment",value :"MYR 500"},
  {key:"Minimum RSP Investment",value:"MYR 100"},
  {key:"Minimum Redemption Amount",value:"500 Units"},
  {key: "Minimum Holding",value:"MYR 1000"},
  {key:"Cooling-off Period(from transaction date)",value:"6 Business Days"},
  {key: "Buy Processing Time",value:"T + 3 business days"},
  {key: "Redemption Processing Time",value:"T + 6 business days"}
];

  constructor() { }

  ngOnInit(): void {
  }

}
