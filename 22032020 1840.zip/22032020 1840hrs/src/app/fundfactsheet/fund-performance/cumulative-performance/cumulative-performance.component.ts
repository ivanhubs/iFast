import { Component, OnInit } from '@angular/core';
import {PeriodOverPercent} from '../periodOverPercent'
@Component({
  selector: 'app-cumulative-performance',
  templateUrl: './cumulative-performance.component.html',
  styleUrls: ['./cumulative-performance.component.css']
})
export class CumulativePerformanceComponent implements OnInit {
  cumulativePerformanceData: PeriodOverPercent[] = [
    { period: '1W',percentage: "4.81%"},
    { period: '1M', percentage: "7.90%"},
    { period: '3M',percentage: "6.37%"},
    { period: '6M', percentage: "2.94%"},
    { period: 'YTD',percentage: "0.53%"},
    { period: '1Y', percentage: "8.54%"},
    { period: '3Y',percentage: "4.33%"},
    { period: '5Y',percentage: "-"},
    { period: '10Y',percentage: "-"},
    { period: 'Launch',percentage: "0.53%"}
    
    ];
  constructor() { }

  ngOnInit(): void {
  }

}
