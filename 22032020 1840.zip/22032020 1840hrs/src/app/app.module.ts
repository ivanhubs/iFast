import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations'
import { AppRoutingModule } from './app-routing.module';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NZ_I18N, en_US } from 'ng-zorro-antd/i18n';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzFormModule } from 'ng-zorro-antd/form';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderHomeComponent } from './home/header-home/header-home.component';
import { Body1HomeComponent } from './home/body1-home/body1-home.component';
import { Body2HomeComponent } from './home/body2-home/body2-home.component';
import { Body3HomeComponent } from './home/body3-home/body3-home.component';
import { Body4HomeComponent } from './home/body4-home/body4-home.component';
import { FooterHomeComponent } from './home/footer-home/footer-home.component';
import { FundfactsheetComponent } from './fundfactsheet/fundfactsheet.component';
import { FundTitleComponent } from './fundfactsheet/fund-title/fund-title.component';
import { FundInfoComponent } from './fundfactsheet/fund-info/fund-info.component';
import { FundDocumentsComponent } from './fundfactsheet/fund-documents/fund-documents.component';
import { InvestObjectiveComponent } from './fundfactsheet/invest-objective/invest-objective.component';
import { FundPerformanceComponent } from './fundfactsheet/fund-performance/fund-performance.component';
import { AnnualisedReturnsComponent } from './fundfactsheet/fund-performance/annualised-returns/annualised-returns.component';
import { CumulativePerformanceComponent } from './fundfactsheet/fund-performance/cumulative-performance/cumulative-performance.component';
import { YearReturnsComponent } from './fundfactsheet/fund-performance/year-returns/year-returns.component';
import { HistoricalNavMovementComponent } from './fundfactsheet/fund-performance/historical-nav-movement/historical-nav-movement.component';
import { FundReturnsComponent } from './fundfactsheet/fund-returns/fund-returns.component';
import { RiskMetricsComponent } from './fundfactsheet/risk-metrics/risk-metrics.component';
import { DisclaimerComponent } from './fundfactsheet/disclaimer/disclaimer.component';
import { TransactionInfoComponent } from './fundfactsheet/transaction-info/transaction-info.component';
import { ChargesComponent } from './fundfactsheet/charges/charges.component';
import { AnnouncementComponent } from './fundfactsheet/announcement/announcement.component';
import { TopPerformanceComponent } from './fundfactsheet/top-performance/top-performance.component';
import { LoginComponent } from './login/login.component';
import { LoginDetailsComponent } from './login/login-details/login-details.component';
import { RegisterComponent } from './register/register.component';
import { RegisterDetailsComponent } from './register/register-details/register-details.component';
import { Content1Component } from './register/content1/content1.component';
import { Content2Component } from './register/content2/content2.component';
import { Content3Component } from './register/content3/content3.component';
import { Content4Component } from './register/content4/content4.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderHomeComponent,
    Body1HomeComponent,
    Body2HomeComponent,
    Body3HomeComponent,
    Body4HomeComponent,
    FooterHomeComponent,
    FundfactsheetComponent,
    FundTitleComponent,
    FundInfoComponent,
    FundDocumentsComponent,
    InvestObjectiveComponent,
    FundPerformanceComponent,
    AnnualisedReturnsComponent,
    CumulativePerformanceComponent,
    YearReturnsComponent,
    HistoricalNavMovementComponent,
    FundReturnsComponent,
    RiskMetricsComponent,
    DisclaimerComponent,
    TransactionInfoComponent,
    ChargesComponent,
    AnnouncementComponent,
    TopPerformanceComponent,
    LoginComponent,
    LoginDetailsComponent,
    RegisterComponent,
    RegisterDetailsComponent,
    Content1Component,
    Content2Component,
    Content3Component,
    Content4Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NzDatePickerModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    NzStepsModule,
    NzUploadModule,
    NzIconModule,
    NzRadioModule,
    NzInputModule,
    NzSelectModule,
    NzFormModule
  ],
  providers: [{provide: NZ_I18N, useValue: en_US} ],
  bootstrap: [AppComponent]
})
export class AppModule { }
