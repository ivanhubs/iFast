import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";
import { FormGroup } from '@angular/forms';
import { userData } from '../userData';
@Component({
  selector: 'app-content4',
  templateUrl: './content4.component.html',
  styleUrls: ['./content4.component.css']
})
export class Content4Component implements OnInit {
  public usernamearray={};
  username:string;
  password :string;
  re_password:string;
  constructor(_dataService:DataService) { 
    
    console.log(_dataService.getOption()); 
    this.usernamearray=_dataService.getOption();
    console.log( this.usernamearray); 
 }

  ngOnInit(): void {
  }

}
