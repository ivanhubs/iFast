export class userData{
    constructor(public username:string){
        
    }
    getName() {  
        return this.username;  
      }  
      setUsername(data) {  
        console.log(data);
        this.username = data.option;  
      } 
    } 