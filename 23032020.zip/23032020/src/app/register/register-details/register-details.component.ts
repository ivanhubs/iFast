import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";
import { userData } from '../userData';

@Component({
  selector: 'app-register-details',
  templateUrl: './register-details.component.html',
  styleUrls: ['./register-details.component.css']
})
export class RegisterDetailsComponent implements OnInit {
  current = 0;
  userInfo:userData;
  index = 'First-content';
  username:string;
  password :string;
  re_password:string;
  declare1:string;
  declare2:string;
  securityAnswer:string;
  securityQuestion:string;
  salutation:string;
  name:string;
  nric:string;
  dob:string;
  cob:string;
  nationality:string;
  bumiStatus:boolean;
  race:string;
  gender:string;
  maritalStatus:string;
  address1:string;
  address2:string;
  address3:string;

  static labelArray=["declare1","declare2","username",
  "password","re_password","securityQuestion","securityAnswer",
  "salutation","name","nric","dob","cob","nationality",
  "bumiStatus","race","gender","maritalStatus","address1","address2","address3"
];


  constructor(_dataService: DataService) { 
    RegisterDetailsComponent.labelArray.forEach(function(value) {
      _dataService.setOption(value, "");
    }); 

    console.log(_dataService.getOption());  
  } 
  ngOnInit(): void {
    
  }

  pre(): void {
    this.current -= 1;
    this.changeContent();
  }

  next(): void {

    this.current += 1;
    this.changeContent();
  }

  done(): void {
    console.log('done');
  }

  changeContent(): void {
    switch (this.current) {
      case 0: {
        this.index = 'First-content';
        break;
      }
      case 1: {
        this.index = 'Second-content';
        break;
      }
      case 2: {
        this.index = 'third-content';
        break;
      }
      default: {
        this.index = 'error';
      }
    }
  }

}
