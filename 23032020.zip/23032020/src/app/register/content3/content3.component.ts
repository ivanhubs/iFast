import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content3',
  templateUrl: './content3.component.html',
  styleUrls: ['./content3.component.css']
})
export class Content3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
