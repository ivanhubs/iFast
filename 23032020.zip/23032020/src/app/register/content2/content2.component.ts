import { Component, OnInit,Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { DataService } from "../data.service";

@Component({
  selector: 'app-content2',
  templateUrl: './content2.component.html',
  styleUrls: ['./content2.component.css']
})
export class Content2Component implements OnInit {
  passwordVisible1 = false;
  passwordVisible2 = false;
  declare1:string;
  declare2:string;
  securityAnswer:string;
  securityQuestion:string;
  salutation:string;
  name:string;
  nric:string;
  dob:string;
  cob:string;
  nationality:string;
  bumiStatus:boolean;
  race:string;
  gender:string;
  maritalStatus:string;
  address1:string;
  address2:string;
  address3:string;
  public usernamearray={};


  constructor(private fb: FormBuilder,_dataService:DataService) { 
    
    console.log(_dataService.getOption()); 
    this.usernamearray=_dataService.getOption();
    console.log( this.usernamearray); 
 }

  ngOnInit(): void {

  }
}
