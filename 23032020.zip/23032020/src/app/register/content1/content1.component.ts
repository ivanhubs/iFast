import { Component, OnInit } from '@angular/core';
import { UploadFile } from 'ng-zorro-antd/upload';

class ImageSnippet{
  constructor(public src:string,public file:File){}
}
@Component({
  selector: 'app-content1',
  templateUrl: './content1.component.html',
  styleUrls: ['./content1.component.css']
})
export class Content1Component implements OnInit {
  selectedFileFront: ImageSnippet;
  selectedFileBack: ImageSnippet;
  processFileFront(imageInput:any){
  
    debugger;
  const file: File = imageInput.files[0];
  const reader = new FileReader();
  
  reader.addEventListener('load',(event:any) => {
    debugger; 
    this.selectedFileFront = new ImageSnippet(event.target.result,file);

  
  });
  reader.readAsDataURL(file);
  }

  processFileBack(imageInput:any){
  
    debugger;
  const file: File = imageInput.files[0];
  const reader = new FileReader();
  
  reader.addEventListener('load',(event:any) => {
    debugger; 
    this.selectedFileBack = new ImageSnippet(event.target.result,file);
  
  });
  reader.readAsDataURL(file);
  }
  ngOnInit(): void {
  }


}

