import { Component, OnInit } from '@angular/core';

import {TransactionInfo} from '../transaction-info/transactionInfo';
@Component({
  selector: 'app-announcement',
  templateUrl: './announcement.component.html',
  styleUrls: ['./announcement.component.css']
})
export class AnnouncementComponent implements OnInit {
  transactionData:TransactionInfo[]=[
    {key:"Malaysia Public Holiday",value :"No upcoming public holiday"},
    {key:"Fund Holiday**",value :"No upcoming public holiday"},
    {key:"Fund Related Notice",value:"-"}

  ];
  constructor() { }

  ngOnInit(): void {
  }

}
