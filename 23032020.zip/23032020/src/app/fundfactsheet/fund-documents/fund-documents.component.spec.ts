import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundDocumentsComponent } from './fund-documents.component';

describe('FundDocumentsComponent', () => {
  let component: FundDocumentsComponent;
  let fixture: ComponentFixture<FundDocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundDocumentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
