export interface TransactionInfo{
    key: string;
    value: string;
    
}