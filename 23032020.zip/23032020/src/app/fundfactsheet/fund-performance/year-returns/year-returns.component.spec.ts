import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearReturnsComponent } from './year-returns.component';

describe('YearReturnsComponent', () => {
  let component: YearReturnsComponent;
  let fixture: ComponentFixture<YearReturnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearReturnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearReturnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
