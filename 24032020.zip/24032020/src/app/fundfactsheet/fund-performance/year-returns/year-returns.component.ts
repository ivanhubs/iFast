import { Component, OnInit } from '@angular/core';
import {PeriodOverPercent} from '../periodOverPercent';
@Component({
  selector: 'app-year-returns',
  templateUrl: './year-returns.component.html',
  styleUrls: ['./year-returns.component.css']
})
export class YearReturnsComponent implements OnInit {
  annualisedReturnsData: PeriodOverPercent[] = [
    { period: '2018',percentage: "-10.94%"},
    { period: '2017', percentage: "7.15%"},
    { period: '2016',percentage: "5.34%"},
    { period: '2015', percentage: "-"},
    { period: '2014',percentage: "-"}
    
    ];
  constructor() { }

  ngOnInit(): void {
  }

}
