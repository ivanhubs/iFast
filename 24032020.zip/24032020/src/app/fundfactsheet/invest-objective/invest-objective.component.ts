import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invest-objective',
  templateUrl: './invest-objective.component.html',
  styleUrls: ['./invest-objective.component.css']
})
export class InvestObjectiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
