export interface FundInfo{
    class: string;
    sector: string;
    geo_Alloc: string;
    approvalEPF:string;
    complaintShariah:string;
    fundSize:number;
    dateLaunch:string;
    priceLaunch:number;
    pricingBasis:string;
    historicalIncomeDist:string

}