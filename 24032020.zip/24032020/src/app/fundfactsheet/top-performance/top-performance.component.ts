import { Component, OnInit } from '@angular/core';
import {TransactionInfo} from '../transaction-info/transactionInfo';
@Component({
  selector: 'app-top-performance',
  templateUrl: './top-performance.component.html',
  styleUrls: ['./top-performance.component.css']
})
export class TopPerformanceComponent implements OnInit {
  transactionData:TransactionInfo[]=[
    {key:"G Opportunity Fund",value :"31.63%"},
    {key:"B Growth Fund",value :"-0.70%"},
    {key:"H Sukuk Fund - USD",value:"31.26%"},
    {key:"F Balanced Fund - MYR ",value :"26.72%"},
    {key:"R Asia (Ex Japan) Opportunity Fund - USD",value :"19.75%"},
    {key:"B Balanced Fund A Acc USD",value:"25.56%"},
    {key:"P Income Fund E Acc USD",value :"25.32%"},
    {key:"T Emerging Market Bond Fund Retail (Gross)Acc USD",value :"21.03%"}

  ];
  constructor() { }

  ngOnInit(): void {
  }

}
