import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-content3',
  templateUrl: './content3.component.html',
  styleUrls: ['./content3.component.css']
})
export class Content3Component implements OnInit {
  dataArray: {};


  constructor(private fb: FormBuilder,_dataService:DataService) { 
  
    this.dataArray=_dataService.getOption(); 
    console.log(this.dataArray);
 }
  ngOnInit(): void {
  }

}
