import { Injectable } from '@angular/core';

@Injectable()
export class DataService {

  private data={};

  getOption() {  
    return this.data;  
  }  
}