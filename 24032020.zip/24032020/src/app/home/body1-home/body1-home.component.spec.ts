import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Body1HomeComponent } from './body1-home.component';

describe('Body1HomeComponent', () => {
  let component: Body1HomeComponent;
  let fixture: ComponentFixture<Body1HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Body1HomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Body1HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
