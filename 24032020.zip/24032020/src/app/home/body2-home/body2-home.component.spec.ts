import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Body2HomeComponent } from './body2-home.component';

describe('Body2HomeComponent', () => {
  let component: Body2HomeComponent;
  let fixture: ComponentFixture<Body2HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Body2HomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Body2HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
