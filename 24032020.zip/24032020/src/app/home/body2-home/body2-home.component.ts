import { Component, OnInit } from '@angular/core';
import { Fund } from './fundData'
@Component({
  selector: 'app-body2-home',
  templateUrl: './body2-home.component.html',
  styleUrls: ['./body2-home.component.css']
})
export class Body2HomeComponent implements OnInit {
  funds: Fund[] = [
    { name: 'RHB China-India Dynamic Growth Fund', price: 0.9855, percentage: 3.81},
    { name: 'RHB Energy Fund', price: 0.3632, percentage: 2.57},
    { name: 'RHB-GS US Equity Fund', price: 1.2338, percentage: 2.46},
    { name: 'RHB Dana Hazeem', price: 0.6928, percentage: 2.30},
    { name: 'RHB Shariah China Focus Fund - MYR', price: 1.2716, percentage: 2.01},
    { name: 'RHB Emerging Markets Bond Fund', price: 0.6021, percentage: 1.07},
    { name: 'RHB Golden Dragon Fund', price: 0.559, percentage: 0.23},
    { name: 'RHB Dana Hazeem', price: 0.4275, percentage: 0.12}
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
