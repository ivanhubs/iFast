import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body3-home',
  templateUrl: './body3-home.component.html',
  styleUrls: ['./body3-home.component.css']
})
export class Body3HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
