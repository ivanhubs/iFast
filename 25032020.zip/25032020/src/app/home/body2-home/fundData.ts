export interface Fund{
    name: string;
    price: number;
    percentage:number;

}