import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body1-home',
  templateUrl: './body1-home.component.html',
  styleUrls: ['./body1-home.component.css']
})
export class Body1HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
