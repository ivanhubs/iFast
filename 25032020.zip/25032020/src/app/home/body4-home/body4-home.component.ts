import { Component, OnInit } from '@angular/core';
import { Fund } from '../body2-home/fundData';
@Component({
  selector: 'app-body4-home',
  templateUrl: './body4-home.component.html',
  styleUrls: ['./body4-home.component.css']
})
export class Body4HomeComponent implements OnInit {
  funds: Fund[] = [
    { name: 'RHB Asian Real Estate Fund', price: 0.4512, percentage: 6.61},
    { name: 'RHB Cash Managemen Fund 2', price: 1.4135, percentage: 3.40},
    { name: 'RHB Bond Fund', price: 0.9486, percentage: 5.99},
    { name: 'RHB Golden Dragon Fund', price: 0.559, percentage: 3.58},
   
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
