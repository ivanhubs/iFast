import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-content3',
  templateUrl: './content3.component.html',
  styleUrls: ['./content3.component.css']
})
export class Content3Component implements OnInit {
  dataArray: {};
  validateForm: FormGroup;
  labels = ["maiden", "sourceIncome", "sourceIncome2","occupation", "employerName",
"employerLocation","businessNature","annualIncome","networth","agent","agentCode"];
  constructor(private fb: FormBuilder, _dataService: DataService) {
    this.dataArray = _dataService.getOption();
    this.validateForm = this.fb.group({
      maiden: ['', [Validators.required]],
      sourceIncome: ['', [Validators.required]],
      sourceIncome2: ['', [Validators.required]],
      occupation: ['', [Validators.required]],
      employerName: ['', [Validators.required]],
      employerLocation: ['', [Validators.required]],
      businessNature: ['', [Validators.required]],
      annualIncome: ['', [Validators.required]],
      networth: ['', [Validators.required]],
      agent: ['', [Validators.required]],
      agentCode: ['', [Validators.required]]
    });
    this.labels.forEach(element => {
      this.validateForm.get(element).valueChanges.subscribe(val => {
        const formattedMessage = `${val}`;
        this.dataArray[element] = formattedMessage;
      });
    });
  }
      ngOnInit(): void {

      }

    } 
