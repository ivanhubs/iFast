import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, ValidationErrors } from '@angular/forms';
import { DataService } from "../data.service";
import { Observable, Observer, fromEventPattern } from 'rxjs';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-content2',
  templateUrl: './content2.component.html',
  styleUrls: ['./content2.component.css']
})
export class Content2Component implements OnInit {
 passwordVisible1 = false;
  passwordVisible2 = false;
  validateForm : FormGroup;
  public labels=["declare1","declare2","username","password","securityQuestion","securityAnswer","salutation","name"
,"nric","dob","cob","nationality","bumiStatus","race","gender","maritalStatus","address1","address2","address3",
"postalcode","city","state","country","correspondenceAdd",
"email","mNumber","hNumber","oNumber","mccNumber","hccNumber","occNumber","ext"];
  public dataArray={};

  constructor(_dataService:DataService,private fb: FormBuilder) { 
    this.dataArray=_dataService.getOption(); 
    this.validateForm = this.fb.group({
      username: ['', [Validators.required], [this.userNameAsyncValidator]],
      declare1: ['', [Validators.required]],
      declare2: ['', [Validators.required]],
      password: ['', [Validators.required]],
      confirm: ['', [this.confirmValidator]],
      securityQuestion: ['', [Validators.required]],
      securityAnswer: ['', [Validators.required]],
      salutation:['', [Validators.required]],
      name:['', [Validators.required]],
      nric:['', [Validators.required]],
      dob:['', [Validators.required]],
      cob:['', [Validators.required]],
      nationality:['', [Validators.required]],
      bumiStatus:['', [Validators.required]],
      race:['', [Validators.required]],
      gender:['', [Validators.required]],
      maritalStatus:['', [Validators.required]],
      address1:['', [Validators.required]],
      address2:['', [Validators.required]],
      address3:['', [Validators.required]],
      postalcode:['', [Validators.required]],
      city:['', [Validators.required]],
      state:['', [Validators.required]],
      country:['', [Validators.required]],
      correspondenceAdd:['', [Validators.required]],
      email:['', [ Validators.email,Validators.required]],
      mccNumber:['', [Validators.required]],
      hccNumber:['', [Validators.required]],
      occNumber:['', [Validators.required]],
      mNumber:['', [Validators.required]],
      hNumber:['', [Validators.required]],
      oNumber:['', [Validators.required]],
      ext:['', [Validators.required]]
    });
    this.labels.forEach(element => {
      this.validateForm.get(element).valueChanges.subscribe(val => {
        const formattedMessage = `${val}`;
        this.dataArray[element]=formattedMessage;
      });
    });

    console.log(this.dataArray);
  }
  
  ngOnInit(): void {

  }
  validateConfirmPassword(): void {
    setTimeout(() => this.validateForm.controls.confirm.updateValueAndValidity());
  }

  userNameAsyncValidator = (control: FormControl) =>
    new Observable((observer: Observer<ValidationErrors | null>) => {
      setTimeout(() => {
        if (control.value === 'ABC') {
          // you have to return `{error: true}` to mark it as an error event
          observer.next({ error: true, duplicated: true });
        } else {
          observer.next(null);
        }
        observer.complete();
      }, 1000);
    });

  confirmValidator = (control: FormControl): { [s: string]: boolean } => {
    if (!control.value) {
      return { error: true, required: true };
    } else if (control.value !== this.validateForm.controls.password.value) {
      return { confirm: true, error: true };
    }
    return {};
  };

 
}
