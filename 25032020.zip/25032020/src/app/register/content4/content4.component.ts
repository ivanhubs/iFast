import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-content4',
  templateUrl: './content4.component.html',
  styleUrls: ['./content4.component.css']
})
export class Content4Component implements OnInit {
  public dataArray = {};
  public keys: string[];
  public values: string[];
  labelArray1 = ["I hereby confirm I understand my FATCA requirement.I hereby declare that I am*:"];
  labelArray2 = ["I hereby confirm I understand my tax residency/CRS requirement.I hereby declare that I am*:"];
  labelArray3 = ["Username*: ", "Password*: ", "Security Question*:", ""];
  labelArray4 = ["Salutation*: ", "Full Name (as per NRIC/Passport)*: ", "NRIC Number/Passport(non Malaysian citizen*:",
    "Date of Birth*:", "Country of Birth*:", "Nationality", "Bumiputera Status*:", "Race*:",
    "Gender*:", "Marital Status*:"];
  labelArray5 = [ "Address*: ","Postal Code*: ", "Town/City*:",
    "State*:", "Country*:", "Is your correspondence address same as your permenant address?*:"];

  labelArray6 = ["Email Address*:", "Mobile Number*:", "Residence/House Number:", "Office Number:"];

  labelArray7 = ["Source of Income*:", "Occupation*:", "Name of Employee / Business*:",
    "Employer's / Business Office*:", "Nature of Business*:", "Annual Income*:", "Estimate Net Worth*:"];

  labelArray8 = ["Do you have a preferred Agent?*:", "Agent Code:"]
  
  constructor(_dataService: DataService) {
    this.dataArray = _dataService.getOption();

    console.log(this.dataArray);
  }



  ngOnInit(): void {
  }

}
