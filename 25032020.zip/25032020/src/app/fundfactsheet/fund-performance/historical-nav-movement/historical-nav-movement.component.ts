import { Component, OnInit } from '@angular/core';
import {PeriodOverPercent} from '../periodOverPercent';

@Component({
  selector: 'app-historical-nav-movement',
  templateUrl: './historical-nav-movement.component.html',
  styleUrls: ['./historical-nav-movement.component.css']
})
export class HistoricalNavMovementComponent implements OnInit {
  annualisedReturnsData: PeriodOverPercent[] = [
    { period: '1Y High',percentage: "MYR 1.1052"},
    { period: '1Y Low', percentage: "MYR 0.9849"},
    { period: '3Y High',percentage: "MYR 1.1704"},
    { period: '3Y Low', percentage: "MYR 0.9406"},
    { period: 'All-time High',percentage: "MYR 1.1704"},
    { period: 'All-time Low',percentage: "MYR 0.8875"}
    
    ];
  constructor() { }

  ngOnInit(): void {
  }

}
