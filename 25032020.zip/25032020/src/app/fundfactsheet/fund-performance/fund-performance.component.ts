import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-fund-performance',
  templateUrl: './fund-performance.component.html',
  styleUrls: ['./fund-performance.component.css']
})
export class FundPerformanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
