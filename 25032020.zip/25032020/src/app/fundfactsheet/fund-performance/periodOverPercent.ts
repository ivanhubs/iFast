export interface PeriodOverPercent{
    period:string;
    percentage:string;

}