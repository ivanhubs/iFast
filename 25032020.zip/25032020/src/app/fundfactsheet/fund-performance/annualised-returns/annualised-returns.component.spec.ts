import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnualisedReturnsComponent } from './annualised-returns.component';

describe('AnnualisedReturnsComponent', () => {
  let component: AnnualisedReturnsComponent;
  let fixture: ComponentFixture<AnnualisedReturnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnnualisedReturnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnualisedReturnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
