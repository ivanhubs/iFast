import { Component, OnInit } from '@angular/core';
import {PeriodOverPercent} from '../periodOverPercent'
@Component({
  selector: 'app-annualised-returns',
  templateUrl: './annualised-returns.component.html',
  styleUrls: ['./annualised-returns.component.css']
})
export class AnnualisedReturnsComponent implements OnInit {
  annualisedReturnsData: PeriodOverPercent[] = [
    { period: '3M',percentage: "6.37%"},
    { period: '6M', percentage: "2.94%"},
    { period: '1Y',percentage: "8.54%"},
    { period: '2Y', percentage: "5.89%"},
    { period: '3Y',percentage: "1.46%"},
    { period: '5Y', percentage: "-"},
    { period: '10Y',percentage: "-"}
    
    ];
  constructor() { }

  ngOnInit(): void {
  }

}
