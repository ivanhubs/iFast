import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundfactsheetComponent } from './fundfactsheet.component';

describe('FundfactsheetComponent', () => {
  let component: FundfactsheetComponent;
  let fixture: ComponentFixture<FundfactsheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundfactsheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundfactsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
