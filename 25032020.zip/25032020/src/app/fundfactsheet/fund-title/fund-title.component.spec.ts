import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundTitleComponent } from './fund-title.component';

describe('FundTitleComponent', () => {
  let component: FundTitleComponent;
  let fixture: ComponentFixture<FundTitleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundTitleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
