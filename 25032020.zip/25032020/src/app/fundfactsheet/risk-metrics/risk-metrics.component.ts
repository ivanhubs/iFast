import { Component, OnInit } from '@angular/core';
import {PeriodOverPercent} from '../fund-performance/periodOverPercent';
@Component({
  selector: 'app-risk-metrics',
  templateUrl: './risk-metrics.component.html',
  styleUrls: ['./risk-metrics.component.css']
})
export class RiskMetricsComponent implements OnInit {
  annualisedReturnsData: PeriodOverPercent[] = [
    { period: '3Y Annualised Volatility',percentage: "11.53%"},
    { period: '3Y Sharpe Ratio', percentage: "-0.30%"}

    
    ];
  constructor() { }

  ngOnInit(): void {
  }

}
