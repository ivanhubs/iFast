import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskMetricsComponent } from './risk-metrics.component';

describe('RiskMetricsComponent', () => {
  let component: RiskMetricsComponent;
  let fixture: ComponentFixture<RiskMetricsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiskMetricsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiskMetricsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
